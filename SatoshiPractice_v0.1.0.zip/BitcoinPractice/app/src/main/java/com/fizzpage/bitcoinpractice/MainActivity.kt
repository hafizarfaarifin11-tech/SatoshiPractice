package com.fizzpage.bitcoinpractice

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 14, 17)
    private val panel = Color.rgb(21, 26, 33)
    private val panelAlt = Color.rgb(28, 34, 42)
    private val gold = Color.rgb(247, 147, 26)
    private val white = Color.rgb(242, 244, 247)
    private val muted = Color.rgb(145, 153, 164)
    private val green = Color.rgb(22, 190, 125)
    private val red = Color.rgb(239, 83, 80)

    private lateinit var balanceText: TextView
    private lateinit var priceText: TextView
    private lateinit var changeText: TextView
    private lateinit var marketStatusText: TextView
    private lateinit var btcText: TextView
    private lateinit var holdingValueText: TextView
    private lateinit var amountInput: EditText
    private lateinit var historyContainer: LinearLayout
    private lateinit var chartView: MarketChartView
    private lateinit var refreshButton: Button

    private val prefs by lazy { getSharedPreferences("satoshi_practice", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var virtualBalance = 100_000_000.0
    private var btcHolding = 0.0
    private var currentPrice = 0.0
    private var change24h = 0.0
    private var marketFresh = false
    private var fetching = false
    private val pricePoints = mutableListOf<Double>()
    private val records = mutableListOf<TradeRecord>()

    private val refreshRunnable = object : Runnable {
        override fun run() {
            fetchMarketData()
            handler.postDelayed(this, 90_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        virtualBalance = prefs.getString("practice_balance", "100000000")?.toDoubleOrNull() ?: 100_000_000.0
        btcHolding = prefs.getString("btc_holding", "0")?.toDoubleOrNull() ?: 0.0
        currentPrice = prefs.getString("last_price", "0")?.toDoubleOrNull() ?: 0.0
        change24h = prefs.getString("last_change", "0")?.toDoubleOrNull() ?: 0.0
        loadCachedChart()
        loadRecords()

        buildScreen()
        updatePortfolio()
        renderHistory()
        if (currentPrice > 0.0) {
            priceText.text = formatIdr(currentPrice)
            changeText.text = formatChange(change24h)
            changeText.setTextColor(if (change24h >= 0) green else red)
            marketStatusText.text = "Harga tersimpan · perbarui untuk data terbaru"
            chartView.setValues(pricePoints)
        }
        fetchMarketData()
        handler.postDelayed(refreshRunnable, 90_000L)
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshRunnable)
        super.onDestroy()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            clipToPadding = false
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }
        scroll.addView(content, ScrollView.LayoutParams(-1, -2))
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brandColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandColumn.addView(label("SATOSHI", 22f, white, true))
        brandColumn.addView(label("BTC / IDR MARKET", 10f, muted, true).apply {
            letterSpacing = 0.12f
        })
        header.addView(brandColumn, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("₿", 34f, gold, true))
        content.addView(header)
        content.addView(gap(14))

        val notice = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panelAlt, 12)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        notice.addView(label("AKUN LATIHAN", 11f, gold, true))
        notice.addView(label("Kredit virtual saja. Tidak ada uang sungguhan, deposit, atau transaksi kripto nyata.", 12f, muted, false).apply {
            setPadding(0, dp(4), 0, 0)
        })
        content.addView(notice, matchWrap())
        content.addView(gap(14))

        val balanceCard = card()
        balanceCard.addView(label("TOTAL SALDO LATIHAN", 11f, muted, true))
        balanceText = label("Rp 100.000.000", 27f, white, true).apply {
            setPadding(0, dp(7), 0, dp(3))
        }
        balanceCard.addView(balanceText)
        balanceCard.addView(label("Saldo awal berupa kredit virtual", 11f, muted, false))
        content.addView(balanceCard, matchWrap())
        content.addView(gap(12))

        val marketCard = card()
        val marketTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val marketTitles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        marketTitles.addView(label("Bitcoin", 18f, white, true))
        marketTitles.addView(label("BTC · Bitcoin", 11f, muted, false))
        marketTop.addView(marketTitles, LinearLayout.LayoutParams(0, -2, 1f))
        refreshButton = button("↻", panelAlt, white).apply {
            minWidth = dp(44)
            setOnClickListener { fetchMarketData() }
        }
        marketTop.addView(refreshButton)
        marketCard.addView(marketTop)
        priceText = label("Mengambil harga...", 25f, white, true).apply {
            setPadding(0, dp(15), 0, dp(4))
        }
        marketCard.addView(priceText)
        changeText = label("Perubahan 24 jam: --", 12f, muted, true)
        marketCard.addView(changeText)
        marketStatusText = label("Menghubungkan ke data pasar...", 10f, muted, false).apply {
            setPadding(0, dp(5), 0, dp(8))
        }
        marketCard.addView(marketStatusText)
        marketCard.addView(label("PERGERAKAN 24 JAM · DATA PASAR", 10f, muted, true))
        chartView = MarketChartView()
        marketCard.addView(chartView, LinearLayout.LayoutParams(-1, dp(150)))
        content.addView(marketCard, matchWrap())
        content.addView(gap(12))

        val holdingCard = card()
        holdingCard.addView(label("PORTOFOLIO BTC", 11f, muted, true))
        val holdingRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val holdingColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        btcText = label("0.00000000 BTC", 18f, white, true)
        holdingValueText = label("Nilai: Rp 0", 11f, muted, false).apply {
            setPadding(0, dp(4), 0, 0)
        }
        holdingColumn.addView(btcText)
        holdingColumn.addView(holdingValueText)
        holdingRow.addView(holdingColumn)
        holdingCard.addView(holdingRow)
        content.addView(holdingCard, matchWrap())
        content.addView(gap(12))

        val orderCard = card()
        orderCard.addView(label("ORDER LATIHAN", 13f, white, true))
        orderCard.addView(label("Masukkan nominal dalam rupiah", 11f, muted, false).apply {
            setPadding(0, dp(5), 0, dp(9))
        })
        amountInput = EditText(this).apply {
            hint = "Contoh: 500000"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            singleLine = true
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(panelAlt, 10)
        }
        orderCard.addView(amountInput, matchWrap())
        orderCard.addView(label("Biaya latihan: 0,1% per order", 10f, muted, false).apply {
            setPadding(0, dp(7), 0, dp(12))
        })
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val buyButton = button("BELI BTC", gold, Color.BLACK).apply {
            setOnClickListener { submitOrder(isBuy = true) }
        }
        val sellButton = button("JUAL BTC", panelAlt, white).apply {
            setOnClickListener { submitOrder(isBuy = false) }
        }
        buttons.addView(buyButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            marginEnd = dp(6)
        })
        buttons.addView(sellButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            marginStart = dp(6)
        })
        orderCard.addView(buttons)
        orderCard.addView(label("Order hanya mengubah portofolio latihan di perangkat ini.", 10f, muted, false).apply {
            setPadding(0, dp(10), 0, 0)
        })
        content.addView(orderCard, matchWrap())
        content.addView(gap(12))

        val historyCard = card()
        historyCard.addView(label("RIWAYAT ORDER", 13f, white, true))
        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        historyCard.addView(historyContainer)
        content.addView(historyCard, matchWrap())
        content.addView(gap(15))
        content.addView(label("SATOSHI PRACTICE  ·  VERSION 0.1.0", 10f, muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        })
    }

    private fun submitOrder(isBuy: Boolean) {
        val amount = amountInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (amount == null || amount <= 0.0) {
            toast("Masukkan nominal yang valid.")
            return
        }
        if (!marketFresh || currentPrice <= 0.0) {
            toast("Harga pasar terbaru belum tersedia. Perbarui data dulu.")
            return
        }

        val feeRate = 0.001
        if (isBuy) {
            val totalCost = amount * (1.0 + feeRate)
            if (totalCost > virtualBalance) {
                toast("Saldo latihan tidak mencukupi.")
                return
            }
            val btcBought = amount / currentPrice
            virtualBalance -= totalCost
            btcHolding += btcBought
            records.add(0, TradeRecord("BELI", amount, btcBought, currentPrice, System.currentTimeMillis()))
            toast("Order beli latihan berhasil.")
        } else {
            val btcToSell = amount / currentPrice
            if (btcToSell > btcHolding) {
                toast("Jumlah BTC latihan tidak mencukupi.")
                return
            }
            val netProceeds = amount * (1.0 - feeRate)
            virtualBalance += netProceeds
            btcHolding -= btcToSell
            records.add(0, TradeRecord("JUAL", amount, btcToSell, currentPrice, System.currentTimeMillis()))
            toast("Order jual latihan berhasil.")
        }

        while (records.size > 30) records.removeAt(records.lastIndex)
        prefs.edit()
            .putString("practice_balance", virtualBalance.toString())
            .putString("btc_holding", btcHolding.toString())
            .putString("order_history", serializeRecords())
            .apply()
        amountInput.setText("")
        updatePortfolio()
        renderHistory()
    }

    private fun fetchMarketData() {
        if (fetching) return
        fetching = true
        refreshButton.isEnabled = false
        marketStatusText.text = "Memperbarui data pasar..."

        thread(name = "btc-market-fetch") {
            try {
                val quoteJson = requestJson(
                    "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=idr&include_24hr_change=true"
                )
                val btc = quoteJson.getJSONObject("bitcoin")
                val newPrice = btc.getDouble("idr")
                val newChange = btc.optDouble("idr_24h_change", 0.0)
                if (newPrice <= 0.0) throw IllegalStateException("Harga tidak valid")

                val newPoints = try {
                    val chartJson = requestJson(
                        "https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=idr&days=1&interval=hourly"
                    )
                    val array = chartJson.getJSONArray("prices")
                    val parsed = mutableListOf<Double>()
                    for (i in 0 until array.length()) {
                        val pair = array.optJSONArray(i) ?: continue
                        if (pair.length() >= 2) {
                            val value = pair.optDouble(1, 0.0)
                            if (value > 0.0) parsed.add(value)
                        }
                    }
                    parsed
                } catch (_: Exception) {
                    emptyList()
                }

                runOnUiThread {
                    currentPrice = newPrice
                    change24h = newChange
                    marketFresh = true
                    if (newPoints.isNotEmpty()) {
                        pricePoints.clear()
                        pricePoints.addAll(newPoints)
                        saveCachedChart()
                    }
                    prefs.edit()
                        .putString("last_price", currentPrice.toString())
                        .putString("last_change", change24h.toString())
                        .apply()
                    priceText.text = formatIdr(currentPrice)
                    updatePortfolio()
                    changeText.text = formatChange(change24h)
                    changeText.setTextColor(if (change24h >= 0.0) green else red)
                    val stamp = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date())
                    marketStatusText.text = "Data pasar diperbarui $stamp · CoinGecko"
                    chartView.setValues(pricePoints)
                }
            } catch (_: Exception) {
                runOnUiThread {
                    marketFresh = false
                    marketStatusText.text = "Data pasar tidak tersedia. Coba perbarui lagi."
                    if (currentPrice <= 0.0) priceText.text = "Harga belum tersedia"
                    else priceText.text = formatIdr(currentPrice)
                    changeText.text = "Harga terakhir tersimpan · order dinonaktifkan"
                    changeText.setTextColor(muted)
                }
            } finally {
                runOnUiThread {
                    fetching = false
                    refreshButton.isEnabled = true
                }
            }
        }
    }

    private fun requestJson(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "SatoshiPractice/0.1 Android")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun updatePortfolio() {
        balanceText.text = formatIdr(virtualBalance)
        btcText.text = String.format(Locale.US, "%.8f BTC", btcHolding)
        val estimated = if (currentPrice > 0.0) btcHolding * currentPrice else 0.0
        holdingValueText.text = "Nilai perkiraan: ${formatIdr(estimated)}"
    }

    private fun renderHistory() {
        historyContainer.removeAllViews()
        if (records.isEmpty()) {
            historyContainer.addView(label("Belum ada order. Transaksi latihan akan muncul di sini.", 11f, muted, false).apply {
                setPadding(0, dp(5), 0, dp(4))
            })
            return
        }
        records.take(10).forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(9), 0, dp(9))
            }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val typeColor = if (item.type == "BELI") green else gold
            details.addView(label(item.type + " BTC", 12f, typeColor, true))
            val time = SimpleDateFormat("dd MMM, HH:mm", Locale("id", "ID")).format(Date(item.time))
            details.addView(label("$time · ${String.format(Locale.US, "%.8f", item.btc)} BTC", 10f, muted, false).apply {
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(formatIdr(item.idr), 12f, white, true))
            historyContainer.addView(row)
            if (index < records.take(10).lastIndex) {
                historyContainer.addView(View(this).apply { setBackgroundColor(panelAlt) },
                    LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
    }

    private fun loadRecords() {
        records.clear()
        val raw = prefs.getString("order_history", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                records.add(
                    TradeRecord(
                        obj.optString("type", "BELI"),
                        obj.optDouble("idr", 0.0),
                        obj.optDouble("btc", 0.0),
                        obj.optDouble("price", 0.0),
                        obj.optLong("time", 0L)
                    )
                )
            }
        } catch (_: Exception) {
            records.clear()
        }
    }

    private fun serializeRecords(): String {
        val array = JSONArray()
        records.forEach { item ->
            array.put(JSONObject().apply {
                put("type", item.type)
                put("idr", item.idr)
                put("btc", item.btc)
                put("price", item.price)
                put("time", item.time)
            })
        }
        return array.toString()
    }

    private fun loadCachedChart() {
        pricePoints.clear()
        try {
            val array = JSONArray(prefs.getString("price_chart", "[]") ?: "[]")
            for (i in 0 until array.length()) {
                val value = array.optDouble(i, 0.0)
                if (value > 0.0) pricePoints.add(value)
            }
        } catch (_: Exception) {
            pricePoints.clear()
        }
    }

    private fun saveCachedChart() {
        val array = JSONArray()
        pricePoints.forEach { array.put(it) }
        prefs.edit().putString("price_chart", array.toString()).apply()
    }

    private fun formatIdr(value: Double): String {
        val number = NumberFormat.getNumberInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 0
            minimumFractionDigits = 0
        }
        return "Rp ${number.format(value)}"
    }

    private fun formatChange(value: Double): String {
        val sign = if (value >= 0.0) "+" else ""
        return "${sign}${String.format(Locale.US, "%.2f", value)}%  ·  24 jam"
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD)
            else Typeface.create("sans-serif", Typeface.NORMAL)
            includeFontPadding = true
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = rounded(panel, 14)
        }
    }

    private fun button(value: String, color: Int, textColor: Int): Button {
        return Button(this).apply {
            text = value
            textSize = 12f
            setTextColor(textColor)
            isAllCaps = false
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(color, 10)
            stateListAnimator = null
            minHeight = dp(44)
            minimumHeight = dp(44)
            setPadding(dp(10), 0, dp(10), 0)
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun gap(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private data class TradeRecord(
        val type: String,
        val idr: Double,
        val btc: Double,
        val price: Double,
        val time: Long
    )

    private inner class MarketChartView : View(this@MainActivity) {
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = gold
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x35F7931A
            style = Paint.Style.FILL
        }
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x24FFFFFF
            strokeWidth = dp(1).toFloat()
        }
        private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = dp(11).toFloat()
        }
        private var values: List<Double> = emptyList()

        fun setValues(data: List<Double>) {
            values = data.toList()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val left = dp(2).toFloat()
            val right = width - dp(2).toFloat()
            val top = dp(14).toFloat()
            val bottom = height - dp(12).toFloat()
            for (i in 0..3) {
                val y = top + (bottom - top) * i / 3f
                canvas.drawLine(left, y, right, y, gridPaint)
            }
            if (values.size < 2) {
                canvas.drawText("Grafik menunggu data pasar", left, height / 2f, emptyPaint)
                return
            }
            val low = values.minOrNull() ?: return
            val high = values.maxOrNull() ?: return
            val range = max(high - low, 1.0)
            val line = Path()
            val area = Path()
            values.forEachIndexed { index, value ->
                val x = left + (right - left) * index / (values.size - 1).toFloat()
                val y = bottom - ((value - low) / range).toFloat() * (bottom - top)
                if (index == 0) {
                    line.moveTo(x, y)
                    area.moveTo(x, bottom)
                    area.lineTo(x, y)
                } else {
                    line.lineTo(x, y)
                    area.lineTo(x, y)
                }
            }
            area.lineTo(right, bottom)
            area.close()
            canvas.drawPath(area, fillPaint)
            canvas.drawPath(line, linePaint)
        }
    }
}
