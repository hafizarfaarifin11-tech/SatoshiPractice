# Satoshi Practice v0.1.0

A portrait Android Bitcoin market-practice app with a dark BTC-inspired interface.

## Included
- BTC/IDR spot price and 24-hour price history fetched from CoinGecko's public API.
- Local practice portfolio with virtual IDR credits and BTC holdings.
- Buy/sell practice orders with a 0.1% practice fee.
- Local transaction history, saved on the device.
- Automatic market refresh every 90 seconds, plus manual refresh.
- Android GitHub Actions workflow at `.github/workflows/android.yml`.

## Important
This is a practice app, not a cryptocurrency exchange or wallet. It does not accept deposits, send payments, connect to a bank, or move real cryptocurrency. The starting IDR balance is virtual practice credit. The market data is retrieved from CoinGecko and may be delayed, unavailable, or rate-limited.

## Build with GitHub Actions
1. Create a new GitHub repository and upload the contents of this folder.
2. Keep the workflow at `.github/workflows/android.yml`.
3. Push to `main` or `master`, or open **Actions → Android CI → Run workflow**.
4. Download the `SatoshiPractice-debug-apk` artifact after the run succeeds.

The workflow builds a debug APK. It is not a Play Store release build.
