# Satoshi Practice v0.1.2 — Android CI project

Repository layout:

- `.github/workflows/android.yml` — GitHub Actions workflow (keep this at repository root).
- `android_project/` — Android Studio / Gradle project source.

## Build APK

1. Extract this ZIP.
2. Upload **all extracted contents** to the root of your GitHub repository. Do not upload the ZIP as a single file.
3. Keep `.github/workflows/android.yml` and `android_project/` at the repository root, side by side.
4. Push to `main` or `master`, or run **Actions → Android CI → Run workflow**.
5. Download the `SatoshiPractice-debug-apk` artifact when the workflow succeeds.

The app uses virtual practice credits; it is not a real exchange or wallet and does not accept real-money deposits.
