# Satoshi Practice v0.5.5

All balances and transactions are virtual practice values. This app does not mine real Bitcoin or connect trading orders to an exchange.

Auto Miner uses `AutoMinerService`, an Android foreground service, to continue the local practice market and bot while the screen is off or the Activity is not visible. It displays an ongoing notification with a stop action. A partial CPU wake lock is used for one-second local ticks and can drain battery. In background it uses the last cached BTC/IDR reference; it does not refresh the external ticker until the app returns to the foreground. Android/OEM battery controls, force-stop, or device shutdown can still stop it. The bot does not automatically restart after a device reboot.

The existing `android.yml` GitHub Actions workflow does not need to change.
