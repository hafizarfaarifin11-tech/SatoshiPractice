# Satoshi Practice v0.6.0

Android project for Satoshi Practice, built with Kotlin and Android Gradle Plugin.

## v0.6.0 – Random market path, hourly outlook, profile photo and credit limits

- Replaced the alternating trend phases with a symmetric random walk, including occasional larger jumps. Price direction is not forced by a win/loss script.
- Shortened visible chart history to three minutes.
- Updated the hourly outlook to show 1, 2, 3, and 4 hour estimates.
- Updated the separate virtual lucky-bonus draw to 50% for Rp50,000–Rp250,000 and 50% with no bonus. This bonus is separate from BTC price movement.
- Capped the selectable virtual credit amount at Rp25,000,000.
- Preserved the previous waiting times up to Rp500,000; amounts above that add one hour per additional Rp500,000 increment.
- Reduced the long credit explanation flow to one concise confirmation. The app still identifies the balance as virtual and does not process real money or exchange orders.
- Added an optional local profile photo during the first profile step, shown in the account header.
- Existing balance, BTC holdings, and transaction history are preserved by this update.

## Build

Import the `android_project` folder in Android Studio or use the repository's existing Android CI workflow. The ZIP contains source files only; no prebuilt APK is included.
