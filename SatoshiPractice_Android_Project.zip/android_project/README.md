# Satoshi Practice v0.5.3

Proyek Android native Kotlin untuk aplikasi latihan pasar BTC/IDR. Tidak terhubung ke akun exchange, tidak mengirim order nyata, dan tidak memproses uang sungguhan.

## Fitur
- Registrasi profil lima langkah dan halaman akun.
- Grafik BTC/IDR latihan dengan harga aktif untuk estimasi dan order.
- Order beli/jual virtual dengan satuan BTC/IDR, biaya latihan 0,1%, serta tombol MAX.
- Portofolio dan riwayat transaksi lokal.
- Auto Miner BTC: bot trading latihan yang membaca grafik setiap detik, membeli memakai hingga 18% saldo IDR yang tersedia, dan menjual berdasarkan target, batas risiko, batas waktu, atau sinyal berubah.
- Panel laporan Auto Miner mencatat semua transaksi bot, harga, jumlah BTC, biaya, hasil bersih, dan P/L. Posisi yang terbuka saat bot dihentikan tetap berada di portofolio.
- Auto Miner berjalan selama aplikasi berada di layar. Ketika aplikasi ditinggalkan/ditutup, bot berhenti; setelah aplikasi dibuka lagi bot perlu diaktifkan manual.

## Penting
Nama fitur "Auto Miner" adalah label aplikasi. Secara fungsi ia merupakan bot trading untuk latihan, bukan mining Bitcoin sungguhan. Seluruh saldo dan transaksi bersifat virtual.

## Build
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- versionCode 16
- versionName 0.5.3
