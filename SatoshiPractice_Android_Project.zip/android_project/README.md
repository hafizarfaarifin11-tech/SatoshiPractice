# Satoshi Practice v0.1.2

Android project directory for the Satoshi Practice app.

This is a practice app with virtual IDR credits. It is not a cryptocurrency exchange or wallet and does not accept deposits or move real cryptocurrency.

## Build

The repository-level GitHub Actions workflow is at `.github/workflows/android.yml`. It builds this project from the `android_project/` directory.
