# Satoshi Practice v0.5.8

All balances and transactions are virtual practice values. This app does not mine real Bitcoin or connect trading orders to an exchange.

Auto Miner uses `AutoMinerService`, an Android foreground service, to continue the local practice market and bot while the screen is off or the Activity is not visible. It displays an ongoing notification with a stop action. A partial CPU wake lock is used for one-second local ticks and can drain battery. In background it uses the last cached BTC/IDR reference; it does not refresh the external ticker until the app returns to the foreground. Android/OEM battery controls, force-stop, or device shutdown can still stop it. The bot does not automatically restart after a device reboot.

The existing `android.yml` GitHub Actions workflow does not need to change.


## v0.5.6 – Auto Miner lebih selektif
- Menghapus entry acak; bot menunggu EMA, momentum, pantulan, dan volatilitas sesuai filter.
- Maksimal 4% saldo virtual per posisi dan jeda minimal 3 menit antar-entry.
- Stop posisi sekitar -1,0% bersih, target +1,6%, serta trailing stop setelah posisi mencapai +0,7%.
- Tidak lagi memaksa menutup posisi rugi hanya karena waktu habis; batas waktu normal menjadi 10 menit.
- Rem otomatis menghentikan sesi jika nilai portofolio turun 3% dari nilai awal sesi.
- Semua transaksi tetap simulasi kredit virtual; hasil tidak dijamin dan bukan sinyal untuk trading sungguhan.


## v0.5.7 – Saldo awal kembali Rp0
- Saat pertama kali membuka versi ini setelah update, saldo IDR virtual dan kepemilikan BTC di-reset menjadi 0.
- Auto Miner dihentikan dan posisi bot yang masih terbuka dibersihkan agar tidak mengubah saldo setelah reset.
- Kredit latihan yang masih dalam antrean dibatalkan supaya saldo tidak tiba-tiba bertambah setelah update.
- Profil, pengaturan onboarding, dan riwayat transaksi lama tetap disimpan.
- Reset hanya berjalan sekali; kredit virtual berikutnya hanya bertambah setelah pengguna memulai proses latihan secara manual.


## v0.5.8 – Batas harga dan Auto Miner mode hoki
- Grafik harga simulasi dikunci pada Rp1.110.000.000 sampai Rp1.200.000.000; titik grafik lama di luar rentang dipotong saat update.
- Setiap posisi Auto Miner mendapat undian lokal: 60% skenario untung dan 40% skenario rugi. Harga grafik simulasi diarahkan ke target/stop yang sesuai sampai posisi ditutup. Ini mekanik game, bukan model pasar atau prediksi trading sungguhan.
- Kartu "Informasi Saldo" di dashboard dihapus sepenuhnya; tidak diganti dengan kartu lain.
- Auto Miner kini dapat memakai maksimal 95% saldo virtual per posisi, target hasil bersih +1,6%, dan stop-loss bersih -1,2%, dengan rem sesi 3%.
- Filter entry dibuat sedikit lebih responsif; aturan Service dan Activity fallback disamakan.
- Contoh: saldo virtual Rp20.000.000, ukuran posisi 95%, dan kenaikan harga dari Rp1,11B ke Rp1,13B dapat menghasilkan sekitar Rp303.696 bersih setelah biaya 0,1% beli dan 0,1% jual. Nilai aktual bergantung pada modal, harga entry/exit, dan biaya.
- Hasil tetap bergantung pada undian virtual per transaksi dan rem sesi. Peluang 60/40 hanya mekanik game lokal; tidak menggambarkan peluang pasar nyata.
