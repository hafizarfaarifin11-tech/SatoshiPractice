package com.fizzpage.bitcoinpractice

import android.app.Activity
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 14, 17)
    private val panel = Color.rgb(21, 26, 33)
    private val panelAlt = Color.rgb(28, 34, 42)
    private val gold = Color.rgb(247, 147, 26)
    private val white = Color.rgb(242, 244, 247)
    private val muted = Color.rgb(145, 153, 164)
    private val green = Color.rgb(22, 190, 125)
    private val red = Color.rgb(239, 83, 80)

    private lateinit var balanceText: TextView
    private lateinit var priceText: TextView
    private lateinit var changeText: TextView
    private lateinit var marketStatusText: TextView
    private lateinit var btcText: TextView
    private lateinit var holdingValueText: TextView
    private lateinit var amountInput: EditText
    private lateinit var historyContainer: LinearLayout
    private lateinit var chartView: MarketChartView
    private lateinit var refreshButton: Button

    private val prefs by lazy { getSharedPreferences("satoshi_practice", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var virtualBalance = 100_000_000.0
    private var btcHolding = 0.0
    private var currentPrice = 0.0
    private var change24h = 0.0
    private var marketFresh = false
    private var fetching = false
    private val pricePoints = mutableListOf<Double>()
    private val records = mutableListOf<TradeRecord>()

    private val refreshRunnable = object : Runnable {
        override fun run() {
            fetchMarketData()
            handler.postDelayed(this, 90_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        virtualBalance = prefs.getString("practice_balance", "100000000")?.toDoubleOrNull() ?: 100_000_000.0
        btcHolding = prefs.getString("btc_holding", "0")?.toDoubleOrNull() ?: 0.0
        currentPrice = prefs.getString("last_price", "0")?.toDoubleOrNull() ?: 0.0
        change24h = prefs.getString("last_change", "0")?.toDoubleOrNull() ?: 0.0
        loadCachedChart()
        loadRecords()

        buildScreen()
        updatePortfolio()
        renderHistory()
        if (currentPrice > 0.0) {
            priceText.text = formatIdr(currentPrice)
            changeText.text = formatChange(change24h)
            changeText.setTextColor(if (change24h >= 0) green else red)
            marketStatusText.text = "Harga tersimpan · perbarui untuk data terbaru"
            chartView.setValues(pricePoints)
        }
        fetchMarketData()
        handler.postDelayed(refreshRunnable, 90_000L)
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshRunnable)
        super.onDestroy()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(28))
        }
        scroll.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        setContentView(scroll)

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brandColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandColumn.addView(label("SATOSHI", 23f, white, true))
        brandColumn.addView(label("BITCOIN MARKET", 10f, muted, true).apply {
            letterSpacing = 0.16f
        })
        header.addView(brandColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val coinMark = TextView(this).apply {
            text = "₿"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(gold, 50)
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        header.addView(coinMark)
        content.addView(header)
        content.addView(gap(14))

        // Clear practice-account notice
        val notice = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.rgb(43, 34, 22), 11)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val noticeMark = TextView(this).apply {
            text = "●"
            textSize = 12f
            setTextColor(gold)
            setPadding(0, 0, dp(9), 0)
        }
        val noticeCopy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        noticeCopy.addView(label("AKUN LATIHAN", 10f, gold, true))
        noticeCopy.addView(label("Saldo dan order memakai kredit virtual, bukan uang sungguhan.", 10f, muted, false).apply {
            setPadding(0, dp(3), 0, 0)
        })
        notice.addView(noticeMark)
        notice.addView(noticeCopy, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(notice, matchWrap())
        content.addView(gap(14))

        // BTC market panel and moving chart
        val marketCard = card().apply { setPadding(dp(15), dp(15), dp(15), dp(13)) }
        val marketTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val marketTitles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        marketTitles.addView(label("BTC / IDR", 16f, white, true))
        marketTitles.addView(label("Bitcoin · Spot market", 10f, muted, false).apply {
            setPadding(0, dp(3), 0, 0)
        })
        marketTop.addView(marketTitles, LinearLayout.LayoutParams(0, -2, 1f))
        refreshButton = button("↻", panelAlt, white).apply {
            minWidth = dp(42)
            minHeight = dp(40)
            minimumHeight = dp(40)
            setOnClickListener { fetchMarketData() }
        }
        marketTop.addView(refreshButton)
        marketCard.addView(marketTop)

        priceText = label("Mengambil harga...", 27f, white, true).apply {
            setPadding(0, dp(15), 0, dp(4))
        }
        marketCard.addView(priceText)
        changeText = label("Perubahan 24 jam: --", 12f, green, true)
        marketCard.addView(changeText)

        val chartHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, dp(4))
        }
        chartHeader.addView(label("GRAFIK HARGA", 10f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        chartHeader.addView(label("24 JAM", 10f, gold, true))
        marketCard.addView(chartHeader)

        chartView = MarketChartView()
        marketCard.addView(chartView, LinearLayout.LayoutParams(-1, dp(214)))

        val legend = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        legend.addView(dot(green))
        legend.addView(label("Naik", 10f, muted, false).apply { setPadding(dp(5), 0, dp(13), 0) })
        legend.addView(dot(red))
        legend.addView(label("Turun", 10f, muted, false).apply { setPadding(dp(5), 0, 0, 0) })
        marketCard.addView(legend)
        marketStatusText = label("Menghubungkan ke data pasar...", 10f, muted, false).apply {
            setPadding(0, dp(7), 0, 0)
        }
        marketCard.addView(marketStatusText)
        content.addView(marketCard, matchWrap())
        content.addView(gap(12))

        // Order panel is placed immediately under the chart. Action buttons sit at its bottom.
        val orderCard = card().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
        val orderHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        orderHeader.addView(label("BUAT ORDER", 12f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        orderHeader.addView(label("BTC / IDR", 10f, muted, true))
        orderCard.addView(orderHeader)
        orderCard.addView(label("Nominal transaksi (IDR)", 10f, muted, false).apply {
            setPadding(0, dp(12), 0, dp(7))
        })
        amountInput = EditText(this).apply {
            hint = "Contoh: 500000"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(panelAlt, 10)
        }
        orderCard.addView(amountInput, matchWrap())
        orderCard.addView(label("Biaya latihan 0,1% · harga mengikuti pembaruan pasar", 10f, muted, false).apply {
            setPadding(0, dp(7), 0, dp(12))
        })

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val buyButton = button("BELI BTC", green, Color.BLACK).apply {
            setOnClickListener { submitOrder(isBuy = true) }
        }
        val sellButton = button("JUAL BTC", red, Color.WHITE).apply {
            setOnClickListener { submitOrder(isBuy = false) }
        }
        buttons.addView(buyButton, LinearLayout.LayoutParams(0, dp(49), 1f).apply {
            marginEnd = dp(6)
        })
        buttons.addView(sellButton, LinearLayout.LayoutParams(0, dp(49), 1f).apply {
            marginStart = dp(6)
        })
        orderCard.addView(buttons)
        orderCard.addView(label("Order hanya mengubah saldo dan portofolio latihan di perangkat ini.", 10f, muted, false).apply {
            setPadding(0, dp(10), 0, 0)
        })
        content.addView(orderCard, matchWrap())
        content.addView(gap(12))

        // Account information below market and trade controls
        val balanceCard = card()
        val balanceHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        balanceHeader.addView(label("SALDO IDR", 10f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        balanceHeader.addView(label("KREDIT VIRTUAL", 9f, gold, true))
        balanceCard.addView(balanceHeader)
        balanceText = label("Rp 100.000.000", 25f, white, true).apply {
            setPadding(0, dp(8), 0, dp(3))
        }
        balanceCard.addView(balanceText)
        balanceCard.addView(label("Saldo tersedia untuk order latihan", 10f, muted, false))
        content.addView(balanceCard, matchWrap())
        content.addView(gap(12))

        val holdingCard = card()
        holdingCard.addView(label("PORTOFOLIO SAYA", 11f, muted, true))
        val holdingRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val holdingColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        btcText = label("0.00000000 BTC", 19f, white, true)
        holdingValueText = label("Nilai perkiraan: Rp 0", 11f, muted, false).apply {
            setPadding(0, dp(4), 0, 0)
        }
        holdingColumn.addView(btcText)
        holdingColumn.addView(holdingValueText)
        holdingRow.addView(holdingColumn, LinearLayout.LayoutParams(0, -2, 1f))
        holdingRow.addView(label("₿", 27f, gold, true))
        holdingCard.addView(holdingRow)
        content.addView(holdingCard, matchWrap())
        content.addView(gap(12))

        val historyCard = card()
        historyCard.addView(label("RIWAYAT ORDER", 12f, white, true))
        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        historyCard.addView(historyContainer)
        content.addView(historyCard, matchWrap())
        content.addView(gap(15))
        content.addView(label("SATOSHI PRACTICE · VERSION 0.2.0", 9f, muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        })
    }

    private fun dot(color: Int): View = View(this).apply {
        background = rounded(color, 20)
        layoutParams = LinearLayout.LayoutParams(dp(7), dp(7))
    }

    private fun submitOrder(isBuy: Boolean) {
        val amount = amountInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (amount == null || amount <= 0.0) {
            toast("Masukkan nominal yang valid.")
            return
        }
        if (!marketFresh || currentPrice <= 0.0) {
            toast("Harga pasar terbaru belum tersedia. Perbarui data dulu.")
            return
        }

        val feeRate = 0.001
        if (isBuy) {
            val totalCost = amount * (1.0 + feeRate)
            if (totalCost > virtualBalance) {
                toast("Saldo latihan tidak mencukupi.")
                return
            }
            val btcBought = amount / currentPrice
            virtualBalance -= totalCost
            btcHolding += btcBought
            records.add(0, TradeRecord("BELI", amount, btcBought, currentPrice, System.currentTimeMillis()))
            toast("Order beli latihan berhasil.")
        } else {
            val btcToSell = amount / currentPrice
            if (btcToSell > btcHolding) {
                toast("Jumlah BTC latihan tidak mencukupi.")
                return
            }
            val netProceeds = amount * (1.0 - feeRate)
            virtualBalance += netProceeds
            btcHolding -= btcToSell
            records.add(0, TradeRecord("JUAL", amount, btcToSell, currentPrice, System.currentTimeMillis()))
            toast("Order jual latihan berhasil.")
        }

        while (records.size > 30) records.removeAt(records.lastIndex)
        prefs.edit()
            .putString("practice_balance", virtualBalance.toString())
            .putString("btc_holding", btcHolding.toString())
            .putString("order_history", serializeRecords())
            .apply()
        amountInput.setText("")
        updatePortfolio()
        renderHistory()
    }

    private fun fetchMarketData() {
        if (fetching) return
        fetching = true
        refreshButton.isEnabled = false
        marketStatusText.text = "Memperbarui data pasar..."

        thread(name = "btc-market-fetch") {
            try {
                val quoteJson = requestJson(
                    "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=idr&include_24hr_change=true"
                )
                val btc = quoteJson.getJSONObject("bitcoin")
                val newPrice = btc.getDouble("idr")
                val newChange = btc.optDouble("idr_24h_change", 0.0)
                if (newPrice <= 0.0) throw IllegalStateException("Harga tidak valid")

                val newPoints = try {
                    val chartJson = requestJson(
                        "https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=idr&days=1&interval=hourly"
                    )
                    val array = chartJson.getJSONArray("prices")
                    val parsed = mutableListOf<Double>()
                    for (i in 0 until array.length()) {
                        val pair = array.optJSONArray(i) ?: continue
                        if (pair.length() >= 2) {
                            val value = pair.optDouble(1, 0.0)
                            if (value > 0.0) parsed.add(value)
                        }
                    }
                    parsed
                } catch (_: Exception) {
                    emptyList()
                }

                runOnUiThread {
                    currentPrice = newPrice
                    change24h = newChange
                    marketFresh = true
                    val chartSeries = if (newPoints.isNotEmpty()) {
                        newPoints.takeLast(48).toMutableList()
                    } else {
                        pricePoints.toMutableList()
                    }
                    if (chartSeries.isEmpty() || chartSeries.last() != newPrice) {
                        chartSeries.add(newPrice)
                    }
                    pricePoints.clear()
                    pricePoints.addAll(chartSeries.takeLast(49))
                    saveCachedChart()
                    prefs.edit()
                        .putString("last_price", currentPrice.toString())
                        .putString("last_change", change24h.toString())
                        .apply()
                    priceText.text = formatIdr(currentPrice)
                    updatePortfolio()
                    changeText.text = formatChange(change24h)
                    changeText.setTextColor(if (change24h >= 0.0) green else red)
                    val stamp = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date())
                    marketStatusText.text = "Data pasar diperbarui $stamp · CoinGecko"
                    chartView.setValues(pricePoints)
                }
            } catch (_: Exception) {
                runOnUiThread {
                    marketFresh = false
                    marketStatusText.text = "Data pasar tidak tersedia. Coba perbarui lagi."
                    if (currentPrice <= 0.0) priceText.text = "Harga belum tersedia"
                    else priceText.text = formatIdr(currentPrice)
                    changeText.text = "Harga terakhir tersimpan · order dinonaktifkan"
                    changeText.setTextColor(muted)
                }
            } finally {
                runOnUiThread {
                    fetching = false
                    refreshButton.isEnabled = true
                }
            }
        }
    }

    private fun requestJson(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "SatoshiPractice/0.2 Android")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun updatePortfolio() {
        balanceText.text = formatIdr(virtualBalance)
        btcText.text = String.format(Locale.US, "%.8f BTC", btcHolding)
        val estimated = if (currentPrice > 0.0) btcHolding * currentPrice else 0.0
        holdingValueText.text = "Nilai perkiraan: ${formatIdr(estimated)}"
    }

    private fun renderHistory() {
        historyContainer.removeAllViews()
        if (records.isEmpty()) {
            historyContainer.addView(label("Belum ada order. Transaksi latihan akan muncul di sini.", 11f, muted, false).apply {
                setPadding(0, dp(5), 0, dp(4))
            })
            return
        }
        records.take(10).forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(9), 0, dp(9))
            }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val typeColor = if (item.type == "BELI") green else gold
            details.addView(label(item.type + " BTC", 12f, typeColor, true))
            val time = SimpleDateFormat("dd MMM, HH:mm", Locale("id", "ID")).format(Date(item.time))
            details.addView(label("$time · ${String.format(Locale.US, "%.8f", item.btc)} BTC", 10f, muted, false).apply {
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(formatIdr(item.idr), 12f, white, true))
            historyContainer.addView(row)
            if (index < records.take(10).lastIndex) {
                historyContainer.addView(View(this).apply { setBackgroundColor(panelAlt) },
                    LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
    }

    private fun loadRecords() {
        records.clear()
        val raw = prefs.getString("order_history", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                records.add(
                    TradeRecord(
                        obj.optString("type", "BELI"),
                        obj.optDouble("idr", 0.0),
                        obj.optDouble("btc", 0.0),
                        obj.optDouble("price", 0.0),
                        obj.optLong("time", 0L)
                    )
                )
            }
        } catch (_: Exception) {
            records.clear()
        }
    }

    private fun serializeRecords(): String {
        val array = JSONArray()
        records.forEach { item ->
            array.put(JSONObject().apply {
                put("type", item.type)
                put("idr", item.idr)
                put("btc", item.btc)
                put("price", item.price)
                put("time", item.time)
            })
        }
        return array.toString()
    }

    private fun loadCachedChart() {
        pricePoints.clear()
        try {
            val array = JSONArray(prefs.getString("price_chart", "[]") ?: "[]")
            for (i in 0 until array.length()) {
                val value = array.optDouble(i, 0.0)
                if (value > 0.0) pricePoints.add(value)
            }
        } catch (_: Exception) {
            pricePoints.clear()
        }
    }

    private fun saveCachedChart() {
        val array = JSONArray()
        pricePoints.forEach { array.put(it) }
        prefs.edit().putString("price_chart", array.toString()).apply()
    }

    private fun formatIdr(value: Double): String {
        val number = NumberFormat.getNumberInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 0
            minimumFractionDigits = 0
        }
        return "Rp ${number.format(value)}"
    }

    private fun formatChange(value: Double): String {
        val sign = if (value >= 0.0) "+" else ""
        return "${sign}${String.format(Locale.US, "%.2f", value)}%  ·  24 jam"
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD)
            else Typeface.create("sans-serif", Typeface.NORMAL)
            includeFontPadding = true
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = rounded(panel, 14)
        }
    }

    private fun button(value: String, color: Int, textColor: Int): Button {
        return Button(this).apply {
            text = value
            textSize = 12f
            setTextColor(textColor)
            isAllCaps = false
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(color, 10)
            stateListAnimator = null
            minHeight = dp(44)
            minimumHeight = dp(44)
            setPadding(dp(10), 0, dp(10), 0)
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun gap(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private data class TradeRecord(
        val type: String,
        val idr: Double,
        val btc: Double,
        val price: Double,
        val time: Long
    )

    private inner class MarketChartView : View(this@MainActivity) {
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x28FFFFFF
            strokeWidth = dp(1).toFloat()
        }
        private val upPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = green
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        private val downPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = red
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = white }
        private val markerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * resources.displayMetrics.density
        }
        private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = dp(9).toFloat()
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = dp(11).toFloat()
            textAlign = Paint.Align.CENTER
        }
        private var values: List<Double> = emptyList()
        private var revealProgress = 1f
        private var pulseProgress = 0f
        private var revealAnimator: ValueAnimator? = null
        private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1150L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = LinearInterpolator()
            addUpdateListener {
                pulseProgress = it.animatedValue as Float
                invalidate()
            }
        }

        fun setValues(data: List<Double>, animate: Boolean = true) {
            values = data.filter { it.isFinite() && it > 0.0 }.toList()
            revealAnimator?.cancel()
            if (animate && values.size >= 2) {
                revealProgress = 0f
                revealAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 850L
                    interpolator = LinearInterpolator()
                    addUpdateListener {
                        revealProgress = it.animatedValue as Float
                        invalidate()
                    }
                    start()
                }
            } else {
                revealProgress = 1f
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            if (!pulseAnimator.isStarted) pulseAnimator.start()
        }

        override fun onDetachedFromWindow() {
            revealAnimator?.cancel()
            pulseAnimator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val left = dp(7).toFloat()
            val right = width - dp(7).toFloat()
            val top = dp(13).toFloat()
            val bottom = height - dp(25).toFloat()
            val plotWidth = right - left
            val plotHeight = bottom - top

            // Exchange-style grid: horizontal price levels and vertical time divisions.
            for (i in 0..4) {
                val y = top + plotHeight * i / 4f
                canvas.drawLine(left, y, right, y, gridPaint)
            }
            for (i in 0..6) {
                val x = left + plotWidth * i / 6f
                canvas.drawLine(x, top, x, bottom, gridPaint)
            }

            val timeLabels = listOf("24J", "20J", "16J", "12J", "8J", "4J", "NOW")
            timeLabels.forEachIndexed { index, text ->
                val x = left + plotWidth * index / 6f
                val align = when (index) {
                    0 -> Paint.Align.LEFT
                    6 -> Paint.Align.RIGHT
                    else -> Paint.Align.CENTER
                }
                axisPaint.textAlign = align
                canvas.drawText(text, x, height - dp(5).toFloat(), axisPaint)
            }

            if (values.size < 2 || plotWidth <= 0f || plotHeight <= 0f) {
                canvas.drawText("Menunggu data pergerakan harga...", width / 2f, height / 2f, emptyPaint)
                return
            }

            val minValue = values.minOrNull() ?: return
            val maxValue = values.maxOrNull() ?: return
            val rawRange = maxValue - minValue
            val padding = if (rawRange > 0.0) rawRange * 0.10 else max(maxValue * 0.001, 1.0)
            val low = minValue - padding
            val high = maxValue + padding
            val range = max(high - low, 1.0)

            fun pointX(index: Int): Float = left + plotWidth * index / (values.size - 1).toFloat()
            fun pointY(value: Double): Float = bottom - ((value - low) / range).toFloat() * plotHeight

            // Draw a very soft tinted area under the visible price curve.
            val segmentCount = values.size - 1
            val progressAcross = revealProgress * segmentCount
            val lastCompleteIndex = progressAcross.toInt().coerceIn(0, segmentCount)
            val partial = (progressAcross - lastCompleteIndex).coerceIn(0f, 1f)
            var endX = pointX(0)
            var endY = pointY(values[0])
            val curve = Path().apply { moveTo(endX, endY) }

            for (i in 0 until segmentCount) {
                if (i > progressAcross) break
                val fraction = if (i < lastCompleteIndex) 1f else partial
                if (fraction <= 0f) break
                val x1 = pointX(i)
                val y1 = pointY(values[i])
                val x2 = pointX(i + 1)
                val y2 = pointY(values[i + 1])
                endX = x1 + (x2 - x1) * fraction
                endY = y1 + (y2 - y1) * fraction
                curve.lineTo(endX, endY)
            }

            val tint = if (values.last() >= values.first()) green else red
            val area = Path().apply {
                moveTo(pointX(0), bottom)
                lineTo(pointX(0), pointY(values[0]))
                addPath(curve)
                lineTo(endX, bottom)
                close()
            }
            val areaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                shader = LinearGradient(
                    0f, top, 0f, bottom,
                    (tint and 0x00FFFFFF) or 0x26000000,
                    (tint and 0x00FFFFFF) or 0x00000000,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawPath(area, areaPaint)

            // Each segment is green when the sampled market price rises, red when it falls.
            canvas.save()
            canvas.clipRect(left, top - dp(2), right, bottom + dp(2))
            for (i in 0 until segmentCount) {
                if (i > progressAcross) break
                val fraction = if (i < lastCompleteIndex) 1f else partial
                if (fraction <= 0f) break
                val x1 = pointX(i)
                val y1 = pointY(values[i])
                val x2 = pointX(i + 1)
                val y2 = pointY(values[i + 1])
                val visibleX = x1 + (x2 - x1) * fraction
                val visibleY = y1 + (y2 - y1) * fraction
                val paint = if (values[i + 1] >= values[i]) upPaint else downPaint
                canvas.drawLine(x1, y1, visibleX, visibleY, paint)
            }
            canvas.restore()

            // A pulsing live point marks the latest received quote, without fabricating prices.
            val latestValue = if (progressAcross >= segmentCount) values.last() else {
                val index = lastCompleteIndex.coerceIn(0, segmentCount - 1)
                values[index] + (values[index + 1] - values[index]) * partial.toDouble()
            }
            val latestX = if (progressAcross >= segmentCount) right else endX
            val latestY = pointY(latestValue)
            val latestColor = if (values.last() >= values[values.lastIndex - 1]) green else red
            markerRingPaint.color = latestColor
            markerRingPaint.alpha = (100 + pulseProgress * 100).toInt().coerceIn(100, 200)
            canvas.drawCircle(latestX, latestY, dp(5).toFloat() + pulseProgress * dp(4), markerRingPaint)
            markerPaint.color = latestColor
            canvas.drawCircle(latestX, latestY, dp(3).toFloat(), markerPaint)
        }
    }
}