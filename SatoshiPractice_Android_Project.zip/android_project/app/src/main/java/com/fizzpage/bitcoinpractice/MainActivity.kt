package com.fizzpage.bitcoinpractice

import android.app.Activity
import android.app.AlertDialog
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 14, 17)
    private val panel = Color.rgb(21, 26, 33)
    private val panelAlt = Color.rgb(28, 34, 42)
    private val gold = Color.rgb(247, 147, 26)
    private val white = Color.rgb(242, 244, 247)
    private val muted = Color.rgb(145, 153, 164)
    private val green = Color.rgb(22, 190, 125)
    private val red = Color.rgb(239, 83, 80)

    private lateinit var balanceText: TextView
    private lateinit var priceText: TextView
    private lateinit var changeText: TextView
    private lateinit var marketStatusText: TextView
    private lateinit var btcText: TextView
    private lateinit var holdingValueText: TextView
    private lateinit var amountInput: EditText
    private lateinit var buyAsButton: Button
    private lateinit var sellAsButton: Button
    private lateinit var amountLabelText: TextView
    private lateinit var orderUnitInfoText: TextView
    private lateinit var orderEstimateText: TextView
    private lateinit var rtpContainer: LinearLayout
    private lateinit var historyContainer: LinearLayout
    private lateinit var chartView: MarketChartView
    private lateinit var refreshButton: Button
    private lateinit var creditStatusText: TextView
    private lateinit var creditSelectionText: TextView
    private lateinit var creditEstimateText: TextView
    private lateinit var creditSelectButton: Button
    private lateinit var creditButton: Button
    private var onboardingNameInput: EditText? = null

    private val prefs by lazy { getSharedPreferences("satoshi_practice", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var virtualBalance = 0.0
    private var btcHolding = 0.0
    private var buyByBtc = false
    private var sellByBtc = true
    private var activeOrderIsBuy = true
    // currentPrice is ALWAYS the latest visible chart point and is used by all
    // estimates, portfolio valuations, and practice buy/sell calculations.
    private var currentPrice = 0.0
    // The public ticker is the reference anchor for the wider practice-volatility path.
    private var marketReferencePrice = 0.0
    private var change24h = 0.0
    private var marketFresh = false
    private var fetching = false
    private var upTapCount = 0
    private var manualPriceBoostIdr = 0.0
    // The chart is an explicitly labeled practice-volatility visualization, not market history.
    private val pricePoints = mutableListOf<Double>()
    private val chartRandom = java.util.Random()
    private var lastMarketStamp = "Belum ada pembaruan harga"
    private var nextQuoteAt = 0L
    private var lastRtpUiUpdateAt = 0L
    private val quoteIntervalMs = 1_000L
    private val quoteRetryIntervalMs = 5_000L
    private var onboardingIndex = 0
    private var selectedPracticeCredit = 200_000L
    private val practiceCreditOptions = listOf(
        200_000L, 250_000L, 300_000L, 400_000L, 500_000L, 750_000L,
        1_000_000L, 1_500_000L, 2_000_000L, 2_500_000L, 3_000_000L,
        4_000_000L, 5_000_000L, 7_500_000L, 10_000_000L, 15_000_000L,
        20_000_000L, 25_000_000L, 30_000_000L, 40_000_000L, 50_000_000L,
        60_000_000L, 75_000_000L, 90_000_000L, 100_000_000L, 125_000_000L,
        150_000_000L, 175_000_000L, 200_000_000L, 250_000_000L, 300_000_000L,
        400_000_000L, 500_000_000L, 650_000_000L, 800_000_000L, 905_000_000L
    )
    private val records = mutableListOf<TradeRecord>()

    // The app polls the read-only BTC/IDR ticker for the displayed market reference.
    // The separate chart below is an explicitly labeled practice-volatility path.
    private val refreshRunnable = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (prefs.getBoolean("practice_credit_pending", false) &&
                now >= prefs.getLong("practice_credit_due_at", Long.MAX_VALUE)
            ) {
                // When the app is open, complete the scheduled credit at its selected due time.
                // The registered alarm remains as the background fallback.
                sendBroadcast(Intent(this@MainActivity, PracticeCreditReceiver::class.java))
            }
            if (!fetching && nextQuoteAt > 0L && now >= nextQuoteAt) {
                fetchMarketData()
            }
            if (::chartView.isInitialized && marketReferencePrice > 0.0) {
                // One new chart point becomes the single active price for all practice
                // trading calculations. The external ticker is only the anchor.
                val practiceAnchor = effectivePracticeAnchor()
                if (pricePoints.isEmpty()) seedPracticeChart(practiceAnchor)
                else appendPracticeChartPoint(practiceAnchor)
                currentPrice = pricePoints.lastOrNull() ?: marketReferencePrice
                priceText.text = formatIdr(currentPrice)
                prefs.edit().putString("last_price", currentPrice.toString()).apply()
                chartView.setValues(pricePoints, animate = false)
                updatePortfolio()
            }
            updateRtpUi()
            updateOrderEstimate()
            if (::marketStatusText.isInitialized) {
                val seconds = if (nextQuoteAt > now) ((nextQuoteAt - now + 999L) / 1000L) else 0L
                val countdown = if (fetching) "ticker memperbarui..." else "ticker cek lagi ${seconds} dtk"
                marketStatusText.text = "$lastMarketStamp · $countdown · harga grafik dan order berubah 1 dtk"
                updateCreditUi()
            }
            handler.postDelayed(this, 1_000L)
        }
    }

    private val onboardingSteps = listOf(
        "Selamat datang di Satoshi Practice" to "Buat akun latihan lokal. Aplikasi ini tidak membuka akun exchange atau dompet kripto sungguhan.",
        "Nama tampilan" to "Masukkan nama tampilan yang wajib diisi. Nama ini hanya disimpan di perangkat dan bukan identitas resmi.",
        "Saldo awal" to "Saldo awal akun latihan adalah Rp0. Tidak ada saldo tunai atau aset sungguhan.",
        "Harga Bitcoin" to "Harga BTC/IDR diambil dari penyedia data pasar publik dan dapat mengalami keterlambatan.",
        "Pembaruan data" to "Ticker publik dipakai sebagai acuan BTC/IDR. Harga latihan pada grafik berubah setiap detik dan menjadi harga yang dipakai untuk perhitungan order.",
        "Grafik" to "Grafik memperlihatkan jalur harga latihan yang berfluktuasi setiap detik. Titik terakhir grafik adalah harga aktif untuk estimasi beli, jual, dan valuasi portofolio. Grafik ini bukan riwayat harga pasar.",
        "Tombol beli" to "Beli BTC hanya menghitung perubahan portofolio latihan di perangkat ini.",
        "Tombol jual" to "Jual BTC hanya mengubah catatan saldo dan BTC latihan. Tidak ada order yang dikirim ke pasar.",
        "Biaya latihan" to "Biaya order hanyalah perhitungan latihan untuk membantu memahami nilai transaksi.",
        "Portofolio" to "Nilai portofolio merupakan perkiraan berdasarkan harga BTC terakhir yang diterima.",
        "Riwayat" to "Riwayat order disimpan secara lokal. Menghapus data aplikasi dapat menghapus riwayat tersebut.",
        "Privasi" to "Aplikasi tidak meminta KTP, foto wajah, rekening bank, seed phrase, atau kata sandi.",
        "Tidak ada uang sungguhan" to "Kredit latihan tidak dapat dibeli, ditarik, ditransfer, atau ditukar menjadi uang.",
        "Konfirmasi akun" to "Dengan menyelesaikan pengaturan, kamu memahami bahwa semua saldo dan transaksi di aplikasi ini bersifat latihan."
    )

    private val creditChallengeSteps = listOf(
        "Ini adalah pemeriksaan pemahaman untuk akun latihan, bukan verifikasi umur 18+ atau identitas resmi.",
        "Satoshi Practice bukan exchange, broker, bank, atau dompet Bitcoin sungguhan.",
        "Semua nominal Rp di menu ini adalah satuan kredit virtual untuk latihan.",
        "Tidak ada uang, Bitcoin, atau aset sungguhan yang dikirim atau diterima.",
        "Aplikasi tidak memproses transfer bank, kartu, QRIS, e-wallet, atau pembayaran lain.",
        "Jangan mengirim uang kepada siapa pun untuk memperoleh kredit latihan.",
        "Aplikasi ini tidak memerlukan KTP, selfie, paspor, atau dokumen identitas.",
        "Jangan masukkan PIN, kata sandi, OTP, seed phrase, atau private key ke aplikasi.",
        "Saldo awal akun latihan adalah Rp0.",
        "Pilihan nominal dimulai dari Rp200.000 kredit virtual.",
        "Pilihan nominal tertinggi adalah Rp905.000.000 kredit virtual.",
        "Nominal yang dipilih hanya mengubah saldo latihan lokal pada perangkat ini.",
        "Semakin tinggi nominal pilihan, semakin panjang waktu tunggu kredit latihan.",
        "Waktu tunggu adalah timer aplikasi, bukan waktu penyelesaian transaksi keuangan.",
        "Perkiraan waktu dapat bergeser jika Android menunda alarm saat perangkat tidak aktif.",
        "Notifikasi hanya memberitahu bahwa kredit latihan lokal telah ditambahkan.",
        "Kredit latihan tidak memiliki nilai tunai atau nilai tukar.",
        "Kredit latihan tidak dapat ditarik, diuangkan, ditransfer, atau dipindahtangankan.",
        "Saldo latihan disimpan secara lokal di perangkat dan bukan rekening online.",
        "Menghapus data aplikasi dapat menghapus saldo serta riwayat latihan.",
        "Harga BTC/IDR berasal dari sumber data pasar publik dan bisa mengalami keterlambatan.",
        "Grafik tidak menjamin harga berikutnya dan bukan saran investasi.",
        "Tombol BELI hanya mencatat pembelian Bitcoin latihan.",
        "Tombol JUAL hanya mencatat penjualan Bitcoin latihan.",
        "Tidak ada order yang dikirim ke bursa kripto atau pihak ketiga.",
        "Saya memahami bahwa seluruh proses ini hanya menambah kredit latihan virtual."
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        // Reset balances created by the older starter build: every account now starts at zero.
        if (!prefs.getBoolean("zero_balance_migration_v3", false)) {
            prefs.edit()
                .putString("practice_balance", "0.0")
                .putString("btc_holding", "0.0")
                .putString("order_history", "[]")
                .putBoolean("zero_balance_migration_v3", true)
                .apply()
        }
        val savedCreditAmount = prefs.getLong("selected_practice_credit_amount", practiceCreditOptions.first())
        selectedPracticeCredit = if (practiceCreditOptions.contains(savedCreditAmount)) {
            savedCreditAmount
        } else {
            practiceCreditOptions.first()
        }
        virtualBalance = prefs.getString("practice_balance", "0")?.toDoubleOrNull() ?: 0.0
        btcHolding = prefs.getString("btc_holding", "0")?.toDoubleOrNull() ?: 0.0
        buyByBtc = prefs.getBoolean("buy_as_btc", false)
        sellByBtc = prefs.getBoolean("sell_as_btc", true)
        currentPrice = prefs.getString("last_price", "0")?.toDoubleOrNull() ?: 0.0
        marketReferencePrice = prefs.getString("market_reference_price", "0")?.toDoubleOrNull()
            ?.takeIf { it > 0.0 } ?: currentPrice
        marketFresh = marketReferencePrice > 0.0
        change24h = prefs.getString("last_change", "0")?.toDoubleOrNull() ?: 0.0
        upTapCount = prefs.getInt("up_tap_count", 0).coerceIn(0, 49)
        manualPriceBoostIdr = prefs.getString("manual_price_boost_idr", "0")
            ?.toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0.0 } ?: 0.0
        // The display name is mandatory. Users from earlier builds who skipped it
        // are routed back to the name step once after updating.
        val savedDisplayName = prefs.getString("display_name", "")?.trim().orEmpty()
        val onboardingWasCompleted = prefs.getBoolean("onboarding_completed", false)
        val savedOnboardingStep = prefs.getInt("onboarding_step", 0)
        if (savedDisplayName.isBlank() && (onboardingWasCompleted || savedOnboardingStep > 1)) {
            prefs.edit()
                .putBoolean("onboarding_completed", false)
                .putInt("onboarding_step", 1)
                .apply()
        }

        // Discard the old real-ticker-only line and migrate to the clearly labeled
        // second-by-second practice-volatility chart introduced in this version.
        if (prefs.getBoolean("practice_volatility_chart_v2", false)) {
            loadCachedChart()
        } else {
            pricePoints.clear()
            prefs.edit().putBoolean("practice_volatility_chart_v2", true).apply()
        }
        // Restore the exact same price used by the visible chart so the order panel,
        // portfolio value, and chart cannot start from different prices.
        if (pricePoints.isNotEmpty()) currentPrice = pricePoints.last()
        loadRecords()

        if (!prefs.getBoolean("onboarding_completed", false)) {
            onboardingIndex = prefs.getInt("onboarding_step", 0).coerceIn(0, onboardingSteps.lastIndex)
            buildOnboarding()
        } else {
            buildScreen()
            updatePortfolio()
            renderHistory()
            if (currentPrice > 0.0) {
                priceText.text = formatIdr(currentPrice)
                changeText.text = formatChange(change24h)
                changeText.setTextColor(if (change24h >= 0) green else red)
                lastMarketStamp = "Harga acuan tersimpan"
                nextQuoteAt = System.currentTimeMillis() + quoteIntervalMs
                if (pricePoints.isEmpty()) seedPracticeChart(effectivePracticeAnchor())
                pricePoints.lastOrNull()?.let { currentPrice = it }
                priceText.text = formatIdr(currentPrice)
                chartView.setValues(pricePoints, animate = false)
            }
            fetchMarketData()
            handler.postDelayed(refreshRunnable, 1_000L)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshRunnable)
        super.onDestroy()
    }

    private fun buildOnboarding() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(34), dp(22), dp(28))
        }
        scroll.addView(root, FrameLayout.LayoutParams(-1, -1))
        setContentView(scroll)

        root.addView(label("SATOSHI PRACTICE", 12f, gold, true))
        root.addView(gap(28))
        root.addView(label("PENGATURAN AKUN LATIHAN", 10f, muted, true))
        root.addView(gap(10))
        root.addView(label("Langkah ${onboardingIndex + 1} dari ${onboardingSteps.size}", 13f, gold, true))
        root.addView(gap(10))

        val progressTrack = View(this).apply {
            background = rounded(panelAlt, 20)
        }
        val progressFill = View(this).apply { background = rounded(gold, 20) }
        val progressFrame = FrameLayout(this)
        progressFrame.addView(progressTrack, FrameLayout.LayoutParams(-1, dp(6)))
        val fillWidth = (resources.displayMetrics.widthPixels - dp(44)) * (onboardingIndex + 1) / onboardingSteps.size
        progressFrame.addView(progressFill, FrameLayout.LayoutParams(fillWidth, dp(6)))
        root.addView(progressFrame, matchWrap())
        root.addView(gap(28))

        val card = card().apply { setPadding(dp(18), dp(22), dp(18), dp(22)) }
        val step = onboardingSteps[onboardingIndex]
        card.addView(label(step.first, 23f, white, true))
        card.addView(label(step.second, 14f, muted, false).apply {
            setPadding(0, dp(14), 0, dp(8))
            setLineSpacing(dp(4).toFloat(), 1f)
        })
        if (onboardingIndex == 1) {
            val nameInput = EditText(this).apply {
                hint = "Masukkan nama tampilan (wajib)"
                setHintTextColor(muted)
                setTextColor(white)
                textSize = 15f
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
                setPadding(dp(13), dp(12), dp(13), dp(12))
                background = rounded(panelAlt, 10)
                setText(prefs.getString("display_name", "") ?: "")
            }
            onboardingNameInput = nameInput
            card.addView(nameInput, matchWrap())
        } else {
            onboardingNameInput = null
        }
        root.addView(card, matchWrap())
        root.addView(gap(18))

        root.addView(label("Tidak perlu email, nomor telepon, KTP, rekening, atau data identitas.", 11f, muted, false))
        root.addView(gap(24))
        val next = button(
            if (onboardingIndex == onboardingSteps.lastIndex) "SELESAIKAN PENGATURAN" else "SAYA PAHAM, LANJUT",
            gold,
            Color.BLACK
        )
        next.setOnClickListener {
            if (onboardingIndex == 1) {
                val nickname = onboardingNameInput?.text?.toString()?.trim().orEmpty().take(24)
                if (nickname.isBlank()) {
                    onboardingNameInput?.error = "Nama tampilan wajib diisi"
                    onboardingNameInput?.requestFocus()
                    toast("Isi nama tampilan dulu sebelum lanjut.")
                    return@setOnClickListener
                }
                prefs.edit().putString("display_name", nickname).apply()
            }
            if (onboardingIndex == onboardingSteps.lastIndex) {
                prefs.edit()
                    .putBoolean("onboarding_completed", true)
                    .putInt("onboarding_step", 0)
                    .apply()
                buildScreen()
                updatePortfolio()
                renderHistory()
                fetchMarketData()
                handler.postDelayed(refreshRunnable, 1_000L)
            } else {
                onboardingIndex += 1
                prefs.edit().putInt("onboarding_step", onboardingIndex).apply()
                buildOnboarding()
            }
        }
        root.addView(next, LinearLayout.LayoutParams(-1, dp(52)))
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(28))
        }
        scroll.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        setContentView(scroll)

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brandColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandColumn.addView(label("SATOSHI", 23f, white, true))
        val displayName = prefs.getString("display_name", "")?.trim().orEmpty()
        brandColumn.addView(label(
            if (displayName.isBlank()) "BITCOIN MARKET · BTC/IDR" else "HALO, ${displayName.uppercase(Locale("id", "ID"))} · BTC/IDR",
            10f,
            muted,
            true
        ).apply { letterSpacing = 0.08f })
        header.addView(brandColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val coinMark = TextView(this).apply {
            text = "₿"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(gold, 50)
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        header.addView(coinMark)
        content.addView(header)
        content.addView(gap(14))

        // Clear practice-account notice
        val notice = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.rgb(43, 34, 22), 11)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val noticeMark = TextView(this).apply {
            text = "●"
            textSize = 12f
            setTextColor(gold)
            setPadding(0, 0, dp(9), 0)
        }
        val noticeCopy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        noticeCopy.addView(label("INFORMASI SALDO", 10f, gold, true))
        noticeCopy.addView(label("Saldo dan order memakai kredit virtual, bukan uang sungguhan.", 10f, muted, false).apply {
            setPadding(0, dp(3), 0, 0)
        })
        notice.addView(noticeMark)
        notice.addView(noticeCopy, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(notice, matchWrap())
        content.addView(gap(14))

        // BTC market panel and moving chart
        val marketCard = card().apply { setPadding(dp(15), dp(15), dp(15), dp(13)) }
        val marketTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val marketTitles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        marketTitles.addView(label("BTC / IDR", 16f, white, true))
        marketTitles.addView(label("Harga grafik menentukan order latihan · acuan Indodax", 10f, muted, false).apply {
            setPadding(0, dp(3), 0, 0)
        })
        marketTop.addView(marketTitles, LinearLayout.LayoutParams(0, -2, 1f))
        refreshButton = button("↻", panelAlt, white).apply {
            minWidth = dp(42)
            minHeight = dp(40)
            minimumHeight = dp(40)
            setOnClickListener { fetchMarketData() }
        }
        marketTop.addView(refreshButton)
        marketCard.addView(marketTop)

        val priceRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(15), 0, dp(4))
        }
        priceText = label("Mengambil harga...", 25f, white, true)
        priceText.maxLines = 1
        priceText.setSingleLine(true)
        priceText.textSize = 21f
        priceRow.addView(priceText, LinearLayout.LayoutParams(0, -2, 1f))
        val upButton = button("UP $upTapCount/50", panelAlt, gold).apply {
            textSize = 10f
            minWidth = dp(82)
            minimumWidth = dp(82)
            minHeight = dp(42)
            minimumHeight = dp(42)
            setOnClickListener { handleUpTap(this) }
        }
        priceRow.addView(upButton, LinearLayout.LayoutParams(dp(88), dp(42)).apply {
            marginStart = dp(8)
        })
        marketCard.addView(priceRow)
        changeText = label("Perubahan 24 jam: --", 12f, green, true)
        marketCard.addView(changeText)

        val chartHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, dp(4))
        }
        chartHeader.addView(label("PERGERAKAN BTC/IDR", 10f, gold, true), LinearLayout.LayoutParams(0, -2, 1f))
        chartHeader.addView(label("90 DETIK", 10f, gold, true))
        marketCard.addView(chartHeader)

        chartView = MarketChartView()
        marketCard.addView(chartView, LinearLayout.LayoutParams(-1, dp(214)))

        val legend = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        legend.addView(dot(green))
        legend.addView(label("Naik", 10f, muted, false).apply { setPadding(dp(5), 0, dp(13), 0) })
        legend.addView(dot(red))
        legend.addView(label("Turun", 10f, muted, false).apply { setPadding(dp(5), 0, 0, 0) })
        marketCard.addView(legend)
        marketStatusText = label("Harga grafik dan order bergerak bersama setiap detik · ticker Indodax sebagai acuan", 10f, muted, false).apply {
            setPadding(0, dp(7), 0, 0)
        }
        marketCard.addView(marketStatusText)
        content.addView(marketCard, matchWrap())

        // Fast buy/sell controls stay directly under the chart so users can act
        // without scrolling down to the detailed order form. Enter the amount below first.
        val chartActionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, dp(4))
        }
        val chartBuyButton = button("BELI BTC", green, Color.BLACK).apply {
            minHeight = dp(53)
            minimumHeight = dp(53)
            setOnClickListener {
                activeOrderIsBuy = true
                updateOrderModeInfo()
                submitOrder(isBuy = true)
            }
        }
        val chartSellButton = button("JUAL BTC", red, Color.WHITE).apply {
            minHeight = dp(53)
            minimumHeight = dp(53)
            setOnClickListener {
                activeOrderIsBuy = false
                updateOrderModeInfo()
                submitOrder(isBuy = false)
            }
        }
        chartActionRow.addView(chartBuyButton, LinearLayout.LayoutParams(0, dp(53), 1f).apply {
            marginEnd = dp(5)
        })
        chartActionRow.addView(chartSellButton, LinearLayout.LayoutParams(0, dp(53), 1f).apply {
            marginStart = dp(5)
        })
        content.addView(chartActionRow, matchWrap())
        content.addView(gap(8))

        // RTP panel: heuristic scenario ranges, not guaranteed outcomes or investment advice.
        val rtpCard = card().apply { setPadding(dp(15), dp(14), dp(15), dp(14)) }
        rtpCard.addView(label("RTP · PERKIRAAN TREN", 12f, white, true))
        rtpCard.addView(label(
            "Skenario berdasarkan perubahan BTC/IDR 24 jam. Rentang bisa meleset dan bukan jaminan profit.",
            10f, muted, false
        ).apply { setPadding(0, dp(5), 0, dp(10)) })
        rtpContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rtpCard.addView(rtpContainer)
        content.addView(rtpCard, matchWrap())
        content.addView(gap(12))

        // Detailed order inputs remain below the quick-action buttons placed directly under the chart.
        val orderCard = card().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
        val orderHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        orderHeader.addView(label("BUAT ORDER", 12f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        orderHeader.addView(label("BTC / IDR", 10f, muted, true))
        orderCard.addView(orderHeader)

        val buyModeHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(13), 0, dp(6))
        }
        buyModeHeader.addView(label("Beli Sebagai", 11f, muted, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        buyAsButton = button(if (buyByBtc) "BTC  ▾" else "Saldo (IDR)  ▾", panelAlt, white).apply {
            minWidth = dp(142)
            setOnClickListener { showOrderModeChooser(isBuy = true) }
        }
        buyModeHeader.addView(buyAsButton)
        orderCard.addView(buyModeHeader)

        val sellModeHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(6))
        }
        sellModeHeader.addView(label("Jual Sebagai", 11f, muted, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        sellAsButton = button(if (sellByBtc) "BTC  ▾" else "Saldo (IDR)  ▾", panelAlt, white).apply {
            minWidth = dp(142)
            setOnClickListener { showOrderModeChooser(isBuy = false) }
        }
        sellModeHeader.addView(sellAsButton)
        orderCard.addView(sellModeHeader)

        orderUnitInfoText = label("", 10f, muted, false).apply {
            setLineSpacing(dp(2).toFloat(), 1f)
            setPadding(0, dp(4), 0, dp(10))
        }
        orderCard.addView(orderUnitInfoText)

        amountLabelText = label("Nominal transaksi", 10f, muted, true).apply {
            setPadding(0, 0, 0, dp(7))
        }
        orderCard.addView(amountLabelText)
        amountInput = EditText(this).apply {
            hint = "Isi nominal sesuai pilihan BELI atau JUAL"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(panelAlt, 10)
        }
        orderCard.addView(amountInput, matchWrap())
        orderEstimateText = label("Perkiraan BTC, nilai Rupiah, biaya, dan sisa saldo akan muncul di sini.", 10f, muted, false).apply {
            setPadding(0, dp(9), 0, dp(10))
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        orderCard.addView(orderEstimateText)
        amountInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateOrderEstimate()
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        orderCard.addView(label("Biaya latihan 0,1%. Untuk BELI dengan satuan IDR, nominal yang dimasukkan sudah termasuk biaya. Untuk JUAL dengan satuan IDR, nominal adalah perkiraan saldo bersih yang ingin diterima.", 10f, muted, false).apply {
            setPadding(0, dp(2), 0, dp(12))
            setLineSpacing(dp(2).toFloat(), 1f)
        })

        orderCard.addView(label("Tombol BELI BTC dan JUAL BTC tersedia tepat di bawah grafik. Isi nominal di panel ini, lalu gunakan tombol cepat tersebut saat diperlukan.", 10f, muted, false).apply {
            setPadding(0, dp(10), 0, 0)
        })
        content.addView(orderCard, matchWrap())
        updateOrderModeInfo()
        content.addView(gap(12))

        // Account information below market and trade controls
        val balanceCard = card()
        val balanceHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        balanceHeader.addView(label("SALDO IDR", 10f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        balanceHeader.addView(label("KREDIT VIRTUAL", 9f, gold, true))
        balanceCard.addView(balanceHeader)
        balanceText = label("Rp 0", 25f, white, true).apply {
            setPadding(0, dp(8), 0, dp(3))
        }
        balanceCard.addView(balanceText)
        balanceCard.addView(label("Saldo tersedia untuk order latihan", 10f, muted, false))
        creditSelectionText = label("Nominal kredit latihan: ${formatIdr(selectedPracticeCredit.toDouble())}", 12f, white, true).apply {
            setPadding(0, dp(14), 0, dp(7))
        }
        balanceCard.addView(creditSelectionText)
        creditSelectButton = button("PILIH NOMINAL KREDIT", panelAlt, white).apply {
            setOnClickListener { showPracticeCreditPicker() }
        }
        balanceCard.addView(creditSelectButton, matchWrap())
        creditEstimateText = label("Estimasi tersedia: ${formatDelay(creditDelayMinutes(selectedPracticeCredit))} setelah langkah pemahaman selesai. Kredit ini virtual dan tidak memakai uang.", 10f, muted, false).apply {
            setPadding(0, dp(8), 0, dp(5))
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        balanceCard.addView(creditEstimateText)
        creditStatusText = label("Kredit latihan belum ditambahkan.", 10f, muted, false).apply {
            setPadding(0, dp(9), 0, dp(8))
        }
        balanceCard.addView(creditStatusText)
        creditButton = button("MULAI 26 LANGKAH PEMAHAMAN", gold, Color.BLACK).apply {
            setOnClickListener { startCreditChallenge() }
        }
        balanceCard.addView(creditButton, matchWrap())
        content.addView(balanceCard, matchWrap())
        content.addView(gap(12))

        val holdingCard = card()
        holdingCard.addView(label("PORTOFOLIO SAYA", 11f, muted, true))
        val holdingRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val holdingColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        btcText = label("0.00000000 BTC", 19f, white, true)
        holdingValueText = label("Nilai perkiraan: Rp 0", 11f, muted, false).apply {
            setPadding(0, dp(4), 0, 0)
        }
        holdingColumn.addView(btcText)
        holdingColumn.addView(holdingValueText)
        holdingRow.addView(holdingColumn, LinearLayout.LayoutParams(0, -2, 1f))
        holdingRow.addView(label("₿", 27f, gold, true))
        holdingCard.addView(holdingRow)
        content.addView(holdingCard, matchWrap())
        content.addView(gap(12))

        val historyCard = card()
        historyCard.addView(label("RIWAYAT ORDER", 12f, white, true))
        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        historyCard.addView(historyContainer)
        content.addView(historyCard, matchWrap())
        content.addView(gap(15))
        content.addView(label("SATOSHI PRACTICE · VERSION 0.4.6", 9f, muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        })
    }

    private fun dot(color: Int): View = View(this).apply {
        background = rounded(color, 20)
        layoutParams = LinearLayout.LayoutParams(dp(7), dp(7))
    }

    private fun showPracticeCreditPicker() {
        if (prefs.getBoolean("practice_credit_pending", false)) {
            toast("Kredit latihan sedang diproses. Tunggu sampai selesai sebelum memilih nominal baru.")
            return
        }
        val labels = practiceCreditOptions.map { amount ->
            "${formatIdr(amount.toDouble())}  ·  ${formatDelay(creditDelayMinutes(amount))}"
        }.toTypedArray()
        val selectedIndex = practiceCreditOptions.indexOf(selectedPracticeCredit).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("PILIH NOMINAL KREDIT LATIHAN")
            .setSingleChoiceItems(labels, selectedIndex) { dialog, which ->
                selectedPracticeCredit = practiceCreditOptions[which]
                prefs.edit().putLong("selected_practice_credit_amount", selectedPracticeCredit).apply()
                updateCreditUi()
                dialog.dismiss()
            }
            .setNegativeButton("TUTUP", null)
            .show()
    }

    private fun creditDelayMinutes(amount: Long): Int {
        val index = practiceCreditOptions.indexOf(amount).coerceAtLeast(0)
        val lastIndex = (practiceCreditOptions.size - 1).coerceAtLeast(1)
        // A strictly increasing preview: 2 minutes at the minimum and 180 at the maximum.
        return 2 + (index * 178 / lastIndex)
    }

    private fun formatDelay(totalMinutes: Int): String {
        return if (totalMinutes < 60) {
            "$totalMinutes menit"
        } else {
            val hours = totalMinutes / 60
            val minutes = totalMinutes % 60
            if (minutes == 0) "$hours jam" else "$hours jam $minutes menit"
        }
    }

    private fun startCreditChallenge() {
        if (prefs.getBoolean("practice_credit_pending", false)) {
            toast("Kredit latihan sedang diproses.")
            return
        }
        showCreditChallengeStep(0)
    }

    private fun showCreditChallengeStep(index: Int) {
        if (index >= creditChallengeSteps.size) {
            schedulePracticeCredit()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("PEMAHAMAN KREDIT LATIHAN · ${index + 1}/${creditChallengeSteps.size}")
            .setMessage(creditChallengeSteps[index])
            .setNegativeButton("BATAL", null)
            .setPositiveButton(if (index == creditChallengeSteps.lastIndex) "SELESAI" else "SAYA PAHAM") { _, _ ->
                showCreditChallengeStep(index + 1)
            }
            .show()
    }

    private fun schedulePracticeCredit() {
        val delayMinutes = creditDelayMinutes(selectedPracticeCredit)
        val dueAt = System.currentTimeMillis() + delayMinutes * 60_000L
        prefs.edit()
            .putBoolean("practice_credit_pending", true)
            .putLong("practice_credit_due_at", dueAt)
            .putString("practice_credit_amount", selectedPracticeCredit.toString())
            .apply()

        val alarmIntent = Intent(this, PracticeCreditReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            PracticeCreditReceiver.REQUEST_CODE,
            alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pendingIntent)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7331)
        }
        updateCreditUi()
        toast("Kredit latihan virtual dijadwalkan. Perkiraan tersedia dalam ${formatDelay(delayMinutes)}.")
    }

    private fun updateCreditUi() {
        if (!::creditStatusText.isInitialized || !::creditButton.isInitialized ||
            !::creditSelectionText.isInitialized || !::creditEstimateText.isInitialized ||
            !::creditSelectButton.isInitialized
        ) return

        val storedBalance = prefs.getString("practice_balance", "0")?.toDoubleOrNull() ?: 0.0
        if (storedBalance.isFinite() && storedBalance != virtualBalance) {
            virtualBalance = storedBalance
            if (::balanceText.isInitialized) balanceText.text = formatIdr(virtualBalance)
        }

        creditSelectionText.text = "Nominal kredit latihan: ${formatIdr(selectedPracticeCredit.toDouble())}"
        val estimate = formatDelay(creditDelayMinutes(selectedPracticeCredit))
        creditEstimateText.text = "Estimasi tersedia: $estimate setelah 26 langkah pemahaman selesai. Timer ini hanya untuk kredit virtual; tidak ada pembayaran atau deposit uang."

        val pending = prefs.getBoolean("practice_credit_pending", false)
        if (pending) {
            val dueAt = prefs.getLong("practice_credit_due_at", System.currentTimeMillis())
            val remaining = ((dueAt - System.currentTimeMillis()).coerceAtLeast(0L) + 999L) / 1000L
            val hours = remaining / 3600L
            val minutes = (remaining % 3600L) / 60L
            val seconds = remaining % 60L
            val countdown = if (hours > 0L) {
                "${hours}j ${minutes}m ${seconds}d"
            } else {
                "${minutes}:${String.format(Locale.US, "%02d", seconds)}"
            }
            val pendingAmount = prefs.getString("practice_credit_amount", selectedPracticeCredit.toString())
                ?.toLongOrNull() ?: selectedPracticeCredit
            creditStatusText.text = "Kredit virtual ${formatIdr(pendingAmount.toDouble())} sedang diproses · $countdown"
            creditButton.text = "KREDIT LATIHAN SEDANG DIPROSES"
            creditButton.isEnabled = false
            creditButton.alpha = 0.55f
            creditSelectButton.isEnabled = false
            creditSelectButton.alpha = 0.55f
        } else {
            val claimCount = prefs.getInt("practice_credit_claim_count", 0)
            creditStatusText.text = if (claimCount > 0) {
                "Kredit latihan sebelumnya sudah ditambahkan. Kamu bisa memilih nominal lain untuk sesi latihan berikutnya."
            } else {
                "Saldo awal Rp0. Pilih salah satu dari ${practiceCreditOptions.size} nominal kredit virtual, lalu selesaikan 26 langkah pemahaman."
            }
            creditButton.text = "MULAI 26 LANGKAH PEMAHAMAN"
            creditButton.isEnabled = true
            creditButton.alpha = 1f
            creditSelectButton.isEnabled = true
            creditSelectButton.alpha = 1f
        }
    }

    private fun showOrderModeChooser(isBuy: Boolean) {
        val title = if (isBuy) "Beli Sebagai" else "Jual Sebagai"
        val options = arrayOf("BTC — jumlah Bitcoin", "Saldo (IDR) — nilai Rupiah")
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(options) { _, which ->
                val useBtc = (which == 0)
                activeOrderIsBuy = isBuy
                if (isBuy) {
                    buyByBtc = useBtc
                    prefs.edit().putBoolean("buy_as_btc", buyByBtc).apply()
                } else {
                    sellByBtc = useBtc
                    prefs.edit().putBoolean("sell_as_btc", sellByBtc).apply()
                }
                updateOrderModeInfo()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateOrderModeInfo() {
        if (!::buyAsButton.isInitialized || !::sellAsButton.isInitialized ||
            !::orderUnitInfoText.isInitialized || !::amountLabelText.isInitialized
        ) return

        val buyMode = if (buyByBtc) "BTC" else "Saldo (IDR)"
        val sellMode = if (sellByBtc) "BTC" else "Saldo (IDR)"
        buyAsButton.text = "$buyMode  ▾"
        sellAsButton.text = "$sellMode  ▾"

        val buyMaximumBtc = if (currentPrice > 0.0) {
            virtualBalance / (currentPrice * 1.001)
        } else 0.0
        val sellMaximumIdrNet = if (currentPrice > 0.0) {
            btcHolding * currentPrice * 0.999
        } else 0.0
        val buyDescription = if (buyByBtc) {
            "masukkan jumlah BTC yang ingin dibeli (saldo tersedia ${formatIdr(virtualBalance)}; maksimum sekitar ${formatBtc(buyMaximumBtc)} BTC)"
        } else {
            "masukkan total anggaran Rupiah termasuk biaya (saldo tersedia ${formatIdr(virtualBalance)})"
        }
        val sellDescription = if (sellByBtc) {
            "masukkan jumlah BTC yang ingin dijual (tersedia ${formatBtc(btcHolding)} BTC)"
        } else {
            val maxText = if (currentPrice > 0.0) formatIdr(sellMaximumIdrNet) else "menunggu harga BTC"
            "masukkan target saldo Rupiah bersih setelah biaya (maksimum sekitar $maxText)"
        }
        orderUnitInfoText.text = "BELI ($buyMode): $buyDescription.\nJUAL ($sellMode): $sellDescription."

        if (::amountInput.isInitialized) {
            val activeMode = if (activeOrderIsBuy) buyMode else sellMode
            val activeAction = if (activeOrderIsBuy) "BELI" else "JUAL"
            amountLabelText.text = "Nominal transaksi · $activeAction ($activeMode)"
            amountInput.hint = when {
                activeOrderIsBuy && buyByBtc -> "Contoh BELI: 0.00050000 BTC"
                activeOrderIsBuy && !buyByBtc -> "Contoh BELI: 200000 IDR (termasuk biaya)"
                !activeOrderIsBuy && sellByBtc -> "Contoh JUAL: 0.00050000 BTC"
                else -> "Contoh JUAL: 200000 IDR (bersih diterima)"
            }
        }
        updateOrderEstimate()
    }

    private fun updateOrderEstimate() {
        if (!::orderEstimateText.isInitialized || !::amountInput.isInitialized) return
        val amount = amountInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (amount == null || !amount.isFinite() || amount <= 0.0) {
            orderEstimateText.text = "Perkiraan jumlah BTC, nilai Rupiah, biaya 0,1%, dan saldo setelah order akan tampil saat nominal diisi."
            orderEstimateText.setTextColor(muted)
            return
        }
        if (currentPrice <= 0.0) {
            orderEstimateText.text = "Menunggu harga BTC/IDR untuk menghitung perkiraan order."
            orderEstimateText.setTextColor(muted)
            return
        }

        val feeRate = 0.001
        val lines = mutableListOf<String>()
        lines += "Harga grafik/order saat ini: ${formatIdr(currentPrice)} per BTC"
        var canProceed = marketFresh
        if (!marketFresh) lines += "Belum ada acuan BTC/IDR. Order akan tersedia setelah harga awal berhasil dimuat."
        if (activeOrderIsBuy) {
            val grossValue: Double
            val feeValue: Double
            val btcAmount: Double
            val totalSpend: Double
            if (buyByBtc) {
                btcAmount = amount
                grossValue = btcAmount * currentPrice
                feeValue = grossValue * feeRate
                totalSpend = grossValue + feeValue
            } else {
                // IDR amount is the full budget, fee included, so using the exact
                // available balance remains possible and cannot fail due to an extra fee.
                totalSpend = amount
                grossValue = totalSpend / (1.0 + feeRate)
                feeValue = totalSpend - grossValue
                btcAmount = grossValue / currentPrice
            }
            val remaining = virtualBalance - totalSpend
            lines += "Perkiraan BTC diterima: ${formatBtc(btcAmount)} BTC"
            lines += "Nilai BTC: ${formatIdr(grossValue)} · Biaya: ${formatIdr(feeValue)}"
            lines += "Total saldo terpakai: ${formatIdr(totalSpend)} · Sisa saldo: ${formatIdr(remaining.coerceAtLeast(0.0))}"
            if (totalSpend > virtualBalance + 1e-7) {
                canProceed = false
                lines += "Saldo kurang ${formatIdr(totalSpend - virtualBalance)}. Maksimum anggaran: ${formatIdr(virtualBalance)}."
            }
        } else {
            val btcAmount: Double
            val grossValue: Double
            val feeValue: Double
            val netReceive: Double
            if (sellByBtc) {
                btcAmount = amount
                grossValue = btcAmount * currentPrice
                feeValue = grossValue * feeRate
                netReceive = grossValue - feeValue
            } else {
                // IDR amount is the desired net proceeds after fee.
                netReceive = amount
                grossValue = netReceive / (1.0 - feeRate)
                feeValue = grossValue - netReceive
                btcAmount = grossValue / currentPrice
            }
            val remainingBtc = btcHolding - btcAmount
            lines += "Perkiraan BTC dijual: ${formatBtc(btcAmount)} BTC"
            lines += "Nilai bruto: ${formatIdr(grossValue)} · Biaya: ${formatIdr(feeValue)}"
            lines += "Saldo IDR diterima: ${formatIdr(netReceive)} · Sisa BTC: ${formatBtc(remainingBtc.coerceAtLeast(0.0))}"
            if (btcAmount > btcHolding + 1e-12) {
                canProceed = false
                val maxNet = btcHolding * currentPrice * (1.0 - feeRate)
                lines += "BTC tidak cukup. Maksimum saldo bersih yang dapat diterima: ${formatIdr(maxNet)}."
            }
        }
        orderEstimateText.text = lines.joinToString("\n")
        orderEstimateText.setTextColor(if (canProceed) muted else red)
    }

    private fun submitOrder(isBuy: Boolean) {
        activeOrderIsBuy = isBuy
        updateOrderModeInfo()
        val amount = amountInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (amount == null || !amount.isFinite() || amount <= 0.0) {
            toast("Masukkan nominal yang valid sesuai satuan yang dipilih.")
            return
        }
        if (!marketFresh || currentPrice <= 0.0) {
            toast("Harga awal BTC/IDR belum tersedia. Sambungkan internet untuk memuat acuan pertama.")
            return
        }

        val feeRate = 0.001
        if (isBuy) {
            val btcBought: Double
            val grossCostIdr: Double
            val totalCost: Double
            if (buyByBtc) {
                btcBought = amount
                grossCostIdr = btcBought * currentPrice
                totalCost = grossCostIdr * (1.0 + feeRate)
            } else {
                // In IDR mode, amount is the total budget with fee already included.
                totalCost = amount
                grossCostIdr = totalCost / (1.0 + feeRate)
                btcBought = grossCostIdr / currentPrice
            }
            if (!btcBought.isFinite() || !grossCostIdr.isFinite() ||
                !totalCost.isFinite() || totalCost > virtualBalance + 1e-7
            ) {
                val maxBtc = if (currentPrice > 0.0) virtualBalance / (currentPrice * (1.0 + feeRate)) else 0.0
                toast("Saldo tidak cukup. Anggaran maksimum ${formatIdr(virtualBalance)} atau sekitar ${formatBtc(maxBtc)} BTC.")
                updateOrderEstimate()
                return
            }
            val feeValue = totalCost - grossCostIdr
            virtualBalance = (virtualBalance - totalCost).coerceAtLeast(0.0)
            btcHolding += btcBought
            records.add(0, TradeRecord("BELI", grossCostIdr, btcBought, currentPrice, System.currentTimeMillis()))
            toast("Beli latihan berhasil: ${formatBtc(btcBought)} BTC · biaya ${formatIdr(feeValue)}.")
        } else {
            // In IDR mode, amount is the desired net Rupiah proceeds after fee.
            val btcToSell = if (sellByBtc) amount else amount / (currentPrice * (1.0 - feeRate))
            if (!btcToSell.isFinite() || btcToSell > btcHolding + 1e-12) {
                if (sellByBtc) {
                    toast("BTC latihan tidak cukup. Tersedia ${formatBtc(btcHolding)} BTC.")
                } else {
                    val maximumIdr = btcHolding * currentPrice * (1.0 - feeRate)
                    toast("Target melebihi saldo BTC. Maksimum bersih sekitar ${formatIdr(maximumIdr)}.")
                }
                updateOrderEstimate()
                return
            }
            val actualBtcToSell = min(btcToSell, btcHolding)
            val grossValueIdr = actualBtcToSell * currentPrice
            val feeValue = grossValueIdr * feeRate
            val netProceeds = grossValueIdr - feeValue
            virtualBalance += netProceeds
            btcHolding = (btcHolding - actualBtcToSell).coerceAtLeast(0.0)
            records.add(0, TradeRecord("JUAL", grossValueIdr, actualBtcToSell, currentPrice, System.currentTimeMillis()))
            toast("Jual latihan berhasil: ${formatIdr(netProceeds)} diterima · biaya ${formatIdr(feeValue)}.")
        }

        while (records.size > 30) records.removeAt(records.lastIndex)
        prefs.edit()
            .putString("practice_balance", virtualBalance.toString())
            .putString("btc_holding", btcHolding.toString())
            .putString("order_history", serializeRecords())
            .apply()
        amountInput.setText("")
        updatePortfolio()
        renderHistory()
    }

    private fun fetchMarketData() {
        if (fetching) return
        fetching = true
        refreshButton.isEnabled = false
        marketStatusText.text = "Mengambil ticker BTC/IDR..."

        thread(name = "btc-market-fetch") {
            try {
                // Indodax's documented public summaries endpoint includes the BTC/IDR
                // last price and the 24-hour reference price. One request per second
                // is 60 requests/minute, below the documented 180 requests/minute cap.
                val summary = requestJson("https://indodax.com/api/summaries")
                val ticker = summary.getJSONObject("tickers").getJSONObject("btc_idr")
                val newPrice = ticker.optString("last", "0").toDoubleOrNull() ?: 0.0
                val previousPrice = summary.getJSONObject("prices_24h")
                    .optString("btcidr", "0").toDoubleOrNull() ?: 0.0
                if (newPrice <= 0.0) throw IllegalStateException("Harga BTC/IDR tidak valid")
                val newChange = if (previousPrice > 0.0) {
                    ((newPrice - previousPrice) / previousPrice) * 100.0
                } else {
                    0.0
                }

                runOnUiThread {
                    val now = System.currentTimeMillis()
                    marketReferencePrice = newPrice
                    change24h = newChange
                    marketFresh = true

                    // The first successful ticker response seeds the chart. After that,
                    // every one-second chart sample drives currentPrice and all orders.
                    if (pricePoints.isEmpty()) seedPracticeChart(effectivePracticeAnchor())
                    currentPrice = pricePoints.lastOrNull() ?: newPrice

                    prefs.edit()
                        .putString("market_reference_price", marketReferencePrice.toString())
                        .putString("last_price", currentPrice.toString())
                        .putString("last_change", change24h.toString())
                        .apply()
                    priceText.text = formatIdr(currentPrice)
                    updatePortfolio()
                    updateRtpUi()
                    updateOrderEstimate()
                    changeText.text = "Acuan pasar 24 jam: ${formatChange(change24h)}"
                    changeText.setTextColor(if (change24h >= 0.0) green else red)
                    val stamp = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date(now))
                    lastMarketStamp = "Acuan ticker Indodax · $stamp"
                    nextQuoteAt = now + quoteIntervalMs
                    marketStatusText.text = "$lastMarketStamp · harga grafik/order latihan berubah tiap 1 dtk"
                    chartView.setValues(pricePoints, animate = false)
                }
            } catch (_: Exception) {
                runOnUiThread {
                    // A previously received anchor is enough to keep the local practice
                    // market running, and its visible chart price remains tradable.
                    marketFresh = marketReferencePrice > 0.0
                    lastMarketStamp = "Ticker Indodax tidak tersedia"
                    nextQuoteAt = System.currentTimeMillis() + quoteRetryIntervalMs
                    marketStatusText.text = "$lastMarketStamp · grafik dan harga order memakai simulasi lokal pada acuan terakhir"
                    if (currentPrice <= 0.0) priceText.text = "Harga belum tersedia"
                    else priceText.text = formatIdr(currentPrice)
                    changeText.text = "Acuan pasar terputus · harga latihan tetap mengikuti grafik"
                    changeText.setTextColor(muted)
                }
            } finally {
                runOnUiThread {
                    fetching = false
                    refreshButton.isEnabled = true
                }
            }
        }
    }

    private fun updateRtpUi() {
        if (!::rtpContainer.isInitialized) return
        val now = System.currentTimeMillis()
        // Avoid rebuilding the forecast rows every second; refresh the projection periodically.
        if (rtpContainer.childCount > 0 && now - lastRtpUiUpdateAt < 15_000L) return
        lastRtpUiUpdateAt = now
        rtpContainer.removeAllViews()
        if (currentPrice <= 0.0) {
            rtpContainer.addView(label("Menunggu data BTC/IDR untuk menyusun perkiraan.", 10f, muted, false))
            return
        }

        val nextSixAm = java.util.Calendar.getInstance().apply {
            timeInMillis = now
            set(java.util.Calendar.HOUR_OF_DAY, 6)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (timeInMillis <= now) add(java.util.Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis

        val checkpoints = listOf(
            Triple("1 JAM", now + 60L * 60L * 1000L, "Perkiraan satu jam ke depan"),
            Triple("6 JAM", now + 6L * 60L * 60L * 1000L, "Perkiraan enam jam ke depan"),
            Triple("PUKUL 06.00", nextSixAm, "Perkiraan pada pukul 06.00 berikutnya"),
            Triple("24 JAM", now + 24L * 60L * 60L * 1000L, "Perkiraan satu hari ke depan")
        )
        val timeFormat = SimpleDateFormat("dd MMM yyyy · HH:mm", Locale("id", "ID"))
        checkpoints.forEachIndexed { index, checkpoint ->
            val horizonHours = ((checkpoint.second - now).coerceAtLeast(1L)).toDouble() / 3_600_000.0
            // A deliberately conservative heuristic: only a small fraction of the
            // current 24h move is carried forward, with a widening scenario band.
            // This is not a statistically calibrated forecast.
            val centerPct = (change24h * (horizonHours / 24.0) * 0.35).coerceIn(-2.0, 2.0)
            val uncertaintyPct = (0.25 + 0.18 * kotlin.math.sqrt(horizonHours / 6.0)).coerceIn(0.25, 0.85)
            val lowerPct = centerPct - uncertaintyPct
            val upperPct = centerPct + uncertaintyPct
            val direction = when {
                centerPct > 0.03 -> "Cenderung naik"
                centerPct < -0.03 -> "Cenderung turun"
                else -> "Belum ada arah kuat"
            }
            val directionColor = when {
                centerPct > 0.03 -> green
                centerPct < -0.03 -> red
                else -> muted
            }

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(7))
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label("${checkpoint.first} · ${timeFormat.format(Date(checkpoint.second))}", 11f, white, true))
            info.addView(label(direction, 10f, directionColor, true).apply {
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val projection = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.END
            }
            projection.addView(label(formatSignedPercent(centerPct), 12f, directionColor, true).apply {
                gravity = Gravity.END
            })
            val range = "Rentang ${formatSignedPercent(lowerPct)} s/d ${formatSignedPercent(upperPct)}"
            projection.addView(label(range, 9f, muted, false).apply {
                gravity = Gravity.END
                setPadding(0, dp(2), 0, 0)
            })
            row.addView(projection)
            rtpContainer.addView(row)
            if (index < checkpoints.lastIndex) {
                rtpContainer.addView(View(this).apply { setBackgroundColor(panelAlt) },
                    LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
        val sourceStatus = if (marketFresh) "Acuan pasar tersedia" else "Menunggu acuan pasar pertama"
        rtpContainer.addView(label(
            "$sourceStatus · acuan: ${formatChange(change24h)}. Rentang adalah skenario latihan, bukan peluang teruji atau janji profit.",
            9f, muted, false
        ).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun formatSignedPercent(value: Double): String {
        val prefix = if (value >= 0.0) "+" else "−"
        return prefix + String.format(Locale.US, "%.2f%%", kotlin.math.abs(value))
    }

    private fun requestJson(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "SatoshiPractice/0.4.6 Android")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun updatePortfolio() {
        balanceText.text = formatIdr(virtualBalance)
        btcText.text = String.format(Locale.US, "%.8f BTC", btcHolding)
        val estimated = if (currentPrice > 0.0) btcHolding * currentPrice else 0.0
        holdingValueText.text = "Nilai perkiraan: ${formatIdr(estimated)}"
        updateOrderModeInfo()
        updateOrderEstimate()
        updateRtpUi()
        updateCreditUi()
    }

    private fun renderHistory() {
        historyContainer.removeAllViews()
        if (records.isEmpty()) {
            historyContainer.addView(label("Belum ada order. Transaksi latihan akan muncul di sini.", 11f, muted, false).apply {
                setPadding(0, dp(5), 0, dp(4))
            })
            return
        }
        records.take(10).forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(9), 0, dp(9))
            }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val typeColor = if (item.type == "BELI") green else gold
            details.addView(label(item.type + " BTC", 12f, typeColor, true))
            val time = SimpleDateFormat("dd MMM, HH:mm", Locale("id", "ID")).format(Date(item.time))
            details.addView(label("$time · ${String.format(Locale.US, "%.8f", item.btc)} BTC", 10f, muted, false).apply {
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(formatIdr(item.idr), 12f, white, true))
            historyContainer.addView(row)
            if (index < records.take(10).lastIndex) {
                historyContainer.addView(View(this).apply { setBackgroundColor(panelAlt) },
                    LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
    }

    private fun loadRecords() {
        records.clear()
        val raw = prefs.getString("order_history", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                records.add(
                    TradeRecord(
                        obj.optString("type", "BELI"),
                        obj.optDouble("idr", 0.0),
                        obj.optDouble("btc", 0.0),
                        obj.optDouble("price", 0.0),
                        obj.optLong("time", 0L)
                    )
                )
            }
        } catch (_: Exception) {
            records.clear()
        }
    }

    private fun serializeRecords(): String {
        val array = JSONArray()
        records.forEach { item ->
            array.put(JSONObject().apply {
                put("type", item.type)
                put("idr", item.idr)
                put("btc", item.btc)
                put("price", item.price)
                put("time", item.time)
            })
        }
        return array.toString()
    }

    private fun seedPracticeChart(anchor: Double) {
        if (!anchor.isFinite() || anchor <= 0.0) return
        pricePoints.clear()
        var value = anchor
        repeat(90) {
            value = nextPracticeChartValue(value, anchor)
            pricePoints.add(value)
        }
        saveCachedChart()
    }

    private fun appendPracticeChartPoint(anchor: Double) {
        if (!anchor.isFinite() || anchor <= 0.0) return
        if (pricePoints.isEmpty()) {
            seedPracticeChart(anchor)
            return
        }
        val next = nextPracticeChartValue(pricePoints.last(), anchor)
        pricePoints.add(next)
        while (pricePoints.size > 90) pricePoints.removeAt(0)
        saveCachedChart()
    }

    private fun effectivePracticeAnchor(): Double {
        val base = marketReferencePrice.takeIf { it > 0.0 } ?: currentPrice
        return (base + manualPriceBoostIdr).coerceAtLeast(1.0)
    }

    private fun handleUpTap(button: Button) {
        upTapCount += 1
        if (upTapCount >= 50) {
            upTapCount = 0
            manualPriceBoostIdr += 1.0
            if (pricePoints.isNotEmpty()) {
                pricePoints[pricePoints.lastIndex] = pricePoints.last() + 1.0
                currentPrice = pricePoints.last()
                saveCachedChart()
            } else if (currentPrice > 0.0) {
                currentPrice += 1.0
            }
            prefs.edit()
                .putString("manual_price_boost_idr", manualPriceBoostIdr.toString())
                .putString("last_price", currentPrice.toString())
                .apply()
            if (::priceText.isInitialized && currentPrice > 0.0) priceText.text = formatIdr(currentPrice)
            if (::chartView.isInitialized) chartView.setValues(pricePoints, animate = false)
            updatePortfolio()
            updateRtpUi()
            updateOrderEstimate()
            toast("UP berhasil: harga latihan bertambah Rp1.")
        }
        prefs.edit().putInt("up_tap_count", upTapCount).apply()
        button.text = "UP $upTapCount/50"
    }

    private fun nextPracticeChartValue(previous: Double, anchor: Double): Double {
        // High-volatility practice path: frequent swings, occasional larger spikes,
        // a very mild upward drift, and a much wider range than the old 2.5% cap.
        val spike = chartRandom.nextDouble() < 0.13
        val movement = if (spike) {
            chartRandom.nextDouble() * 0.070 - 0.028  // -2.8% to +4.2%
        } else {
            chartRandom.nextDouble() * 0.014 - 0.006 // -0.6% to +0.8%
        }
        val upwardDrift = 0.00008
        val meanReversion = ((anchor - previous) / anchor) * 0.003
        val next = previous * (1.0 + movement + upwardDrift + meanReversion)
        return next.coerceIn(anchor * 0.25, anchor * 4.0)
    }

    private fun loadCachedChart() {
        pricePoints.clear()
        try {
            val array = JSONArray(prefs.getString("price_chart", "[]") ?: "[]")
            for (i in 0 until array.length()) {
                val value = array.optDouble(i, 0.0)
                if (value > 0.0) pricePoints.add(value)
            }
        } catch (_: Exception) {
            pricePoints.clear()
        }
    }

    private fun saveCachedChart() {
        val array = JSONArray()
        pricePoints.forEach { array.put(it) }
        prefs.edit().putString("price_chart", array.toString()).apply()
    }

    private fun formatBtc(value: Double): String = String.format(Locale.US, "%.8f", value.coerceAtLeast(0.0))

    private fun formatIdr(value: Double): String {
        val number = NumberFormat.getNumberInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 0
            minimumFractionDigits = 0
        }
        return "Rp ${number.format(value)}"
    }

    private fun formatChange(value: Double): String {
        val sign = if (value >= 0.0) "+" else ""
        return "${sign}${String.format(Locale.US, "%.2f", value)}%  ·  24 jam"
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD)
            else Typeface.create("sans-serif", Typeface.NORMAL)
            includeFontPadding = true
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = rounded(panel, 14)
        }
    }

    private fun button(value: String, color: Int, textColor: Int): Button {
        return Button(this).apply {
            text = value
            textSize = 12f
            setTextColor(textColor)
            isAllCaps = false
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(color, 10)
            stateListAnimator = null
            minHeight = dp(44)
            minimumHeight = dp(44)
            setPadding(dp(10), 0, dp(10), 0)
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun gap(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private data class TradeRecord(
        val type: String,
        val idr: Double,
        val btc: Double,
        val price: Double,
        val time: Long
    )

    private inner class MarketChartView : View(this@MainActivity) {
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x28FFFFFF
            strokeWidth = dp(1).toFloat()
        }
        private val upPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = green
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        private val downPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = red
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = white }
        private val markerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * resources.displayMetrics.density
        }
        private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = dp(9).toFloat()
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = dp(11).toFloat()
            textAlign = Paint.Align.CENTER
        }
        private var values: List<Double> = emptyList()
        private var revealProgress = 1f
        private var pulseProgress = 0f
        private var revealAnimator: ValueAnimator? = null
        private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1150L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = LinearInterpolator()
            addUpdateListener {
                pulseProgress = it.animatedValue as Float
                invalidate()
            }
        }

        fun setValues(data: List<Double>, animate: Boolean = true) {
            values = data.filter { it.isFinite() && it > 0.0 }.toList()
            revealAnimator?.cancel()
            if (animate && values.size >= 2) {
                revealProgress = 0f
                revealAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 850L
                    interpolator = LinearInterpolator()
                    addUpdateListener {
                        revealProgress = it.animatedValue as Float
                        invalidate()
                    }
                    start()
                }
            } else {
                revealProgress = 1f
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            if (!pulseAnimator.isStarted) pulseAnimator.start()
        }

        override fun onDetachedFromWindow() {
            revealAnimator?.cancel()
            pulseAnimator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val left = dp(7).toFloat()
            val right = width - dp(7).toFloat()
            val top = dp(13).toFloat()
            val bottom = height - dp(25).toFloat()
            val plotWidth = right - left
            val plotHeight = bottom - top

            // Exchange-style grid: horizontal price levels and vertical time divisions.
            for (i in 0..4) {
                val y = top + plotHeight * i / 4f
                canvas.drawLine(left, y, right, y, gridPaint)
            }
            for (i in 0..6) {
                val x = left + plotWidth * i / 6f
                canvas.drawLine(x, top, x, bottom, gridPaint)
            }

            val timeLabels = listOf("90s", "75s", "60s", "45s", "30s", "15s", "NOW")
            timeLabels.forEachIndexed { index, text ->
                val x = left + plotWidth * index / 6f
                val align = when (index) {
                    0 -> Paint.Align.LEFT
                    6 -> Paint.Align.RIGHT
                    else -> Paint.Align.CENTER
                }
                axisPaint.textAlign = align
                canvas.drawText(text, x, height - dp(5).toFloat(), axisPaint)
            }

            if (values.size < 2 || plotWidth <= 0f || plotHeight <= 0f) {
                canvas.drawText("Menunggu data pergerakan harga...", width / 2f, height / 2f, emptyPaint)
                return
            }

            val minValue = values.minOrNull() ?: return
            val maxValue = values.maxOrNull() ?: return
            val rawRange = maxValue - minValue
            val padding = if (rawRange > 0.0) rawRange * 0.10 else max(maxValue * 0.001, 1.0)
            val low = minValue - padding
            val high = maxValue + padding
            val range = max(high - low, 1.0)

            fun pointX(index: Int): Float = left + plotWidth * index / (values.size - 1).toFloat()
            fun pointY(value: Double): Float = bottom - ((value - low) / range).toFloat() * plotHeight

            // Draw a very soft tinted area under the visible price curve.
            val segmentCount = values.size - 1
            val progressAcross = revealProgress * segmentCount
            val lastCompleteIndex = progressAcross.toInt().coerceIn(0, segmentCount)
            val partial = (progressAcross - lastCompleteIndex).coerceIn(0f, 1f)
            var endX = pointX(0)
            var endY = pointY(values[0])
            val curve = Path().apply { moveTo(endX, endY) }

            for (i in 0 until segmentCount) {
                if (i > progressAcross) break
                val fraction = if (i < lastCompleteIndex) 1f else partial
                if (fraction <= 0f) break
                val x1 = pointX(i)
                val y1 = pointY(values[i])
                val x2 = pointX(i + 1)
                val y2 = pointY(values[i + 1])
                endX = x1 + (x2 - x1) * fraction
                endY = y1 + (y2 - y1) * fraction
                curve.lineTo(endX, endY)
            }

            val tint = if (values.last() >= values.first()) green else red
            val area = Path().apply {
                moveTo(pointX(0), bottom)
                lineTo(pointX(0), pointY(values[0]))
                addPath(curve)
                lineTo(endX, bottom)
                close()
            }
            val areaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                shader = LinearGradient(
                    0f, top, 0f, bottom,
                    (tint and 0x00FFFFFF) or 0x26000000,
                    (tint and 0x00FFFFFF) or 0x00000000,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawPath(area, areaPaint)

            // Each segment is green when the sampled market price rises, red when it falls.
            canvas.save()
            canvas.clipRect(left, top - dp(2), right, bottom + dp(2))
            for (i in 0 until segmentCount) {
                if (i > progressAcross) break
                val fraction = if (i < lastCompleteIndex) 1f else partial
                if (fraction <= 0f) break
                val x1 = pointX(i)
                val y1 = pointY(values[i])
                val x2 = pointX(i + 1)
                val y2 = pointY(values[i + 1])
                val visibleX = x1 + (x2 - x1) * fraction
                val visibleY = y1 + (y2 - y1) * fraction
                val paint = if (values[i + 1] >= values[i]) upPaint else downPaint
                canvas.drawLine(x1, y1, visibleX, visibleY, paint)
            }
            canvas.restore()

            // A pulsing point marks the latest practice-volatility sample.
            val latestValue = if (progressAcross >= segmentCount) values.last() else {
                val index = lastCompleteIndex.coerceIn(0, segmentCount - 1)
                values[index] + (values[index + 1] - values[index]) * partial.toDouble()
            }
            val latestX = if (progressAcross >= segmentCount) right else endX
            val latestY = pointY(latestValue)
            val latestColor = if (values.last() >= values[values.lastIndex - 1]) green else red
            markerRingPaint.color = latestColor
            markerRingPaint.alpha = (100 + pulseProgress * 100).toInt().coerceIn(100, 200)
            canvas.drawCircle(latestX, latestY, dp(5).toFloat() + pulseProgress * dp(4), markerRingPaint)
            markerPaint.color = latestColor
            canvas.drawCircle(latestX, latestY, dp(3).toFloat(), markerPaint)
        }
    }
}