package com.fizzpage.bitcoinpractice

import android.app.Activity
import android.Manifest
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Build
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.InputFilter
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 14, 17)
    private val panel = Color.rgb(21, 26, 33)
    private val panelAlt = Color.rgb(28, 34, 42)
    private val gold = Color.rgb(247, 147, 26)
    private val white = Color.rgb(242, 244, 247)
    private val muted = Color.rgb(145, 153, 164)
    private val green = Color.rgb(22, 190, 125)
    private val red = Color.rgb(239, 83, 80)

    private lateinit var balanceText: TextView
    private lateinit var priceText: TextView
    private lateinit var changeText: TextView
    private lateinit var marketStatusText: TextView
    private lateinit var btcText: TextView
    private lateinit var holdingValueText: TextView
    private lateinit var amountInput: EditText
    private lateinit var maxAmountButton: Button
    private lateinit var buyAsButton: Button
    private lateinit var sellAsButton: Button
    private lateinit var amountLabelText: TextView
    private lateinit var orderUnitInfoText: TextView
    private lateinit var orderEstimateText: TextView
    private lateinit var rtpContainer: LinearLayout
    private lateinit var historyContainer: LinearLayout
    private lateinit var chartView: MarketChartView
    private lateinit var refreshButton: Button
    private lateinit var creditStatusText: TextView
    private lateinit var creditSelectionText: TextView
    private lateinit var creditEstimateText: TextView
    private lateinit var creditSelectButton: Button
    private lateinit var creditButton: Button
    private var onboardingNameInput: EditText? = null
    private var onboardingBirthDateButton: Button? = null
    private var onboardingProvinceInput: EditText? = null
    private var onboardingRegencyInput: EditText? = null
    private var onboardingDistrictInput: EditText? = null
    private var onboardingExperienceButton: Button? = null
    private var onboardingStrategyButton: Button? = null
    private var selectedExperience = ""
    private var selectedStrategy = ""
    private var selectedBirthDate = ""

    private val prefs by lazy { getSharedPreferences("satoshi_practice", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private var virtualBalance = 0.0
    private var btcHolding = 0.0
    private var buyByBtc = false
    private var sellByBtc = true
    private var activeOrderIsBuy = true
    // currentPrice is ALWAYS the latest visible chart point and is used by all
    // estimates, portfolio valuations, and practice buy/sell calculations.
    private var currentPrice = 0.0
    // The public ticker is the reference anchor for the wider practice-volatility path.
    private var marketReferencePrice = 0.0
    private var change24h = 0.0
    private var marketFresh = false
    private var fetching = false
    private var activityVisible = false
    private var pendingAutoBotStart = false
    private var lastSyncedChartJson = ""
    private var lastSyncedHistoryJson = ""
    private var lastSyncedBotEventsJson = ""
    private var upTapCount = 0
    private var manualPriceBoostIdr = 0.0
    // The chart is an explicitly labeled practice-volatility visualization, not market history.
    private val pricePoints = mutableListOf<Double>()
    private val chartRandom = java.util.Random()
    // Regime-based market mood: bullish, bearish, or sideways.
    private var practiceTrendRegime = 0 // -1 bearish, 0 sideways, 1 bullish
    private var practiceTrendTicksRemaining = 0
    private var lastMarketStamp = "Belum ada pembaruan harga"
    private var nextQuoteAt = 0L
    private var lastRtpUiUpdateAt = 0L
    // Public ticker is only a reference anchor; the local practice chart/service ticks every second.
    private val quoteIntervalMs = 60_000L
    private val quoteRetryIntervalMs = 5_000L
    private var onboardingIndex = 0
    private var selectedPracticeCredit = 200_000L
    private val practiceCreditOptions = listOf(
        200_000L, 250_000L, 300_000L, 400_000L, 500_000L, 750_000L,
        1_000_000L, 1_500_000L, 2_000_000L, 2_500_000L, 3_000_000L,
        4_000_000L, 5_000_000L, 7_500_000L, 10_000_000L, 15_000_000L,
        20_000_000L, 25_000_000L, 30_000_000L, 40_000_000L, 50_000_000L,
        60_000_000L, 75_000_000L, 90_000_000L, 100_000_000L, 125_000_000L,
        150_000_000L, 175_000_000L, 200_000_000L, 250_000_000L, 300_000_000L,
        400_000_000L, 500_000_000L, 650_000_000L, 800_000_000L, 905_000_000L
    )
    private val records = mutableListOf<TradeRecord>()

    // Auto Miner is a local practice trading bot. It never mines real coins or sends orders.
    private var autoBotActive = false
    private var autoBotOwnedBtc = 0.0
    private var autoBotEntryCost = 0.0
    private var autoBotEntryPrice = 0.0
    private var autoBotEntryTime = 0L
    private var autoBotLastTradeAt = 0L
    private var autoBotSessionStartedAt = 0L
    private val autoBotEvents = mutableListOf<BotTradeEvent>()
    private lateinit var autoBotToggleButton: Button
    private lateinit var autoBotStatusText: TextView
    private lateinit var autoBotReportText: TextView

    // The app polls the read-only BTC/IDR ticker for the displayed market reference.
    // The separate chart below is an explicitly labeled practice-volatility path.
    private val refreshRunnable = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (prefs.getBoolean("practice_credit_pending", false) &&
                now >= prefs.getLong("practice_credit_due_at", Long.MAX_VALUE)
            ) {
                // When the app is open, complete the scheduled credit at its selected due time.
                // The registered alarm remains as the background fallback.
                sendBroadcast(Intent(this@MainActivity, PracticeCreditReceiver::class.java))
            }
            if (activityVisible && !fetching && nextQuoteAt > 0L && now >= nextQuoteAt) {
                fetchMarketData()
            }
            if (!prefs.getBoolean("auto_bot_active", false) && autoBotActive) {
                // Mirror a stop command that came from the persistent notification.
                loadAutoBotSession()
            }
            val serviceRunning = AutoMinerService.isRunning() && prefs.getBoolean("auto_bot_active", false)
            if (serviceRunning) {
                // The foreground service owns the one-second market/bot loop while the
                // app is backgrounded. The Activity only mirrors its persisted snapshot.
                syncBackgroundBotSnapshot()
            } else if (prefs.getBoolean("auto_bot_active", false) && prefs.getBoolean("auto_bot_service_running", false)) {
                // The OS may stop a service on some devices. Never silently keep a bot
                // marked active without its foreground service.
                loadAutoBotSession()
                syncBackgroundBotSnapshot()
            } else if (::chartView.isInitialized && marketReferencePrice > 0.0) {
                val practiceAnchor = effectivePracticeAnchor()
                if (pricePoints.isEmpty()) seedPracticeChart(practiceAnchor)
                else appendPracticeChartPoint(practiceAnchor)
                currentPrice = pricePoints.lastOrNull() ?: marketReferencePrice
                priceText.text = formatIdr(currentPrice)
                prefs.edit().putString("last_price", currentPrice.toString()).apply()
                chartView.setValues(pricePoints, animate = false)
                updatePortfolio()
            }
            if (autoBotActive && !serviceRunning) processAutoBotTick()
            updateAutoBotUi()
            updateRtpUi()
            updateOrderEstimate()
            if (::marketStatusText.isInitialized) {
                val seconds = if (nextQuoteAt > now) ((nextQuoteAt - now + 999L) / 1000L) else 0L
                val countdown = if (fetching) "ticker memperbarui..." else "ticker cek lagi ${seconds} dtk"
                marketStatusText.text = "$lastMarketStamp · $countdown · harga grafik dan order berubah 1 dtk"
                updateCreditUi()
            }
            handler.postDelayed(this, 1_000L)
        }
    }

    private val onboardingSteps = listOf(
        "Nama lengkap" to "Isi nama yang ingin ditampilkan di akun. Wajib diisi, maksimal 24 karakter. Nama disimpan secara lokal di perangkat ini.",
        "Tanggal lahir" to "Pilih tanggal, bulan, dan tahun menggunakan kalender. Tanggal lahir hanya disimpan di perangkat dan tidak dipakai sebagai verifikasi usia.",
        "Tempat tinggal" to "Isi provinsi, kabupaten/kota, dan kecamatan. Data domisili hanya disimpan di perangkat; aplikasi tidak mengakses GPS.",
        "Pengalaman latihan" to "Pilih tingkat pengalaman agar ringkasan akun dapat menampilkan konteks latihan yang sesuai.",
        "Strategi pilihan" to "Pilih gaya yang paling ingin kamu pelajari. Ini hanya preferensi tampilan dan bukan rekomendasi transaksi."
    )

    private val creditChallengeSteps = listOf(
        "Ini adalah pemeriksaan pemahaman untuk akun latihan, bukan verifikasi umur 18+ atau identitas resmi.",
        "Satoshi Practice bukan exchange, broker, bank, atau dompet Bitcoin sungguhan.",
        "Semua nominal Rp di menu ini adalah satuan kredit virtual untuk latihan.",
        "Tidak ada uang, Bitcoin, atau aset sungguhan yang dikirim atau diterima.",
        "Aplikasi tidak memproses transfer bank, kartu, QRIS, e-wallet, atau pembayaran lain.",
        "Jangan mengirim uang kepada siapa pun untuk memperoleh kredit latihan.",
        "Aplikasi ini tidak memerlukan KTP, selfie, paspor, atau dokumen identitas.",
        "Jangan masukkan PIN, kata sandi, OTP, seed phrase, atau private key ke aplikasi.",
        "Saldo awal akun latihan adalah Rp0.",
        "Pilihan nominal dimulai dari Rp200.000 kredit virtual.",
        "Pilihan nominal tertinggi adalah Rp905.000.000 kredit virtual.",
        "Nominal yang dipilih hanya mengubah saldo latihan lokal pada perangkat ini.",
        "Semakin tinggi nominal pilihan, semakin panjang waktu tunggu kredit latihan.",
        "Waktu tunggu adalah timer aplikasi, bukan waktu penyelesaian transaksi keuangan.",
        "Perkiraan waktu dapat bergeser jika Android menunda alarm saat perangkat tidak aktif.",
        "Notifikasi hanya memberitahu bahwa kredit latihan lokal telah ditambahkan.",
        "Kredit latihan tidak memiliki nilai tunai atau nilai tukar.",
        "Kredit latihan tidak dapat ditarik, diuangkan, ditransfer, atau dipindahtangankan.",
        "Saldo latihan disimpan secara lokal di perangkat dan bukan rekening online.",
        "Menghapus data aplikasi dapat menghapus saldo serta riwayat latihan.",
        "Harga BTC/IDR berasal dari sumber data pasar publik dan bisa mengalami keterlambatan.",
        "Grafik tidak menjamin harga berikutnya dan bukan saran investasi.",
        "Tombol BELI hanya mencatat pembelian Bitcoin latihan.",
        "Tombol JUAL hanya mencatat penjualan Bitcoin latihan.",
        "Tidak ada order yang dikirim ke bursa kripto atau pihak ketiga.",
        "Saya memahami bahwa seluruh proses ini hanya menambah kredit latihan virtual."
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        // One-time v0.5.7 wallet reset. Existing installs get a clean zero balance,
        // while profile/onboarding preferences and historical order logs are preserved.
        // Cancel a pending practice-credit alarm so an old scheduled credit cannot
        // repopulate the wallet immediately after this reset.
        if (!prefs.getBoolean("zero_balance_reset_v4", false)) {
            val creditAlarm = getSystemService(ALARM_SERVICE) as AlarmManager
            val creditIntent = Intent(this, PracticeCreditReceiver::class.java)
            val creditPendingIntent = PendingIntent.getBroadcast(
                this,
                PracticeCreditReceiver.REQUEST_CODE,
                creditIntent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (creditPendingIntent != null) {
                creditAlarm.cancel(creditPendingIntent)
                creditPendingIntent.cancel()
            }

            // Commit before stopping the service so its next tick sees the inactive flag.
            prefs.edit()
                .putBoolean("auto_bot_active", false)
                .putBoolean("auto_bot_service_running", false)
                .putString("practice_balance", "0.0")
                .putString("btc_holding", "0.0")
                .putString("auto_bot_owned_btc", "0.0")
                .putString("auto_bot_entry_cost", "0.0")
                .putString("auto_bot_entry_price", "0.0")
                .putLong("auto_bot_entry_time", 0L)
                .putLong("auto_bot_last_trade_at", 0L)
                .putLong("auto_bot_session_started_at", 0L)
                .putString("auto_bot_session_start_equity", "0.0")
                .putString("auto_bot_peak_net_return", "0.0")
                .putString("practice_credit_amount", "0")
                .putBoolean("practice_credit_pending", false)
                .putLong("practice_credit_due_at", 0L)
                .putBoolean("zero_balance_reset_v4", true)
                .commit()
            stopService(Intent(this, AutoMinerService::class.java))
        }
        val savedCreditAmount = prefs.getLong("selected_practice_credit_amount", practiceCreditOptions.first())
        selectedPracticeCredit = if (practiceCreditOptions.contains(savedCreditAmount)) {
            savedCreditAmount
        } else {
            practiceCreditOptions.first()
        }
        virtualBalance = prefs.getString("practice_balance", "0")?.toDoubleOrNull() ?: 0.0
        btcHolding = prefs.getString("btc_holding", "0")?.toDoubleOrNull() ?: 0.0
        buyByBtc = prefs.getBoolean("buy_as_btc", false)
        sellByBtc = prefs.getBoolean("sell_as_btc", true)
        currentPrice = prefs.getString("last_price", "0")?.toDoubleOrNull() ?: 0.0
        marketReferencePrice = prefs.getString("market_reference_price", "0")?.toDoubleOrNull()
            ?.takeIf { it > 0.0 } ?: currentPrice
        marketFresh = marketReferencePrice > 0.0
        change24h = prefs.getString("last_change", "0")?.toDoubleOrNull() ?: 0.0
        upTapCount = prefs.getInt("up_tap_count", 0).coerceIn(0, 49)
        manualPriceBoostIdr = prefs.getString("manual_price_boost_idr", "0")
            ?.toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0.0 } ?: 0.0
        practiceTrendRegime = prefs.getInt("practice_trend_regime", 0).coerceIn(-1, 1)
        practiceTrendTicksRemaining = prefs.getInt("practice_trend_ticks", 0).coerceIn(0, 30)
        // Run the new five-step profile setup once after updating. Existing balances,
        // BTC holdings, and transaction history are deliberately preserved.
        if (!prefs.getBoolean("onboarding_v5_migrated", false)) {
            prefs.edit()
                .putBoolean("onboarding_completed", false)
                .putInt("onboarding_step", 0)
                .putBoolean("onboarding_v5_migrated", true)
                .apply()
        }
        selectedBirthDate = prefs.getString("birth_date", "")?.trim().orEmpty()
        selectedExperience = prefs.getString("experience_level", "")?.trim().orEmpty()
        selectedStrategy = prefs.getString("preferred_strategy", "")?.trim().orEmpty()

        // Re-seed the local practice chart once for the fixed Rp1.11B-Rp1.20B band.
        // Wallet balance, BTC holdings, profile, and trade history are not changed.
        if (prefs.getBoolean("practice_price_band_v4", false)) {
            loadCachedChart()
            if (pricePoints.isNotEmpty()) {
                for (i in pricePoints.indices) {
                    pricePoints[i] = pricePoints[i].coerceIn(PracticeMarketConfig.PRICE_FLOOR_IDR, PracticeMarketConfig.PRICE_CEILING_IDR)
                }
                saveCachedChart()
            }
        } else {
            pricePoints.clear()
            prefs.edit().putBoolean("practice_price_band_v4", true).apply()
        }
        // Restore the exact same price used by the visible chart so the order panel,
        // portfolio value, and chart cannot start from different prices.
        if (pricePoints.isNotEmpty()) currentPrice = pricePoints.last()
        loadRecords()
        loadAutoBotSession()
        if (autoBotOwnedBtc > 0.0 && !prefs.contains("auto_bot_lucky_trade")) {
            prefs.edit().putBoolean("auto_bot_lucky_trade", chartRandom.nextDouble() < PracticeMarketConfig.BOT_WIN_CHANCE).apply()
        }

        if (!prefs.getBoolean("onboarding_completed", false)) {
            onboardingIndex = prefs.getInt("onboarding_step", 0).coerceIn(0, onboardingSteps.lastIndex)
            buildOnboarding()
        } else {
            buildScreen()
            updatePortfolio()
            renderHistory()
            if (currentPrice > 0.0) {
                priceText.text = formatIdr(currentPrice)
                changeText.text = formatChange(change24h)
                changeText.setTextColor(if (change24h >= 0) green else red)
                lastMarketStamp = "Harga acuan tersimpan"
                nextQuoteAt = System.currentTimeMillis() + quoteIntervalMs
                if (pricePoints.isEmpty()) seedPracticeChart(effectivePracticeAnchor())
                pricePoints.lastOrNull()?.let { currentPrice = it }
                priceText.text = formatIdr(currentPrice)
                chartView.setValues(pricePoints, animate = false)
            }
            fetchMarketData()
            handler.postDelayed(refreshRunnable, 1_000L)
        }
    }

    override fun onResume() {
        super.onResume()
        activityVisible = true
        if (nextQuoteAt > 0L) nextQuoteAt = System.currentTimeMillis()
        handler.removeCallbacks(refreshRunnable)
        handler.post(refreshRunnable)
    }

    override fun onStop() {
        activityVisible = false
        // The Activity UI loop pauses, but AutoMinerService continues its user-started
        // foreground-service loop with an ongoing notification and CPU wake lock.
        handler.removeCallbacks(refreshRunnable)
        super.onStop()
    }

    override fun onDestroy() {
        // Destroying the Activity must not stop a separately running foreground service.
        handler.removeCallbacks(refreshRunnable)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUTO_BOT_NOTIFICATION) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (pendingAutoBotStart && granted) {
                pendingAutoBotStart = false
                startAutoBotNow()
            } else {
                pendingAutoBotStart = false
                toast("Izin notifikasi diperlukan agar status bot latar belakang selalu terlihat.")
            }
        }
    }

    private fun buildOnboarding() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(34), dp(22), dp(28))
        }
        scroll.addView(root, FrameLayout.LayoutParams(-1, -1))
        setContentView(scroll)

        root.addView(label("SATOSHI PRACTICE", 12f, gold, true))
        root.addView(gap(24))
        root.addView(label("BUAT PROFIL PENGGUNA", 10f, muted, true))
        root.addView(gap(10))
        root.addView(label("Langkah ${onboardingIndex + 1} dari 5", 13f, gold, true))
        root.addView(gap(10))

        val progressFrame = FrameLayout(this)
        progressFrame.addView(View(this).apply { background = rounded(panelAlt, 20) },
            FrameLayout.LayoutParams(-1, dp(6)))
        val fillWidth = (resources.displayMetrics.widthPixels - dp(44)) * (onboardingIndex + 1) / 5
        progressFrame.addView(View(this).apply { background = rounded(gold, 20) },
            FrameLayout.LayoutParams(fillWidth, dp(6)))
        root.addView(progressFrame, matchWrap())
        root.addView(gap(24))

        val card = card().apply { setPadding(dp(18), dp(22), dp(18), dp(22)) }
        val step = onboardingSteps[onboardingIndex]
        card.addView(label(step.first, 23f, white, true))
        card.addView(label(step.second, 14f, muted, false).apply {
            setPadding(0, dp(12), 0, dp(15))
            setLineSpacing(dp(4).toFloat(), 1f)
        })

        onboardingNameInput = null
        onboardingBirthDateButton = null
        onboardingProvinceInput = null
        onboardingRegencyInput = null
        onboardingDistrictInput = null
        onboardingExperienceButton = null
        onboardingStrategyButton = null

        when (onboardingIndex) {
            0 -> {
                val nameInput = onboardingEditText(
                    "Nama lengkap (maksimal 24 karakter)",
                    prefs.getString("display_name", "") ?: ""
                )
                nameInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
                nameInput.filters = arrayOf(InputFilter.LengthFilter(24))
                onboardingNameInput = nameInput
                card.addView(nameInput, matchWrap())
                card.addView(label("Nama wajib diisi dan dibatasi maksimal 24 karakter. Nama hanya digunakan sebagai profil lokal.", 10f, muted, false).apply {
                    setPadding(0, dp(8), 0, 0)
                })
            }
            1 -> {
                val dateButton = button(
                    if (selectedBirthDate.isBlank()) "PILIH TANGGAL LAHIR  ▾" else "${formatBirthDate(selectedBirthDate)}  ▾",
                    panelAlt, white
                ).apply {
                    minHeight = dp(54)
                    setOnClickListener { showBirthDatePicker() }
                }
                onboardingBirthDateButton = dateButton
                card.addView(dateButton, matchWrap())
                card.addView(label("Contoh format: 17 Agustus 1945. Ini bukan pemeriksaan kelayakan atau verifikasi umur.", 10f, muted, false).apply {
                    setPadding(0, dp(9), 0, 0)
                })
            }
            2 -> {
                val provinceInput = onboardingEditText("Provinsi", prefs.getString("province", "") ?: "")
                val regencyInput = onboardingEditText("Kabupaten / Kota", prefs.getString("regency", "") ?: "")
                val districtInput = onboardingEditText("Kecamatan", prefs.getString("district", "") ?: "")
                onboardingProvinceInput = provinceInput
                onboardingRegencyInput = regencyInput
                onboardingDistrictInput = districtInput
                card.addView(provinceInput, matchWrap())
                card.addView(gap(9))
                card.addView(regencyInput, matchWrap())
                card.addView(gap(9))
                card.addView(districtInput, matchWrap())
                card.addView(label("Isi nama wilayah saja. Tidak perlu alamat jalan, nomor rumah, atau kode pos.", 10f, muted, false).apply {
                    setPadding(0, dp(9), 0, 0)
                })
            }
            3 -> {
                val options = arrayOf("Baru mulai", "Pernah mencoba", "Memahami dasar", "Sudah rutin latihan")
                val experienceButton = button(
                    if (selectedExperience.isBlank()) "PILIH PENGALAMAN  ▾" else "$selectedExperience  ▾",
                    panelAlt, white
                ).apply {
                    minHeight = dp(54)
                    setOnClickListener {
                        showProfileChoice("PENGALAMAN LATIHAN", options, selectedExperience) { choice ->
                            selectedExperience = choice
                            onboardingExperienceButton?.text = "$choice  ▾"
                        }
                    }
                }
                onboardingExperienceButton = experienceButton
                card.addView(experienceButton, matchWrap())
            }
            4 -> {
                val options = arrayOf("Scalping", "Day Trading", "Swing Trading", "Jangka Panjang", "Belum menentukan")
                val strategyButton = button(
                    if (selectedStrategy.isBlank()) "PILIH STRATEGI  ▾" else "$selectedStrategy  ▾",
                    panelAlt, white
                ).apply {
                    minHeight = dp(54)
                    setOnClickListener {
                        showProfileChoice("STRATEGI LATIHAN", options, selectedStrategy) { choice ->
                            selectedStrategy = choice
                            onboardingStrategyButton?.text = "$choice  ▾"
                        }
                    }
                }
                onboardingStrategyButton = strategyButton
                card.addView(strategyButton, matchWrap())
                card.addView(label("Strategi ini hanya label preferensi untuk halaman akun. Aplikasi tidak mengeksekusi strategi otomatis.", 10f, muted, false).apply {
                    setPadding(0, dp(9), 0, 0)
                })
            }
        }
        root.addView(card, matchWrap())
        root.addView(gap(16))
        root.addView(label("Profil, tanggal lahir, dan domisili disimpan di perangkat ini. Aplikasi tidak mengirimkannya ke server.", 11f, muted, false).apply {
            setLineSpacing(dp(3).toFloat(), 1f)
        })
        root.addView(gap(22))
        val next = button(if (onboardingIndex == 4) "SELESAIKAN PROFIL" else "LANJUT", gold, Color.BLACK)
        next.setOnClickListener {
            when (onboardingIndex) {
                0 -> {
                    val fullName = onboardingNameInput?.text?.toString()?.trim().orEmpty()
                    if (fullName.isBlank()) {
                        onboardingNameInput?.error = "Nama wajib diisi"
                        onboardingNameInput?.requestFocus()
                        toast("Isi nama terlebih dahulu.")
                        return@setOnClickListener
                    }
                    if (fullName.length > 24) {
                        onboardingNameInput?.error = "Maksimal 24 karakter (${fullName.length}/24)"
                        onboardingNameInput?.requestFocus()
                        toast("Nama maksimal 24 karakter.")
                        return@setOnClickListener
                    }
                    prefs.edit().putString("display_name", fullName).apply()
                }
                1 -> {
                    if (selectedBirthDate.isBlank()) {
                        toast("Pilih tanggal lahir melalui kalender dulu.")
                        return@setOnClickListener
                    }
                    prefs.edit().putString("birth_date", selectedBirthDate).apply()
                }
                2 -> {
                    val province = onboardingProvinceInput?.text?.toString()?.trim().orEmpty()
                    val regency = onboardingRegencyInput?.text?.toString()?.trim().orEmpty()
                    val district = onboardingDistrictInput?.text?.toString()?.trim().orEmpty()
                    if (province.isBlank() || regency.isBlank() || district.isBlank()) {
                        toast("Lengkapi provinsi, kabupaten/kota, dan kecamatan.")
                        return@setOnClickListener
                    }
                    prefs.edit()
                        .putString("province", province)
                        .putString("regency", regency)
                        .putString("district", district)
                        .apply()
                }
                3 -> {
                    if (selectedExperience.isBlank()) {
                        toast("Pilih pengalaman latihan dulu.")
                        return@setOnClickListener
                    }
                    prefs.edit().putString("experience_level", selectedExperience).apply()
                }
                4 -> {
                    if (selectedStrategy.isBlank()) {
                        toast("Pilih strategi latihan dulu.")
                        return@setOnClickListener
                    }
                    prefs.edit()
                        .putString("preferred_strategy", selectedStrategy)
                        .putBoolean("onboarding_completed", true)
                        .putBoolean("profile_onboarding_v2_done", true)
                        .putInt("onboarding_step", 0)
                        .apply()
                    buildScreen()
                    updatePortfolio()
                    renderHistory()
                    fetchMarketData()
                    handler.postDelayed(refreshRunnable, 1_000L)
                    return@setOnClickListener
                }
            }
            onboardingIndex += 1
            prefs.edit().putInt("onboarding_step", onboardingIndex).apply()
            buildOnboarding()
        }
        root.addView(next, LinearLayout.LayoutParams(-1, dp(52)))
    }

    private fun onboardingEditText(hintText: String, initial: String): EditText {
        return EditText(this).apply {
            hint = hintText
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(panelAlt, 10)
            setText(initial)
        }
    }

    private fun showBirthDatePicker() {
        val calendar = Calendar.getInstance()
        if (selectedBirthDate.isNotBlank()) {
            try {
                val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(selectedBirthDate)
                if (parsed != null) calendar.time = parsed
            } catch (_: Exception) { }
        } else {
            calendar.set(2000, Calendar.JANUARY, 1)
        }
        val picker = DatePickerDialog(
            this,
            { _, year, month, day ->
                selectedBirthDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                onboardingBirthDateButton?.text = "${formatBirthDate(selectedBirthDate)}  ▾"
            },
            calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)
        )
        picker.datePicker.maxDate = System.currentTimeMillis()
        picker.show()
    }

    private fun formatBirthDate(isoDate: String): String {
        return try {
            val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(isoDate)
            if (parsed == null) isoDate else SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID")).format(parsed)
        } catch (_: Exception) { isoDate }
    }

    private fun calculateAge(isoDate: String): Int? {
        if (isoDate.isBlank()) return null
        return try {
            val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(isoDate) ?: return null
            val birth = Calendar.getInstance().apply { time = parsed }
            val today = Calendar.getInstance()
            var age = today.get(Calendar.YEAR) - birth.get(Calendar.YEAR)
            val monthBeforeBirthday = today.get(Calendar.MONTH) < birth.get(Calendar.MONTH)
            val dayBeforeBirthday = today.get(Calendar.MONTH) == birth.get(Calendar.MONTH) &&
                today.get(Calendar.DAY_OF_MONTH) < birth.get(Calendar.DAY_OF_MONTH)
            if (monthBeforeBirthday || dayBeforeBirthday) age -= 1
            age.takeIf { it >= 0 }
        } catch (_: Exception) { null }
    }

    private fun showProfileChoice(title: String, choices: Array<String>, selected: String, onChosen: (String) -> Unit) {
        val selectedIndex = choices.indexOf(selected).coerceAtLeast(-1)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(choices, selectedIndex) { dialog, which ->
                onChosen(choices[which])
                dialog.dismiss()
            }
            .setNegativeButton("BATAL", null)
            .show()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(28))
        }
        scroll.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        setContentView(scroll)

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brandColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandColumn.addView(label("SATOSHI", 23f, white, true))
        val displayName = prefs.getString("display_name", "")?.trim().orEmpty()
        brandColumn.addView(label(
            if (displayName.isBlank()) "BITCOIN MARKET · BTC/IDR" else "HALO, ${displayName.uppercase(Locale("id", "ID"))} · BTC/IDR",
            10f,
            muted,
            true
        ).apply { letterSpacing = 0.08f })
        header.addView(brandColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val headerActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val coinMark = TextView(this).apply {
            text = "₿"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(gold, 50)
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(8) }
        }
        val profileInitials = displayName.split(Regex("\\s+")).filter { it.isNotBlank() }
            .take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("")
            .ifBlank { "👤" }
        val profileButton = TextView(this).apply {
            text = if (profileInitials == "👤") profileInitials else profileInitials
            textSize = if (profileInitials.length > 2) 13f else 17f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(green, 50)
            isClickable = true
            isFocusable = true
            contentDescription = "Buka akun pengguna"
            setOnClickListener { buildAccountScreen() }
        }
        headerActions.addView(coinMark)
        headerActions.addView(profileButton, LinearLayout.LayoutParams(dp(42), dp(42)))
        header.addView(headerActions)
        content.addView(header)
        content.addView(gap(14))

        // BTC market panel and moving chart
        val marketCard = card().apply { setPadding(dp(15), dp(15), dp(15), dp(13)) }
        val marketTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val marketTitles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        marketTitles.addView(label("BTC / IDR", 16f, white, true))
        marketTitles.addView(label("Grafik simulasi latihan · batas Rp1,11–1,20 miliar", 10f, muted, false).apply {
            setPadding(0, dp(3), 0, 0)
        })
        marketTop.addView(marketTitles, LinearLayout.LayoutParams(0, -2, 1f))
        refreshButton = button("↻", panelAlt, white).apply {
            minWidth = dp(42)
            minHeight = dp(40)
            minimumHeight = dp(40)
            setOnClickListener { fetchMarketData() }
        }
        marketTop.addView(refreshButton)
        marketCard.addView(marketTop)

        val priceRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(15), 0, dp(4))
        }
        priceText = label("Mengambil harga...", 25f, white, true)
        priceText.maxLines = 1
        priceText.setSingleLine(true)
        priceText.textSize = 21f
        priceRow.addView(priceText, LinearLayout.LayoutParams(0, -2, 1f))
        val upButton = button("UP $upTapCount/50", panelAlt, gold).apply {
            textSize = 10f
            minWidth = dp(82)
            minimumWidth = dp(82)
            minHeight = dp(42)
            minimumHeight = dp(42)
            setOnClickListener { handleUpTap(this) }
        }
        priceRow.addView(upButton, LinearLayout.LayoutParams(dp(88), dp(42)).apply {
            marginStart = dp(8)
        })
        marketCard.addView(priceRow)
        changeText = label("Perubahan 24 jam: --", 12f, green, true)
        marketCard.addView(changeText)

        val chartHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, dp(4))
        }
        chartHeader.addView(label("PERGERAKAN BTC/IDR", 10f, gold, true), LinearLayout.LayoutParams(0, -2, 1f))
        chartHeader.addView(label("90 DETIK", 10f, gold, true))
        marketCard.addView(chartHeader)

        chartView = MarketChartView()
        marketCard.addView(chartView, LinearLayout.LayoutParams(-1, dp(214)))

        val legend = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        legend.addView(dot(green))
        legend.addView(label("Naik", 10f, muted, false).apply { setPadding(dp(5), 0, dp(13), 0) })
        legend.addView(dot(red))
        legend.addView(label("Turun", 10f, muted, false).apply { setPadding(dp(5), 0, 0, 0) })
        marketCard.addView(legend)
        marketStatusText = label("Harga grafik dan order bergerak bersama setiap detik · ticker Indodax sebagai acuan", 10f, muted, false).apply {
            setPadding(0, dp(7), 0, 0)
        }
        marketCard.addView(marketStatusText)
        content.addView(marketCard, matchWrap())

        // Fast buy/sell controls stay directly under the chart so users can act
        // without scrolling down to the detailed order form. Enter the amount below first.
        val chartActionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, dp(4))
        }
        val chartBuyButton = button("BELI BTC", green, Color.BLACK).apply {
            minHeight = dp(53)
            minimumHeight = dp(53)
            setOnClickListener {
                activeOrderIsBuy = true
                updateOrderModeInfo()
                submitOrder(isBuy = true)
            }
        }
        val chartSellButton = button("JUAL BTC", red, Color.WHITE).apply {
            minHeight = dp(53)
            minimumHeight = dp(53)
            setOnClickListener {
                activeOrderIsBuy = false
                updateOrderModeInfo()
                submitOrder(isBuy = false)
            }
        }
        chartActionRow.addView(chartBuyButton, LinearLayout.LayoutParams(0, dp(53), 1f).apply {
            marginEnd = dp(5)
        })
        chartActionRow.addView(chartSellButton, LinearLayout.LayoutParams(0, dp(53), 1f).apply {
            marginStart = dp(5)
        })
        content.addView(chartActionRow, matchWrap())
        content.addView(gap(8))

        // RTP panel: heuristic scenario ranges, not guaranteed outcomes or investment advice.
        val rtpCard = card().apply { setPadding(dp(15), dp(14), dp(15), dp(14)) }
        rtpCard.addView(label("RTP · PERKIRAAN TREN", 12f, white, true))
        rtpCard.addView(label(
            "Skenario berdasarkan perubahan BTC/IDR 24 jam. Rentang bisa meleset dan bukan jaminan profit.",
            10f, muted, false
        ).apply { setPadding(0, dp(5), 0, dp(10)) })
        rtpContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rtpCard.addView(rtpContainer)
        content.addView(rtpCard, matchWrap())
        content.addView(gap(12))

        // Detailed order inputs remain below the quick-action buttons placed directly under the chart.
        val orderCard = card().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
        val orderHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        orderHeader.addView(label("BUAT ORDER", 12f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        orderHeader.addView(label("BTC / IDR", 10f, muted, true))
        orderCard.addView(orderHeader)

        val buyModeHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(13), 0, dp(6))
        }
        buyModeHeader.addView(label("Beli Sebagai", 11f, muted, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        buyAsButton = button(if (buyByBtc) "BTC  ▾" else "Saldo (IDR)  ▾", panelAlt, white).apply {
            minWidth = dp(142)
            setOnClickListener { showOrderModeChooser(isBuy = true) }
        }
        buyModeHeader.addView(buyAsButton)
        orderCard.addView(buyModeHeader)

        val sellModeHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(6))
        }
        sellModeHeader.addView(label("Jual Sebagai", 11f, muted, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        sellAsButton = button(if (sellByBtc) "BTC  ▾" else "Saldo (IDR)  ▾", panelAlt, white).apply {
            minWidth = dp(142)
            setOnClickListener { showOrderModeChooser(isBuy = false) }
        }
        sellModeHeader.addView(sellAsButton)
        orderCard.addView(sellModeHeader)

        orderUnitInfoText = label("", 10f, muted, false).apply {
            setLineSpacing(dp(2).toFloat(), 1f)
            setPadding(0, dp(4), 0, dp(10))
        }
        orderCard.addView(orderUnitInfoText)

        amountLabelText = label("Nominal transaksi", 10f, muted, true).apply {
            setPadding(0, 0, 0, dp(7))
        }
        orderCard.addView(amountLabelText)
        amountInput = EditText(this).apply {
            hint = "Isi nominal sesuai pilihan BELI atau JUAL"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(panelAlt, 10)
        }
        val amountEntryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        amountEntryRow.addView(amountInput, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
            marginEnd = dp(8)
        })
        maxAmountButton = button("MAX", panelAlt, gold).apply {
            minWidth = dp(76)
            minHeight = dp(54)
            minimumHeight = dp(54)
            contentDescription = "Isi nominal maksimum yang tersedia"
            setOnClickListener { fillMaximumOrderAmount() }
        }
        amountEntryRow.addView(maxAmountButton, LinearLayout.LayoutParams(dp(78), dp(54)))
        orderCard.addView(amountEntryRow, matchWrap())
        orderEstimateText = label("Perkiraan BTC, nilai Rupiah, biaya, dan sisa saldo akan muncul di sini.", 10f, muted, false).apply {
            setPadding(0, dp(9), 0, dp(10))
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        orderCard.addView(orderEstimateText)
        amountInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateOrderEstimate()
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        orderCard.addView(label("Biaya latihan 0,1%. Untuk BELI dengan satuan IDR, nominal yang dimasukkan sudah termasuk biaya. Untuk JUAL dengan satuan IDR, nominal adalah perkiraan saldo bersih yang ingin diterima.", 10f, muted, false).apply {
            setPadding(0, dp(2), 0, dp(12))
            setLineSpacing(dp(2).toFloat(), 1f)
        })

        orderCard.addView(label("Tombol BELI BTC dan JUAL BTC tersedia tepat di bawah grafik. Isi nominal di panel ini, lalu gunakan tombol cepat tersebut saat diperlukan.", 10f, muted, false).apply {
            setPadding(0, dp(10), 0, 0)
        })
        content.addView(orderCard, matchWrap())
        updateOrderModeInfo()
        content.addView(gap(12))

        // Account information below market and trade controls
        val balanceCard = card()
        val balanceHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        balanceHeader.addView(label("SALDO IDR", 10f, muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        balanceHeader.addView(label("KREDIT VIRTUAL", 9f, gold, true))
        balanceCard.addView(balanceHeader)
        balanceText = label("Rp 0", 25f, white, true).apply {
            setPadding(0, dp(8), 0, dp(3))
        }
        balanceCard.addView(balanceText)
        balanceCard.addView(label("Saldo tersedia untuk order latihan", 10f, muted, false))
        creditSelectionText = label("Nominal kredit latihan: ${formatIdr(selectedPracticeCredit.toDouble())}", 12f, white, true).apply {
            setPadding(0, dp(14), 0, dp(7))
        }
        balanceCard.addView(creditSelectionText)
        creditSelectButton = button("PILIH NOMINAL KREDIT", panelAlt, white).apply {
            setOnClickListener { showPracticeCreditPicker() }
        }
        balanceCard.addView(creditSelectButton, matchWrap())
        creditEstimateText = label("Estimasi tersedia: ${formatDelay(creditDelayMinutes(selectedPracticeCredit))} setelah langkah pemahaman selesai. Kredit ini virtual dan tidak memakai uang.", 10f, muted, false).apply {
            setPadding(0, dp(8), 0, dp(5))
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        balanceCard.addView(creditEstimateText)
        creditStatusText = label("Kredit latihan belum ditambahkan.", 10f, muted, false).apply {
            setPadding(0, dp(9), 0, dp(8))
        }
        balanceCard.addView(creditStatusText)
        creditButton = button("MULAI 26 LANGKAH PEMAHAMAN", gold, Color.BLACK).apply {
            setOnClickListener { startCreditChallenge() }
        }
        balanceCard.addView(creditButton, matchWrap())
        content.addView(balanceCard, matchWrap())
        content.addView(gap(12))

        val holdingCard = card()
        holdingCard.addView(label("PORTOFOLIO SAYA", 11f, muted, true))
        val holdingRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val holdingColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        btcText = label("0.00000000 BTC", 19f, white, true)
        holdingValueText = label("Nilai perkiraan: Rp 0", 11f, muted, false).apply {
            setPadding(0, dp(4), 0, 0)
        }
        holdingColumn.addView(btcText)
        holdingColumn.addView(holdingValueText)
        holdingRow.addView(holdingColumn, LinearLayout.LayoutParams(0, -2, 1f))
        holdingRow.addView(label("₿", 27f, gold, true))
        holdingCard.addView(holdingRow)
        content.addView(holdingCard, matchWrap())
        content.addView(gap(12))

        // Auto Miner practice bot: this panel is intentionally placed at the bottom of the dashboard.
        val autoBotCard = card().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
        val autoBotHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val autoBotTitles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        autoBotTitles.addView(label("AUTO MINER BTC", 13f, white, true))
        autoBotTitles.addView(label("Bot beli/jual otomatis · kredit latihan", 10f, muted, false).apply {
            setPadding(0, dp(3), 0, 0)
        })
        autoBotHeader.addView(autoBotTitles, LinearLayout.LayoutParams(0, -2, 1f))
        autoBotHeader.addView(label("BOT", 9f, gold, true))
        autoBotCard.addView(autoBotHeader)
        autoBotCard.addView(label(
            "Mode hoki virtual: setiap posisi mendapat undian 60% skenario untung atau 40% skenario rugi. Grafik simulasi mengikuti skenario itu sampai target bersih +1,6% atau stop-loss -1,2% tercapai. Bot memakai maksimal 95% saldo virtual per posisi dan rem sesi 3%. Ini mekanik game, bukan prediksi pasar atau win rate trading sungguhan. Tidak ada BTC sungguhan atau order exchange. Bot dapat berjalan saat layar mati melalui notifikasi layanan Android, tetapi penghemat baterai atau penghentian paksa sistem tetap dapat menghentikannya.",
            10f, muted, false
        ).apply {
            setPadding(0, dp(9), 0, dp(11))
            setLineSpacing(dp(2).toFloat(), 1f)
        })
        autoBotStatusText = label("NONAKTIF · Tekan tombol untuk memulai bot latihan.", 11f, muted, true).apply {
            setPadding(0, 0, 0, dp(10))
        }
        autoBotCard.addView(autoBotStatusText)
        autoBotToggleButton = button("AKTIFKAN AUTO MINER", green, Color.BLACK).apply {
            minHeight = dp(52)
            minimumHeight = dp(52)
            setOnClickListener {
                if (autoBotActive) stopAutoBot("Bot dimatikan secara manual", showToast = true)
                else startAutoBot()
            }
        }
        autoBotCard.addView(autoBotToggleButton, matchWrap())
        autoBotCard.addView(label("LAPORAN TRANSAKSI BOT", 10f, gold, true).apply {
            setPadding(0, dp(14), 0, dp(6))
        })
        autoBotReportText = label("Belum ada sesi Auto Miner. Aktifkan bot untuk mulai mencatat transaksi.", 10f, muted, false).apply {
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, dp(3), 0, 0)
        }
        autoBotCard.addView(autoBotReportText)
        content.addView(autoBotCard, matchWrap())
        content.addView(gap(12))
        updateAutoBotUi()

        // Transaction history is displayed only on the account screen.
        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        content.addView(gap(15))
        content.addView(label("SATOSHI PRACTICE · VERSION 0.5.8", 9f, muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        })
    }

    private fun buildAccountScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(28))
        }
        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        setContentView(scroll)

        val backButton = button("←  KEMBALI KE DASHBOARD", panelAlt, white).apply {
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setOnClickListener {
                buildScreen()
                updatePortfolio()
                renderHistory()
            }
        }
        content.addView(backButton, matchWrap())
        content.addView(gap(20))

        val displayName = prefs.getString("display_name", "Pengguna")?.trim().orEmpty().ifBlank { "Pengguna" }
        val initials = displayName.split(Regex("\\s+")).filter { it.isNotBlank() }
            .take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("").ifBlank { "SP" }
        val profileHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(16))
        }
        val avatar = TextView(this).apply {
            text = initials
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(green, 60)
        }
        profileHeader.addView(avatar, LinearLayout.LayoutParams(dp(68), dp(68)).apply { marginEnd = dp(13) })
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleColumn.addView(label("AKUN PENGGUNA", 10f, gold, true))
        titleColumn.addView(label(displayName, 19f, white, true).apply { setPadding(0, dp(4), 0, 0) })
        titleColumn.addView(label("Profil lokal · data tersimpan di perangkat", 10f, muted, false).apply {
            setPadding(0, dp(3), 0, 0)
        })
        profileHeader.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(profileHeader, matchWrap())

        val profileCard = card()
        profileCard.addView(label("INFORMASI PROFIL", 12f, white, true))
        val birthDate = prefs.getString("birth_date", "")?.takeIf { it.isNotBlank() }?.let { formatBirthDate(it) } ?: "Belum diisi"
        val province = prefs.getString("province", "")?.trim().orEmpty()
        val regency = prefs.getString("regency", "")?.trim().orEmpty()
        val district = prefs.getString("district", "")?.trim().orEmpty()
        val domicile = listOf(district, regency, province).filter { it.isNotBlank() }.joinToString(", ").ifBlank { "Belum diisi" }
        addAccountInfoRow(profileCard, "Tanggal lahir", birthDate)
        addAccountInfoRow(profileCard, "Usia saat ini", calculateAge(selectedBirthDate)?.let { "$it tahun" } ?: "Belum tersedia")
        addAccountInfoRow(profileCard, "Domisili", domicile)
        addAccountInfoRow(profileCard, "Pengalaman", prefs.getString("experience_level", "Belum diisi") ?: "Belum diisi")
        addAccountInfoRow(profileCard, "Strategi pilihan", prefs.getString("preferred_strategy", "Belum ditentukan") ?: "Belum ditentukan")
        content.addView(profileCard, matchWrap())
        content.addView(gap(12))

        val strategyCard = card()
        strategyCard.addView(label("ANALISIS STRATEGI", 12f, white, true))
        val strategy = prefs.getString("preferred_strategy", "Belum menentukan") ?: "Belum menentukan"
        val strategyDescription = when (strategy) {
            "Scalping" -> "Preferensi latihan dengan fokus pada pergerakan singkat. Perhatikan frekuensi order dan biaya yang terakumulasi."
            "Day Trading" -> "Preferensi latihan dengan fokus pada perubahan dalam satu hari. Perhatikan batas waktu dan perubahan volatilitas."
            "Swing Trading" -> "Preferensi latihan dengan fokus pada pergerakan beberapa hari. Harga dapat berbalik sebelum target tercapai."
            "Jangka Panjang" -> "Preferensi latihan dengan fokus pada perubahan jangka panjang. Evaluasi portofolio secara berkala, bukan tiap gerakan kecil."
            else -> "Belum ada strategi pilihan. Kamu dapat memilih strategi saat mengatur profil."
        }
        strategyCard.addView(label("Strategi pilihan: $strategy", 14f, gold, true).apply { setPadding(0, dp(10), 0, dp(4)) })
        strategyCard.addView(label(strategyDescription, 11f, muted, false).apply { setLineSpacing(dp(3).toFloat(), 1f) })
        val buyCount = records.count { it.type == "BELI" || it.type == "BOT BELI" }
        val sellCount = records.count { it.type == "JUAL" || it.type == "BOT JUAL" }
        val totalBuyBtc = records.filter { it.type == "BELI" || it.type == "BOT BELI" }.sumOf { it.btc }
        val totalBuyIdr = records.filter { it.type == "BELI" || it.type == "BOT BELI" }.sumOf { it.idr }
        val avgBuyPrice = if (totalBuyBtc > 0.0) totalBuyIdr / totalBuyBtc else 0.0
        strategyCard.addView(gap(10))
        addAccountInfoRow(strategyCard, "Total order", "${records.size}")
        addAccountInfoRow(strategyCard, "Order beli", "$buyCount")
        addAccountInfoRow(strategyCard, "Order jual", "$sellCount")
        addAccountInfoRow(strategyCard, "Rata-rata harga beli tercatat", if (avgBuyPrice > 0.0) formatIdr(avgBuyPrice) else "Belum ada pembelian")
        strategyCard.addView(label("Ringkasan aktivitas, bukan penilaian performa atau saran investasi.", 9f, muted, false).apply {
            setPadding(0, dp(8), 0, 0)
        })
        content.addView(strategyCard, matchWrap())
        content.addView(gap(12))

        val portfolioCard = card()
        portfolioCard.addView(label("PORTOFOLIO", 12f, white, true))
        addAccountInfoRow(portfolioCard, "Saldo IDR", formatIdr(virtualBalance))
        addAccountInfoRow(portfolioCard, "Kepemilikan BTC", String.format(Locale.US, "%.8f BTC", btcHolding))
        val btcValue = if (currentPrice > 0.0) btcHolding * currentPrice else 0.0
        addAccountInfoRow(portfolioCard, "Nilai BTC saat ini", formatIdr(btcValue))
        addAccountInfoRow(portfolioCard, "Total estimasi portofolio", formatIdr(virtualBalance + btcValue))
        content.addView(portfolioCard, matchWrap())
        content.addView(gap(12))

        val historyCard = card()
        historyCard.addView(label("RIWAYAT TRANSAKSI", 12f, white, true))
        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        historyCard.addView(historyContainer)
        content.addView(historyCard, matchWrap())
        renderHistory()
        content.addView(gap(14))
        content.addView(label("Tanggal lahir dan domisili hanya disimpan di perangkat. Jangan bagikan tangkapan layar profil jika berisi informasi pribadi.", 9f, muted, false).apply {
            setLineSpacing(dp(3).toFloat(), 1f)
        })
    }

    private fun addAccountInfoRow(parent: LinearLayout, title: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(9), 0, dp(8))
        }
        row.addView(label(title, 9f, muted, true))
        row.addView(label(value, 12f, white, false).apply {
            setPadding(0, dp(3), 0, 0)
            setLineSpacing(dp(2).toFloat(), 1f)
        })
        parent.addView(row, matchWrap())
        parent.addView(View(this).apply { setBackgroundColor(panelAlt) }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun dot(color: Int): View = View(this).apply {
        background = rounded(color, 20)
        layoutParams = LinearLayout.LayoutParams(dp(7), dp(7))
    }

    private fun showPracticeCreditPicker() {
        if (prefs.getBoolean("practice_credit_pending", false)) {
            toast("Kredit latihan sedang diproses. Tunggu sampai selesai sebelum memilih nominal baru.")
            return
        }
        val labels = practiceCreditOptions.map { amount ->
            "${formatIdr(amount.toDouble())}  ·  ${formatDelay(creditDelayMinutes(amount))}"
        }.toTypedArray()
        val selectedIndex = practiceCreditOptions.indexOf(selectedPracticeCredit).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("PILIH NOMINAL KREDIT LATIHAN")
            .setSingleChoiceItems(labels, selectedIndex) { dialog, which ->
                selectedPracticeCredit = practiceCreditOptions[which]
                prefs.edit().putLong("selected_practice_credit_amount", selectedPracticeCredit).apply()
                updateCreditUi()
                dialog.dismiss()
            }
            .setNegativeButton("TUTUP", null)
            .show()
    }

    private fun creditDelayMinutes(amount: Long): Int {
        val index = practiceCreditOptions.indexOf(amount).coerceAtLeast(0)
        val lastIndex = (practiceCreditOptions.size - 1).coerceAtLeast(1)
        // A strictly increasing preview: 2 minutes at the minimum and 180 at the maximum.
        return 2 + (index * 178 / lastIndex)
    }

    private fun formatDelay(totalMinutes: Int): String {
        return if (totalMinutes < 60) {
            "$totalMinutes menit"
        } else {
            val hours = totalMinutes / 60
            val minutes = totalMinutes % 60
            if (minutes == 0) "$hours jam" else "$hours jam $minutes menit"
        }
    }

    private fun startCreditChallenge() {
        if (prefs.getBoolean("practice_credit_pending", false)) {
            toast("Kredit latihan sedang diproses.")
            return
        }
        showCreditChallengeStep(0)
    }

    private fun showCreditChallengeStep(index: Int) {
        if (index >= creditChallengeSteps.size) {
            schedulePracticeCredit()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("PEMAHAMAN KREDIT LATIHAN · ${index + 1}/${creditChallengeSteps.size}")
            .setMessage(creditChallengeSteps[index])
            .setNegativeButton("BATAL", null)
            .setPositiveButton(if (index == creditChallengeSteps.lastIndex) "SELESAI" else "SAYA PAHAM") { _, _ ->
                showCreditChallengeStep(index + 1)
            }
            .show()
    }

    private fun schedulePracticeCredit() {
        val delayMinutes = creditDelayMinutes(selectedPracticeCredit)
        val dueAt = System.currentTimeMillis() + delayMinutes * 60_000L
        prefs.edit()
            .putBoolean("practice_credit_pending", true)
            .putLong("practice_credit_due_at", dueAt)
            .putString("practice_credit_amount", selectedPracticeCredit.toString())
            .apply()

        val alarmIntent = Intent(this, PracticeCreditReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            PracticeCreditReceiver.REQUEST_CODE,
            alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pendingIntent)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7331)
        }
        updateCreditUi()
        toast("Kredit latihan virtual dijadwalkan. Perkiraan tersedia dalam ${formatDelay(delayMinutes)}.")
    }

    private fun updateCreditUi() {
        if (!::creditStatusText.isInitialized || !::creditButton.isInitialized ||
            !::creditSelectionText.isInitialized || !::creditEstimateText.isInitialized ||
            !::creditSelectButton.isInitialized
        ) return

        val storedBalance = prefs.getString("practice_balance", "0")?.toDoubleOrNull() ?: 0.0
        if (storedBalance.isFinite() && storedBalance != virtualBalance) {
            virtualBalance = storedBalance
            if (::balanceText.isInitialized) balanceText.text = formatIdr(virtualBalance)
        }

        creditSelectionText.text = "Nominal kredit latihan: ${formatIdr(selectedPracticeCredit.toDouble())}"
        val estimate = formatDelay(creditDelayMinutes(selectedPracticeCredit))
        creditEstimateText.text = "Estimasi tersedia: $estimate setelah 26 langkah pemahaman selesai. Timer ini hanya untuk kredit virtual; tidak ada pembayaran atau deposit uang."

        val pending = prefs.getBoolean("practice_credit_pending", false)
        if (pending) {
            val dueAt = prefs.getLong("practice_credit_due_at", System.currentTimeMillis())
            val remaining = ((dueAt - System.currentTimeMillis()).coerceAtLeast(0L) + 999L) / 1000L
            val hours = remaining / 3600L
            val minutes = (remaining % 3600L) / 60L
            val seconds = remaining % 60L
            val countdown = if (hours > 0L) {
                "${hours}j ${minutes}m ${seconds}d"
            } else {
                "${minutes}:${String.format(Locale.US, "%02d", seconds)}"
            }
            val pendingAmount = prefs.getString("practice_credit_amount", selectedPracticeCredit.toString())
                ?.toLongOrNull() ?: selectedPracticeCredit
            creditStatusText.text = "Kredit virtual ${formatIdr(pendingAmount.toDouble())} sedang diproses · $countdown"
            creditButton.text = "KREDIT LATIHAN SEDANG DIPROSES"
            creditButton.isEnabled = false
            creditButton.alpha = 0.55f
            creditSelectButton.isEnabled = false
            creditSelectButton.alpha = 0.55f
        } else {
            val claimCount = prefs.getInt("practice_credit_claim_count", 0)
            creditStatusText.text = if (claimCount > 0) {
                "Kredit latihan sebelumnya sudah ditambahkan. Kamu bisa memilih nominal lain untuk sesi latihan berikutnya."
            } else {
                "Saldo awal Rp0. Pilih salah satu dari ${practiceCreditOptions.size} nominal kredit virtual, lalu selesaikan 26 langkah pemahaman."
            }
            creditButton.text = "MULAI 26 LANGKAH PEMAHAMAN"
            creditButton.isEnabled = true
            creditButton.alpha = 1f
            creditSelectButton.isEnabled = true
            creditSelectButton.alpha = 1f
        }
    }

    private fun showOrderModeChooser(isBuy: Boolean) {
        val title = if (isBuy) "Beli Sebagai" else "Jual Sebagai"
        val options = arrayOf("BTC — jumlah Bitcoin", "Saldo (IDR) — nilai Rupiah")
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(options) { _, which ->
                val useBtc = (which == 0)
                activeOrderIsBuy = isBuy
                if (isBuy) {
                    buyByBtc = useBtc
                    prefs.edit().putBoolean("buy_as_btc", buyByBtc).apply()
                } else {
                    sellByBtc = useBtc
                    prefs.edit().putBoolean("sell_as_btc", sellByBtc).apply()
                }
                updateOrderModeInfo()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateOrderModeInfo() {
        if (!::buyAsButton.isInitialized || !::sellAsButton.isInitialized ||
            !::orderUnitInfoText.isInitialized || !::amountLabelText.isInitialized
        ) return

        val buyMode = if (buyByBtc) "BTC" else "Saldo (IDR)"
        val sellMode = if (sellByBtc) "BTC" else "Saldo (IDR)"
        buyAsButton.text = "$buyMode  ▾"
        sellAsButton.text = "$sellMode  ▾"

        val buyMaximumBtc = if (currentPrice > 0.0) {
            virtualBalance / (currentPrice * 1.001)
        } else 0.0
        val sellMaximumIdrNet = if (currentPrice > 0.0) {
            availableManualBtcForSell() * currentPrice * 0.999
        } else 0.0
        val buyDescription = if (buyByBtc) {
            "masukkan jumlah BTC yang ingin dibeli (saldo tersedia ${formatIdr(virtualBalance)}; maksimum sekitar ${formatBtc(buyMaximumBtc)} BTC)"
        } else {
            "masukkan total anggaran Rupiah termasuk biaya (saldo tersedia ${formatIdr(virtualBalance)})"
        }
        val sellDescription = if (sellByBtc) {
            "masukkan jumlah BTC yang ingin dijual (tersedia ${formatBtc(availableManualBtcForSell())} BTC di luar posisi bot)"
        } else {
            val maxText = if (currentPrice > 0.0) formatIdr(sellMaximumIdrNet) else "menunggu harga BTC"
            "masukkan target saldo Rupiah bersih setelah biaya (maksimum sekitar $maxText)"
        }
        orderUnitInfoText.text = "BELI ($buyMode): $buyDescription.\nJUAL ($sellMode): $sellDescription."

        if (::amountInput.isInitialized) {
            val activeMode = if (activeOrderIsBuy) buyMode else sellMode
            val activeAction = if (activeOrderIsBuy) "BELI" else "JUAL"
            amountLabelText.text = "Nominal transaksi · $activeAction ($activeMode)"
            amountInput.hint = when {
                activeOrderIsBuy && buyByBtc -> "Contoh BELI: 0.00050000 BTC"
                activeOrderIsBuy && !buyByBtc -> "Contoh BELI: 200000 IDR (termasuk biaya)"
                !activeOrderIsBuy && sellByBtc -> "Contoh JUAL: 0.00050000 BTC"
                else -> "Contoh JUAL: 200000 IDR (bersih diterima)"
            }
        }
        if (::maxAmountButton.isInitialized) {
            maxAmountButton.isEnabled = currentPrice > 0.0 &&
                if (activeOrderIsBuy) virtualBalance > 0.0 else availableManualBtcForSell() > 0.0
            maxAmountButton.alpha = if (maxAmountButton.isEnabled) 1f else 0.45f
        }
        updateOrderEstimate()
    }

    private fun fillMaximumOrderAmount() {
        if (currentPrice <= 0.0) {
            toast("Tunggu harga BTC/IDR dimuat terlebih dahulu.")
            return
        }
        val feeRate = 0.001
        val maxValue = when {
            activeOrderIsBuy && buyByBtc ->
                floor((virtualBalance / (currentPrice * (1.0 + feeRate))) * 100_000_000.0) / 100_000_000.0
            activeOrderIsBuy && !buyByBtc -> floor(virtualBalance)
            !activeOrderIsBuy && sellByBtc ->
                floor(availableManualBtcForSell() * 100_000_000.0) / 100_000_000.0
            else -> floor(availableManualBtcForSell() * currentPrice * (1.0 - feeRate))
        }
        if (!maxValue.isFinite() || maxValue <= 0.0) {
            toast(if (activeOrderIsBuy) "Saldo IDR belum cukup untuk membeli BTC." else "Belum ada BTC latihan yang bisa dijual.")
            return
        }
        val valueText = if ((activeOrderIsBuy && buyByBtc) || (!activeOrderIsBuy && sellByBtc)) {
            formatBtc(maxValue)
        } else {
            String.format(Locale.US, "%.0f", maxValue)
        }
        amountInput.setText(valueText)
        amountInput.setSelection(amountInput.text.length)
        updateOrderEstimate()
    }

    private fun updateOrderEstimate() {
        if (!::orderEstimateText.isInitialized || !::amountInput.isInitialized) return
        val amount = amountInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (amount == null || !amount.isFinite() || amount <= 0.0) {
            orderEstimateText.text = "Perkiraan jumlah BTC, nilai Rupiah, biaya 0,1%, dan saldo setelah order akan tampil saat nominal diisi."
            orderEstimateText.setTextColor(muted)
            return
        }
        if (currentPrice <= 0.0) {
            orderEstimateText.text = "Menunggu harga BTC/IDR untuk menghitung perkiraan order."
            orderEstimateText.setTextColor(muted)
            return
        }

        val feeRate = 0.001
        val lines = mutableListOf<String>()
        lines += "Harga grafik/order saat ini: ${formatIdr(currentPrice)} per BTC"
        var canProceed = marketFresh
        if (!marketFresh) lines += "Belum ada acuan BTC/IDR. Order akan tersedia setelah harga awal berhasil dimuat."
        if (activeOrderIsBuy) {
            val grossValue: Double
            val feeValue: Double
            val btcAmount: Double
            val totalSpend: Double
            if (buyByBtc) {
                btcAmount = amount
                grossValue = btcAmount * currentPrice
                feeValue = grossValue * feeRate
                totalSpend = grossValue + feeValue
            } else {
                // IDR amount is the full budget, fee included, so using the exact
                // available balance remains possible and cannot fail due to an extra fee.
                totalSpend = amount
                grossValue = totalSpend / (1.0 + feeRate)
                feeValue = totalSpend - grossValue
                btcAmount = grossValue / currentPrice
            }
            val remaining = virtualBalance - totalSpend
            lines += "Perkiraan BTC diterima: ${formatBtc(btcAmount)} BTC"
            lines += "Nilai BTC: ${formatIdr(grossValue)} · Biaya: ${formatIdr(feeValue)}"
            lines += "Total saldo terpakai: ${formatIdr(totalSpend)} · Sisa saldo: ${formatIdr(remaining.coerceAtLeast(0.0))}"
            if (totalSpend > virtualBalance + 1e-7) {
                canProceed = false
                lines += "Saldo kurang ${formatIdr(totalSpend - virtualBalance)}. Maksimum anggaran: ${formatIdr(virtualBalance)}."
            }
        } else {
            val btcAmount: Double
            val grossValue: Double
            val feeValue: Double
            val netReceive: Double
            if (sellByBtc) {
                btcAmount = amount
                grossValue = btcAmount * currentPrice
                feeValue = grossValue * feeRate
                netReceive = grossValue - feeValue
            } else {
                // IDR amount is the desired net proceeds after fee.
                netReceive = amount
                grossValue = netReceive / (1.0 - feeRate)
                feeValue = grossValue - netReceive
                btcAmount = grossValue / currentPrice
            }
            val remainingBtc = availableManualBtcForSell() - btcAmount
            lines += "Perkiraan BTC dijual: ${formatBtc(btcAmount)} BTC"
            lines += "Nilai bruto: ${formatIdr(grossValue)} · Biaya: ${formatIdr(feeValue)}"
            lines += "Saldo IDR diterima: ${formatIdr(netReceive)} · Sisa BTC: ${formatBtc(remainingBtc.coerceAtLeast(0.0))}"
            if (btcAmount > availableManualBtcForSell() + 1e-12) {
                canProceed = false
                val maxNet = availableManualBtcForSell() * currentPrice * (1.0 - feeRate)
                lines += "BTC tidak cukup. Maksimum saldo bersih yang dapat diterima: ${formatIdr(maxNet)}."
            }
        }
        orderEstimateText.text = lines.joinToString("\n")
        orderEstimateText.setTextColor(if (canProceed) muted else red)
    }

    private fun submitOrder(isBuy: Boolean) {
        activeOrderIsBuy = isBuy
        updateOrderModeInfo()
        val amount = amountInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (amount == null || !amount.isFinite() || amount <= 0.0) {
            toast("Masukkan nominal yang valid sesuai satuan yang dipilih.")
            return
        }
        if (!marketFresh || currentPrice <= 0.0) {
            toast("Harga awal BTC/IDR belum tersedia. Sambungkan internet untuk memuat acuan pertama.")
            return
        }

        val feeRate = 0.001
        if (isBuy) {
            val btcBought: Double
            val grossCostIdr: Double
            val totalCost: Double
            if (buyByBtc) {
                btcBought = amount
                grossCostIdr = btcBought * currentPrice
                totalCost = grossCostIdr * (1.0 + feeRate)
            } else {
                // In IDR mode, amount is the total budget with fee already included.
                totalCost = amount
                grossCostIdr = totalCost / (1.0 + feeRate)
                btcBought = grossCostIdr / currentPrice
            }
            if (!btcBought.isFinite() || !grossCostIdr.isFinite() ||
                !totalCost.isFinite() || totalCost > virtualBalance + 1e-7
            ) {
                val maxBtc = if (currentPrice > 0.0) virtualBalance / (currentPrice * (1.0 + feeRate)) else 0.0
                toast("Saldo tidak cukup. Anggaran maksimum ${formatIdr(virtualBalance)} atau sekitar ${formatBtc(maxBtc)} BTC.")
                updateOrderEstimate()
                return
            }
            val feeValue = totalCost - grossCostIdr
            virtualBalance = (virtualBalance - totalCost).coerceAtLeast(0.0)
            btcHolding += btcBought
            records.add(0, TradeRecord("BELI", grossCostIdr, btcBought, currentPrice, System.currentTimeMillis()))
            toast("Beli latihan berhasil: ${formatBtc(btcBought)} BTC · biaya ${formatIdr(feeValue)}.")
        } else {
            // In IDR mode, amount is the desired net Rupiah proceeds after fee.
            val btcToSell = if (sellByBtc) amount else amount / (currentPrice * (1.0 - feeRate))
            val manualBtcAvailable = availableManualBtcForSell()
            if (!btcToSell.isFinite() || btcToSell > manualBtcAvailable + 1e-12) {
                if (sellByBtc) {
                    toast("BTC latihan yang tersedia untuk order manual ${formatBtc(manualBtcAvailable)} BTC. BTC yang sedang dikelola bot tidak dapat dijual manual sampai bot dimatikan.")
                } else {
                    val maximumIdr = manualBtcAvailable * currentPrice * (1.0 - feeRate)
                    toast("Target melebihi saldo BTC. Maksimum bersih sekitar ${formatIdr(maximumIdr)}.")
                }
                updateOrderEstimate()
                return
            }
            val actualBtcToSell = min(btcToSell, manualBtcAvailable)
            val grossValueIdr = actualBtcToSell * currentPrice
            val feeValue = grossValueIdr * feeRate
            val netProceeds = grossValueIdr - feeValue
            virtualBalance += netProceeds
            btcHolding = (btcHolding - actualBtcToSell).coerceAtLeast(0.0)
            records.add(0, TradeRecord("JUAL", grossValueIdr, actualBtcToSell, currentPrice, System.currentTimeMillis()))
            toast("Jual latihan berhasil: ${formatIdr(netProceeds)} diterima · biaya ${formatIdr(feeValue)}.")
        }

        while (records.size > 30) records.removeAt(records.lastIndex)
        prefs.edit()
            .putString("practice_balance", virtualBalance.toString())
            .putString("btc_holding", btcHolding.toString())
            .putString("order_history", serializeRecords())
            .apply()
        amountInput.setText("")
        updatePortfolio()
        renderHistory()
    }

    private fun availableManualBtcForSell(): Double =
        (btcHolding - if (autoBotActive) autoBotOwnedBtc else 0.0).coerceAtLeast(0.0)

    private fun startAutoBot() {
        if (currentPrice <= 0.0 || !marketFresh) {
            toast("Tunggu harga BTC/IDR tersedia sebelum mengaktifkan Auto Miner.")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingAutoBotStart = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_AUTO_BOT_NOTIFICATION)
            toast("Izinkan notifikasi agar bot latar belakang selalu terlihat.")
            return
        }
        startAutoBotNow()
    }

    private fun startAutoBotNow() {
        if (AutoMinerService.isRunning()) {
            toast("Auto Miner sudah berjalan di latar belakang.")
            return
        }
        autoBotActive = true
        autoBotOwnedBtc = 0.0
        autoBotEntryCost = 0.0
        autoBotEntryPrice = 0.0
        autoBotEntryTime = 0L
        autoBotLastTradeAt = 0L
        prefs.edit().putBoolean("auto_bot_lucky_trade", false).apply()
        autoBotSessionStartedAt = System.currentTimeMillis()
        autoBotEvents.clear()
        addAutoBotEvent(BotTradeEvent(
            type = "INFO",
            time = autoBotSessionStartedAt,
            note = "Mode hoki virtual aktif: setiap posisi mendapat undian 60% untung / 40% rugi. Maksimal 95% saldo virtual per posisi, target bersih +1,6%, stop-loss -1,2%, rem sesi 3%. Hasil ini mekanik game, bukan prediksi pasar sungguhan."
        ))
        val sessionStartEquity = virtualBalance + btcHolding * currentPrice
        prefs.edit()
            .putBoolean("auto_bot_active", true)
            .putString("auto_bot_session_start_equity", sessionStartEquity.toString())
            .putString("auto_bot_peak_net_return", "0.0")
            .apply()
        saveAutoBotSession()
        try {
            AutoMinerService.start(this)
            updateAutoBotUi()
            toast("Auto Miner aktif. Bot tetap bekerja saat layar mati; notifikasi akan selalu ditampilkan.")
        } catch (error: Exception) {
            autoBotActive = false
            prefs.edit()
                .putBoolean("auto_bot_active", false)
                .putBoolean("auto_bot_service_running", false)
                .apply()
            saveAutoBotSession()
            updateAutoBotUi()
            toast("Bot gagal dijalankan: ${error.javaClass.simpleName}")
        }
    }

    private fun stopAutoBot(reason: String, showToast: Boolean) {
        if (AutoMinerService.isRunning()) {
            try {
                startService(Intent(this, AutoMinerService::class.java).setAction(AutoMinerService.ACTION_STOP))
                if (showToast) toast("Auto Miner sedang dihentikan dan laporan sesi diperbarui.")
            } catch (_: Exception) {
                toast("Tidak bisa mengirim perintah untuk mematikan bot.")
            }
            return
        }
        if (!autoBotActive) return
        autoBotActive = false
        val now = System.currentTimeMillis()
        val openBtc = autoBotOwnedBtc
        val openEntryCost = autoBotEntryCost
        if (openBtc > 0.0) {
            val estimatedNet = openBtc * currentPrice * (1.0 - 0.001)
            val estimatedPnl = estimatedNet - openEntryCost
            // The open BTC is not liquidated when the bot stops. It stays in the user's wallet.
            autoBotOwnedBtc = 0.0
            autoBotEntryCost = 0.0
            autoBotEntryPrice = 0.0
            autoBotEntryTime = 0L
            addAutoBotEvent(BotTradeEvent(
                type = "INFO",
                btc = openBtc,
                price = currentPrice,
                grossIdr = openBtc * currentPrice,
                feeIdr = openBtc * currentPrice * 0.001,
                cashFlowIdr = estimatedNet,
                realizedPnl = estimatedPnl,
                time = now,
                note = "Posisi ${formatBtc(openBtc)} BTC belum dijual dan tetap berada di portofolio. Estimasi P/L jika dijual sekarang: ${formatSignedIdr(estimatedPnl)}."
            ))
        } else {
            autoBotOwnedBtc = 0.0
            autoBotEntryCost = 0.0
            autoBotEntryPrice = 0.0
            autoBotEntryTime = 0L
        }
        addAutoBotEvent(BotTradeEvent(
            type = "INFO",
            time = now,
            note = reason
        ))
        prefs.edit().putBoolean("auto_bot_active", false).putBoolean("auto_bot_lucky_trade", false).apply()
        saveAutoBotSession()
        updateAutoBotUi()
        updateOrderModeInfo()
        updateOrderEstimate()
        if (showToast) toast("Auto Miner dimatikan. Laporan sesi sudah diperbarui.")
    }

    private fun processAutoBotTick() {
        if (!autoBotActive || !currentPrice.isFinite() || currentPrice <= 0.0 || !marketFresh) return
        val now = System.currentTimeMillis()
        val feeRate = 0.001
        val sessionStartEquity = prefs.getString("auto_bot_session_start_equity", "0")?.toDoubleOrNull() ?: 0.0
        val currentEquity = virtualBalance + btcHolding * currentPrice
        val sessionDrawdown = if (sessionStartEquity > 0.0) currentEquity / sessionStartEquity - 1.0 else 0.0
        val sessionRiskLimitReached = sessionDrawdown <= -0.03

        if (autoBotOwnedBtc > 0.0 && autoBotEntryCost > 0.0) {
            val estimatedNet = autoBotOwnedBtc * currentPrice * (1.0 - feeRate)
            val netReturn = estimatedNet / autoBotEntryCost - 1.0
            val peakNetReturn = maxOf(
                prefs.getString("auto_bot_peak_net_return", "0")?.toDoubleOrNull() ?: 0.0,
                netReturn
            )
            prefs.edit().putString("auto_bot_peak_net_return", peakNetReturn.toString()).apply()
            val exitReason = when {
                sessionRiskLimitReached -> "Rem otomatis: batas rugi sesi 3% tercapai"
                netReturn <= PracticeMarketConfig.BOT_STOP_LOSS_NET -> "Batas risiko posisi -1,2% tersentuh"
                netReturn >= PracticeMarketConfig.BOT_TAKE_PROFIT_NET -> "Target hasil bersih +1,6% tercapai"
                else -> null
            }
            if (exitReason != null) closeAutoBotPosition(exitReason, now)
            if (sessionRiskLimitReached) stopAutoBot("Rem otomatis aktif: nilai portofolio turun 3% dari awal sesi. Bot dihentikan untuk membatasi simulasi kerugian.", showToast = false)
            return
        }

        if (sessionRiskLimitReached) {
            stopAutoBot("Rem otomatis aktif: nilai portofolio turun 3% dari awal sesi. Bot dihentikan untuk membatasi simulasi kerugian.", showToast = false)
            return
        }
        if (now - autoBotLastTradeAt < PracticeMarketConfig.BOT_ENTRY_COOLDOWN_MS || virtualBalance < 1_000.0) return
        if (!hasBullishBotEntrySignal(pricePoints)) return
        val insideOutcomeRange = currentPrice >= PracticeMarketConfig.PRICE_FLOOR_IDR * 1.015 &&
            currentPrice <= PracticeMarketConfig.PRICE_CEILING_IDR / PracticeMarketConfig.BOT_WIN_PRICE_RATIO
        if (!insideOutcomeRange) return

        val totalSpend = min(virtualBalance * PracticeMarketConfig.BOT_POSITION_FRACTION, virtualBalance)
        if (!totalSpend.isFinite() || totalSpend < 1_000.0) return
        val grossValue = totalSpend / (1.0 + feeRate)
        val fee = totalSpend - grossValue
        val btcBought = grossValue / currentPrice
        if (!btcBought.isFinite() || btcBought <= 0.0) return

        virtualBalance = (virtualBalance - totalSpend).coerceAtLeast(0.0)
        btcHolding += btcBought
        autoBotOwnedBtc = btcBought
        autoBotEntryCost = totalSpend
        autoBotEntryPrice = currentPrice
        autoBotEntryTime = now
        autoBotLastTradeAt = now
        val luckyTrade = chartRandom.nextDouble() < PracticeMarketConfig.BOT_WIN_CHANCE
        prefs.edit()
            .putString("auto_bot_peak_net_return", "0.0")
            .putBoolean("auto_bot_lucky_trade", luckyTrade)
            .apply()
        val event = BotTradeEvent(
            type = "BELI",
            btc = btcBought,
            price = currentPrice,
            grossIdr = grossValue,
            feeIdr = fee,
            cashFlowIdr = totalSpend,
            time = now,
            note = if (luckyTrade) "Undian hoki virtual: skenario untung 60%; grafik bergerak ke target latihan" else "Undian hoki virtual: skenario rugi 40%; stop-loss latihan membatasi hasil"
        )
        records.add(0, TradeRecord("BOT BELI", grossValue, btcBought, currentPrice, now))
        trimAndSaveTradeRecords()
        addAutoBotEvent(event)
        updatePortfolio()
        renderHistory()
        updateAutoBotUi()
    }

    private fun calculateBotEma(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        val alpha = 2.0 / (period + 1.0)
        var result = values.first()
        for (value in values.drop(1)) result += alpha * (value - result)
        return result
    }

    private fun hasBullishBotEntrySignal(points: List<Double>): Boolean {
        if (points.size < 16) return false
        val sample = points.takeLast(18)
        val fast = calculateBotEma(sample, 5)
        val slow = calculateBotEma(sample, 13)
        val priorFast = calculateBotEma(sample.dropLast(3), 5)
        val price = sample.last()
        val previous = sample[sample.lastIndex - 1]
        val threeTicksAgo = sample[sample.lastIndex - 3]
        val fastSlope = if (priorFast > 0.0) fast / priorFast - 1.0 else 0.0
        val momentum = if (threeTicksAgo > 0.0) price / threeTicksAgo - 1.0 else 0.0
        val recentMoves = sample.takeLast(12).zipWithNext { a, b ->
            if (a > 0.0) kotlin.math.abs(b / a - 1.0) else 1.0
        }
        val averageVolatility = if (recentMoves.isNotEmpty()) recentMoves.average() else 1.0
        val trendUp = fast > slow * 1.00005 && fastSlope > 0.00002
        val rebound = price > previous && price >= threeTicksAgo * 0.999
        val nearTrend = price >= fast * 0.993 && price <= fast * 1.012
        val momentumOkay = momentum in -0.0004..0.0065
        return trendUp && rebound && nearTrend && momentumOkay && averageVolatility < 0.0045
    }

    private fun closeAutoBotPosition(reason: String, now: Long) {
        val btcSold = min(autoBotOwnedBtc, btcHolding)
        if (btcSold <= 0.0) {
            autoBotOwnedBtc = 0.0
            autoBotEntryCost = 0.0
            autoBotEntryPrice = 0.0
            autoBotEntryTime = 0L
            autoBotLastTradeAt = now
            prefs.edit().putBoolean("auto_bot_lucky_trade", false).apply()
            addAutoBotEvent(BotTradeEvent(type = "INFO", time = now, note = "Posisi bot tidak ditemukan di saldo; bot kembali memantau."))
            return
        }
        val grossValue = btcSold * currentPrice
        val fee = grossValue * 0.001
        val netProceeds = grossValue - fee
        val realizedPnl = netProceeds - autoBotEntryCost
        virtualBalance += netProceeds
        btcHolding = (btcHolding - btcSold).coerceAtLeast(0.0)
        records.add(0, TradeRecord("BOT JUAL", grossValue, btcSold, currentPrice, now))
        autoBotOwnedBtc = 0.0
        autoBotEntryCost = 0.0
        autoBotEntryPrice = 0.0
        autoBotEntryTime = 0L
        autoBotLastTradeAt = now
        prefs.edit()
            .putString("auto_bot_peak_net_return", "0.0")
            .putBoolean("auto_bot_lucky_trade", false)
            .apply()
        trimAndSaveTradeRecords()
        addAutoBotEvent(BotTradeEvent(
            type = "JUAL",
            btc = btcSold,
            price = currentPrice,
            grossIdr = grossValue,
            feeIdr = fee,
            cashFlowIdr = netProceeds,
            realizedPnl = realizedPnl,
            time = now,
            note = reason
        ))
        updatePortfolio()
        renderHistory()
        updateAutoBotUi()
    }

    private fun trimAndSaveTradeRecords() {
        while (records.size > 30) records.removeAt(records.lastIndex)
        prefs.edit()
            .putString("practice_balance", virtualBalance.toString())
            .putString("btc_holding", btcHolding.toString())
            .putString("order_history", serializeRecords())
            .apply()
        saveAutoBotSession()
    }

    private fun addAutoBotEvent(event: BotTradeEvent) {
        autoBotEvents.add(event)
        while (autoBotEvents.size > 500) autoBotEvents.removeAt(0)
        saveAutoBotSession()
        updateAutoBotUi()
    }

    private fun saveAutoBotSession() {
        val array = JSONArray()
        autoBotEvents.forEach { item ->
            array.put(JSONObject().apply {
                put("type", item.type)
                put("btc", item.btc)
                put("price", item.price)
                put("gross", item.grossIdr)
                put("fee", item.feeIdr)
                put("cash", item.cashFlowIdr)
                put("pnl", item.realizedPnl)
                put("time", item.time)
                put("note", item.note)
            })
        }
        prefs.edit()
            .putBoolean("auto_bot_active", autoBotActive)
            .putString("auto_bot_events", array.toString())
            .putString("auto_bot_owned_btc", autoBotOwnedBtc.toString())
            .putString("auto_bot_entry_cost", autoBotEntryCost.toString())
            .putString("auto_bot_entry_price", autoBotEntryPrice.toString())
            .putLong("auto_bot_entry_time", autoBotEntryTime)
            .putLong("auto_bot_last_trade_at", autoBotLastTradeAt)
            .putLong("auto_bot_session_started_at", autoBotSessionStartedAt)
            .apply()
    }

    private fun loadAutoBotSession() {
        autoBotEvents.clear()
        try {
            val array = JSONArray(prefs.getString("auto_bot_events", "[]") ?: "[]")
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                autoBotEvents.add(BotTradeEvent(
                    type = obj.optString("type", "INFO"),
                    btc = obj.optDouble("btc", 0.0),
                    price = obj.optDouble("price", 0.0),
                    grossIdr = obj.optDouble("gross", 0.0),
                    feeIdr = obj.optDouble("fee", 0.0),
                    cashFlowIdr = obj.optDouble("cash", 0.0),
                    realizedPnl = obj.optDouble("pnl", 0.0),
                    time = obj.optLong("time", 0L),
                    note = obj.optString("note", "")
                ))
            }
        } catch (_: Exception) {
            autoBotEvents.clear()
        }
        autoBotActive = AutoMinerService.isRunning() && prefs.getBoolean("auto_bot_active", false)
        autoBotOwnedBtc = prefs.getString("auto_bot_owned_btc", "0")?.toDoubleOrNull() ?: 0.0
        autoBotEntryCost = prefs.getString("auto_bot_entry_cost", "0")?.toDoubleOrNull() ?: 0.0
        autoBotEntryPrice = prefs.getString("auto_bot_entry_price", "0")?.toDoubleOrNull() ?: 0.0
        autoBotEntryTime = prefs.getLong("auto_bot_entry_time", 0L)
        autoBotLastTradeAt = prefs.getLong("auto_bot_last_trade_at", 0L)
        autoBotSessionStartedAt = prefs.getLong("auto_bot_session_started_at", 0L)
        if (prefs.getBoolean("auto_bot_active", false) && !autoBotActive) {
            val interruptedPosition = autoBotOwnedBtc
            if (interruptedPosition > 0.0) {
                val estimatedPnl = interruptedPosition * currentPrice * (1.0 - 0.001) - autoBotEntryCost
                autoBotEvents.add(BotTradeEvent(
                    type = "INFO",
                    btc = interruptedPosition,
                    price = currentPrice,
                    realizedPnl = estimatedPnl,
                    time = System.currentTimeMillis(),
                    note = "Sesi sebelumnya terhenti ketika posisi masih terbuka. ${formatBtc(interruptedPosition)} BTC tetap ada di portofolio; estimasi P/L terakhir ${formatSignedIdr(estimatedPnl)}."
                ))
            }
            autoBotEvents.add(BotTradeEvent(
                type = "INFO",
                time = System.currentTimeMillis(),
                note = "Bot tidak dilanjutkan otomatis setelah aplikasi dibuka kembali. Aktifkan lagi secara manual jika ingin memulai sesi baru."
            ))
            autoBotOwnedBtc = 0.0
            autoBotEntryCost = 0.0
            autoBotEntryPrice = 0.0
            autoBotEntryTime = 0L
            autoBotActive = false
            prefs.edit().putBoolean("auto_bot_service_running", false).apply()
            saveAutoBotSession()
        }
    }

    private fun syncBackgroundBotSnapshot() {
        virtualBalance = prefs.getString("practice_balance", "0")?.toDoubleOrNull() ?: virtualBalance
        btcHolding = prefs.getString("btc_holding", "0")?.toDoubleOrNull() ?: btcHolding
        marketReferencePrice = prefs.getString("market_reference_price", marketReferencePrice.toString())
            ?.toDoubleOrNull()?.takeIf { it > 0.0 } ?: marketReferencePrice
        currentPrice = prefs.getString("last_price", currentPrice.toString())
            ?.toDoubleOrNull()?.takeIf { it > 0.0 } ?: currentPrice
        marketFresh = marketReferencePrice > 0.0
        autoBotActive = prefs.getBoolean("auto_bot_active", false) && AutoMinerService.isRunning()
        autoBotOwnedBtc = prefs.getString("auto_bot_owned_btc", "0")?.toDoubleOrNull() ?: 0.0
        autoBotEntryCost = prefs.getString("auto_bot_entry_cost", "0")?.toDoubleOrNull() ?: 0.0
        autoBotEntryPrice = prefs.getString("auto_bot_entry_price", "0")?.toDoubleOrNull() ?: 0.0
        autoBotEntryTime = prefs.getLong("auto_bot_entry_time", 0L)
        autoBotLastTradeAt = prefs.getLong("auto_bot_last_trade_at", 0L)
        autoBotSessionStartedAt = prefs.getLong("auto_bot_session_started_at", autoBotSessionStartedAt)
        practiceTrendRegime = prefs.getInt("practice_trend_regime", practiceTrendRegime).coerceIn(-1, 1)
        practiceTrendTicksRemaining = prefs.getInt("practice_trend_ticks", practiceTrendTicksRemaining).coerceAtLeast(0)

        val chartJson = prefs.getString("price_chart", "[]") ?: "[]"
        if (chartJson != lastSyncedChartJson) {
            lastSyncedChartJson = chartJson
            pricePoints.clear()
            try {
                val chartArray = JSONArray(chartJson)
                for (index in 0 until chartArray.length()) {
                    val point = chartArray.optDouble(index, 0.0)
                    if (point.isFinite() && point > 0.0) pricePoints.add(point)
                }
            } catch (_: Exception) {
                pricePoints.clear()
            }
            if (pricePoints.isNotEmpty()) currentPrice = pricePoints.last()
            if (::chartView.isInitialized) chartView.setValues(pricePoints, animate = false)
        }

        val eventJson = prefs.getString("auto_bot_events", "[]") ?: "[]"
        if (eventJson != lastSyncedBotEventsJson) {
            lastSyncedBotEventsJson = eventJson
            autoBotEvents.clear()
            try {
                val eventArray = JSONArray(eventJson)
                for (index in 0 until eventArray.length()) {
                    val obj = eventArray.optJSONObject(index) ?: continue
                    autoBotEvents.add(BotTradeEvent(
                        type = obj.optString("type", "INFO"),
                        btc = obj.optDouble("btc", 0.0),
                        price = obj.optDouble("price", 0.0),
                        grossIdr = obj.optDouble("gross", 0.0),
                        feeIdr = obj.optDouble("fee", 0.0),
                        cashFlowIdr = obj.optDouble("cash", 0.0),
                        realizedPnl = obj.optDouble("pnl", 0.0),
                        time = obj.optLong("time", 0L),
                        note = obj.optString("note", "")
                    ))
                }
            } catch (_: Exception) {
                autoBotEvents.clear()
            }
        }

        val historyJson = prefs.getString("order_history", "[]") ?: "[]"
        if (historyJson != lastSyncedHistoryJson) {
            lastSyncedHistoryJson = historyJson
            loadRecords()
            if (::historyContainer.isInitialized) renderHistory()
        }
        if (::priceText.isInitialized && currentPrice > 0.0) priceText.text = formatIdr(currentPrice)
        if (::balanceText.isInitialized) updatePortfolio()
    }

    private fun updateAutoBotUi() {
        if (!::autoBotToggleButton.isInitialized || !::autoBotStatusText.isInitialized || !::autoBotReportText.isInitialized) return
        autoBotToggleButton.text = if (autoBotActive) "MATIKAN AUTO MINER" else "AKTIFKAN AUTO MINER"
        autoBotToggleButton.background = rounded(if (autoBotActive) red else green, 10)
        autoBotToggleButton.setTextColor(if (autoBotActive) Color.WHITE else Color.BLACK)
        autoBotToggleButton.contentDescription = if (autoBotActive) "Matikan Auto Miner" else "Aktifkan Auto Miner"

        autoBotStatusText.text = if (!autoBotActive) {
            "NONAKTIF · Bot berhenti. Lihat laporan transaksi sesi terakhir di bawah."
        } else if (autoBotOwnedBtc > 0.0) {
            val estimatedNet = autoBotOwnedBtc * currentPrice * (1.0 - 0.001)
            val pnl = estimatedNet - autoBotEntryCost
            "AKTIF · Layanan latar belakang · Memegang ${formatBtc(autoBotOwnedBtc)} BTC · P/L berjalan ${formatSignedIdr(pnl)}"
        } else if (virtualBalance < 1_000.0) {
            "AKTIF · Layanan latar belakang · Menunggu saldo IDR yang cukup untuk mencari peluang."
        } else {
            "AKTIF · Layanan latar belakang · Memantau grafik ${formatIdr(currentPrice)} dan menunggu peluang beli."
        }

        if (autoBotEvents.isEmpty()) {
            autoBotReportText.text = "Belum ada sesi Auto Miner. Aktifkan bot untuk mulai mencatat transaksi."
            return
        }
        val buys = autoBotEvents.count { it.type == "BELI" }
        val sells = autoBotEvents.count { it.type == "JUAL" }
        val realized = autoBotEvents.filter { it.type == "JUAL" }.sumOf { it.realizedPnl }
        val report = StringBuilder()
        report.append("Sesi: ")
            .append(if (autoBotSessionStartedAt > 0L) SimpleDateFormat("dd MMM, HH:mm:ss", Locale("id", "ID")).format(Date(autoBotSessionStartedAt)) else "tersimpan")
            .append("\nBeli: ").append(buys).append(" · Jual: ").append(sells)
            .append("\nP/L terealisasi: ").append(formatSignedIdr(realized))
            .append("\n\n")
        autoBotEvents.asReversed().forEach { item ->
            val time = if (item.time > 0L) SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date(item.time)) else "--:--:--"
            report.append(time).append(" · ")
            when (item.type) {
                "BELI" -> report.append("BOT BELI ").append(formatBtc(item.btc)).append(" BTC @ ")
                    .append(formatIdr(item.price)).append(" · total ").append(formatIdr(item.cashFlowIdr))
                    .append(" (biaya ").append(formatIdr(item.feeIdr)).append(")")
                "JUAL" -> report.append("BOT JUAL ").append(formatBtc(item.btc)).append(" BTC @ ")
                    .append(formatIdr(item.price)).append(" · bersih ").append(formatIdr(item.cashFlowIdr))
                    .append(" · P/L ").append(formatSignedIdr(item.realizedPnl))
                else -> report.append(item.note)
            }
            if (item.type == "BELI" || item.type == "JUAL") {
                if (item.note.isNotBlank()) report.append("\n  ").append(item.note)
            }
            report.append("\n\n")
        }
        autoBotReportText.text = report.toString().trim()
    }

    private fun formatSignedIdr(value: Double): String =
        (if (value >= 0.0) "+" else "-") + formatIdr(kotlin.math.abs(value))

    private fun fetchMarketData() {
        if (fetching) return
        fetching = true
        refreshButton.isEnabled = false
        marketStatusText.text = "Mengambil ticker BTC/IDR..."

        thread(name = "btc-market-fetch") {
            try {
                // Indodax's documented public summaries endpoint includes the BTC/IDR
                // last price and the 24-hour reference price. One request per second
                // is 60 requests/minute, below the documented 180 requests/minute cap.
                val summary = requestJson("https://indodax.com/api/summaries")
                val ticker = summary.getJSONObject("tickers").getJSONObject("btc_idr")
                val newPrice = ticker.optString("last", "0").toDoubleOrNull() ?: 0.0
                val previousPrice = summary.getJSONObject("prices_24h")
                    .optString("btcidr", "0").toDoubleOrNull() ?: 0.0
                if (newPrice <= 0.0) throw IllegalStateException("Harga BTC/IDR tidak valid")
                val newChange = if (previousPrice > 0.0) {
                    ((newPrice - previousPrice) / previousPrice) * 100.0
                } else {
                    0.0
                }

                runOnUiThread {
                    val now = System.currentTimeMillis()
                    marketReferencePrice = newPrice
                    change24h = newChange
                    marketFresh = true

                    // During a background bot session the foreground service owns the
                    // current chart price. A fresh ticker response updates only its anchor.
                    val serviceOwnsPrice = AutoMinerService.isRunning() && prefs.getBoolean("auto_bot_active", false)
                    if (serviceOwnsPrice) {
                        currentPrice = prefs.getString("last_price", currentPrice.toString())
                            ?.toDoubleOrNull()?.takeIf { it > 0.0 } ?: currentPrice
                    } else {
                        if (pricePoints.isEmpty()) seedPracticeChart(effectivePracticeAnchor())
                        currentPrice = pricePoints.lastOrNull() ?: newPrice
                    }

                    val marketEditor = prefs.edit()
                        .putString("market_reference_price", marketReferencePrice.toString())
                        .putString("last_change", change24h.toString())
                    if (!serviceOwnsPrice) marketEditor.putString("last_price", currentPrice.toString())
                    marketEditor.apply()
                    if (serviceOwnsPrice) syncBackgroundBotSnapshot()
                    priceText.text = formatIdr(currentPrice)
                    updatePortfolio()
                    updateRtpUi()
                    updateOrderEstimate()
                    changeText.text = "Acuan pasar 24 jam: ${formatChange(change24h)}"
                    changeText.setTextColor(if (change24h >= 0.0) green else red)
                    val stamp = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date(now))
                    lastMarketStamp = "Acuan ticker Indodax · $stamp"
                    nextQuoteAt = now + quoteIntervalMs
                    marketStatusText.text = "$lastMarketStamp · harga grafik/order latihan berubah tiap 1 dtk"
                    chartView.setValues(pricePoints, animate = false)
                }
            } catch (_: Exception) {
                runOnUiThread {
                    // A previously received anchor is enough to keep the local practice
                    // market running, and its visible chart price remains tradable.
                    marketFresh = marketReferencePrice > 0.0
                    lastMarketStamp = "Ticker Indodax tidak tersedia"
                    nextQuoteAt = System.currentTimeMillis() + quoteRetryIntervalMs
                    marketStatusText.text = "$lastMarketStamp · grafik dan harga order memakai simulasi lokal pada acuan terakhir"
                    if (currentPrice <= 0.0) priceText.text = "Harga belum tersedia"
                    else priceText.text = formatIdr(currentPrice)
                    changeText.text = "Acuan pasar terputus · harga latihan tetap mengikuti grafik"
                    changeText.setTextColor(muted)
                }
            } finally {
                runOnUiThread {
                    fetching = false
                    refreshButton.isEnabled = true
                }
            }
        }
    }

    private fun updateRtpUi() {
        if (!::rtpContainer.isInitialized) return
        val now = System.currentTimeMillis()
        // Avoid rebuilding the forecast rows every second; refresh the projection periodically.
        if (rtpContainer.childCount > 0 && now - lastRtpUiUpdateAt < 15_000L) return
        lastRtpUiUpdateAt = now
        rtpContainer.removeAllViews()
        if (currentPrice <= 0.0) {
            rtpContainer.addView(label("Menunggu data BTC/IDR untuk menyusun perkiraan.", 10f, muted, false))
            return
        }

        val nextSixAm = java.util.Calendar.getInstance().apply {
            timeInMillis = now
            set(java.util.Calendar.HOUR_OF_DAY, 6)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
            if (timeInMillis <= now) add(java.util.Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis

        val checkpoints = listOf(
            Triple("1 JAM", now + 60L * 60L * 1000L, "Perkiraan satu jam ke depan"),
            Triple("6 JAM", now + 6L * 60L * 60L * 1000L, "Perkiraan enam jam ke depan"),
            Triple("PUKUL 06.00", nextSixAm, "Perkiraan pada pukul 06.00 berikutnya"),
            Triple("24 JAM", now + 24L * 60L * 60L * 1000L, "Perkiraan satu hari ke depan")
        )
        val timeFormat = SimpleDateFormat("dd MMM yyyy · HH:mm", Locale("id", "ID"))
        checkpoints.forEachIndexed { index, checkpoint ->
            val horizonHours = ((checkpoint.second - now).coerceAtLeast(1L)).toDouble() / 3_600_000.0
            // A deliberately conservative heuristic: only a small fraction of the
            // current 24h move is carried forward, with a widening scenario band.
            // This is not a statistically calibrated forecast.
            val centerPct = (change24h * (horizonHours / 24.0) * 0.35).coerceIn(-2.0, 2.0)
            val uncertaintyPct = (0.25 + 0.18 * kotlin.math.sqrt(horizonHours / 6.0)).coerceIn(0.25, 0.85)
            val lowerPct = centerPct - uncertaintyPct
            val upperPct = centerPct + uncertaintyPct
            val direction = when {
                centerPct > 0.03 -> "Cenderung naik"
                centerPct < -0.03 -> "Cenderung turun"
                else -> "Belum ada arah kuat"
            }
            val directionColor = when {
                centerPct > 0.03 -> green
                centerPct < -0.03 -> red
                else -> muted
            }

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(7))
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label("${checkpoint.first} · ${timeFormat.format(Date(checkpoint.second))}", 11f, white, true))
            info.addView(label(direction, 10f, directionColor, true).apply {
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val projection = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.END
            }
            projection.addView(label(formatSignedPercent(centerPct), 12f, directionColor, true).apply {
                gravity = Gravity.END
            })
            val range = "Rentang ${formatSignedPercent(lowerPct)} s/d ${formatSignedPercent(upperPct)}"
            projection.addView(label(range, 9f, muted, false).apply {
                gravity = Gravity.END
                setPadding(0, dp(2), 0, 0)
            })
            row.addView(projection)
            rtpContainer.addView(row)
            if (index < checkpoints.lastIndex) {
                rtpContainer.addView(View(this).apply { setBackgroundColor(panelAlt) },
                    LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
        val sourceStatus = if (marketFresh) "Acuan pasar tersedia" else "Menunggu acuan pasar pertama"
        rtpContainer.addView(label(
            "$sourceStatus · acuan: ${formatChange(change24h)}. Rentang adalah skenario latihan, bukan peluang teruji atau janji profit.",
            9f, muted, false
        ).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun formatSignedPercent(value: Double): String {
        val prefix = if (value >= 0.0) "+" else "−"
        return prefix + String.format(Locale.US, "%.2f%%", kotlin.math.abs(value))
    }

    private fun requestJson(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "SatoshiPractice/0.5.4 Android")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun updatePortfolio() {
        balanceText.text = formatIdr(virtualBalance)
        btcText.text = String.format(Locale.US, "%.8f BTC", btcHolding)
        val estimated = if (currentPrice > 0.0) btcHolding * currentPrice else 0.0
        holdingValueText.text = "Nilai perkiraan: ${formatIdr(estimated)}"
        updateOrderModeInfo()
        updateOrderEstimate()
        updateRtpUi()
        updateCreditUi()
    }

    private fun renderHistory() {
        historyContainer.removeAllViews()
        if (records.isEmpty()) {
            historyContainer.addView(label("Belum ada order. Transaksi latihan akan muncul di sini.", 11f, muted, false).apply {
                setPadding(0, dp(5), 0, dp(4))
            })
            return
        }
        records.take(10).forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(9), 0, dp(9))
            }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val typeColor = if (item.type == "BELI" || item.type == "BOT BELI") green else gold
            details.addView(label(item.type + " BTC", 12f, typeColor, true))
            val time = SimpleDateFormat("dd MMM, HH:mm", Locale("id", "ID")).format(Date(item.time))
            details.addView(label("$time · ${String.format(Locale.US, "%.8f", item.btc)} BTC", 10f, muted, false).apply {
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(formatIdr(item.idr), 12f, white, true))
            historyContainer.addView(row)
            if (index < records.take(10).lastIndex) {
                historyContainer.addView(View(this).apply { setBackgroundColor(panelAlt) },
                    LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
    }

    private fun loadRecords() {
        records.clear()
        val raw = prefs.getString("order_history", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                records.add(
                    TradeRecord(
                        obj.optString("type", "BELI"),
                        obj.optDouble("idr", 0.0),
                        obj.optDouble("btc", 0.0),
                        obj.optDouble("price", 0.0),
                        obj.optLong("time", 0L)
                    )
                )
            }
        } catch (_: Exception) {
            records.clear()
        }
    }

    private fun serializeRecords(): String {
        val array = JSONArray()
        records.forEach { item ->
            array.put(JSONObject().apply {
                put("type", item.type)
                put("idr", item.idr)
                put("btc", item.btc)
                put("price", item.price)
                put("time", item.time)
            })
        }
        return array.toString()
    }

    private fun seedPracticeChart(anchor: Double) {
        if (!anchor.isFinite() || anchor <= 0.0) return
        pricePoints.clear()
        var value = anchor
        repeat(90) {
            value = nextPracticeChartValue(value, anchor)
            pricePoints.add(value)
        }
        saveCachedChart()
    }

    private fun appendPracticeChartPoint(anchor: Double) {
        if (!anchor.isFinite() || anchor <= 0.0) return
        if (pricePoints.isEmpty()) {
            seedPracticeChart(anchor)
            return
        }
        val next = nextPracticeChartValue(pricePoints.last(), anchor)
        pricePoints.add(next)
        while (pricePoints.size > 90) pricePoints.removeAt(0)
        saveCachedChart()
    }

    private fun effectivePracticeAnchor(): Double {
        val base = marketReferencePrice.takeIf { it > 0.0 } ?: currentPrice
        return (base + manualPriceBoostIdr).coerceIn(
            PracticeMarketConfig.PRICE_FLOOR_IDR,
            PracticeMarketConfig.PRICE_CEILING_IDR
        )
    }

    private fun handleUpTap(button: Button) {
        upTapCount += 1
        if (upTapCount >= 50) {
            upTapCount = 0
            manualPriceBoostIdr += 1.0
            if (pricePoints.isNotEmpty()) {
                pricePoints[pricePoints.lastIndex] = (pricePoints.last() + 1.0).coerceIn(
                    PracticeMarketConfig.PRICE_FLOOR_IDR, PracticeMarketConfig.PRICE_CEILING_IDR
                )
                currentPrice = pricePoints.last()
                saveCachedChart()
            } else if (currentPrice > 0.0) {
                currentPrice = (currentPrice + 1.0).coerceIn(
                    PracticeMarketConfig.PRICE_FLOOR_IDR, PracticeMarketConfig.PRICE_CEILING_IDR
                )
            }
            prefs.edit()
                .putString("manual_price_boost_idr", manualPriceBoostIdr.toString())
                .putString("last_price", currentPrice.toString())
                .apply()
            if (::priceText.isInitialized && currentPrice > 0.0) priceText.text = formatIdr(currentPrice)
            if (::chartView.isInitialized) chartView.setValues(pricePoints, animate = false)
            updatePortfolio()
            updateRtpUi()
            updateOrderEstimate()
            toast("UP berhasil: harga latihan bertambah Rp1.")
        }
        prefs.edit().putInt("up_tap_count", upTapCount).apply()
        button.text = "UP $upTapCount/50"
    }

    private fun nextPracticeChartValue(previous: Double, anchor: Double): Double {
        // Local game chart only: hard-bounded between Rp1.11B and Rp1.20B.
        // Background trend phases are weighted 60/40, and an open bot position
        // follows its own random virtual win/loss draw until its exit threshold.
        val floor = PracticeMarketConfig.PRICE_FLOOR_IDR
        val ceiling = PracticeMarketConfig.PRICE_CEILING_IDR
        if (!previous.isFinite() || previous <= 0.0 || !anchor.isFinite() || anchor <= 0.0) {
            return anchor.coerceIn(floor, ceiling)
        }
        val safePrevious = previous.coerceIn(floor, ceiling)
        val safeAnchor = anchor.coerceIn(floor, ceiling)

        if (practiceTrendTicksRemaining <= 0) {
            practiceTrendRegime = if (chartRandom.nextDouble() < PracticeMarketConfig.BULL_PHASE_CHANCE) 1 else -1
            practiceTrendTicksRemaining = 25 + chartRandom.nextInt(36) // 25-60 seconds
        }
        practiceTrendTicksRemaining -= 1

        val displacement = ((safeAnchor - safePrevious) / safeAnchor).coerceIn(-0.06, 0.06)
        val drift = if (practiceTrendRegime > 0) 0.00048 else -0.00072
        val noise = if (practiceTrendRegime > 0) 0.00115 else 0.00125
        val meanReversion = if (practiceTrendRegime > 0) 0.035 else 0.045
        var movement = drift + chartRandom.nextGaussian() * noise + displacement * meanReversion

        val eventRoll = chartRandom.nextDouble()
        val pumpChance = if (practiceTrendRegime > 0 && safePrevious < ceiling * 0.995) 0.009 else 0.0015
        val dumpChance = if (practiceTrendRegime < 0 && safePrevious > floor * 1.005) 0.009 else 0.0015
        when {
            eventRoll < dumpChance -> movement -= 0.012 + chartRandom.nextDouble() * 0.012
            eventRoll < dumpChance + pumpChance -> movement += 0.012 + chartRandom.nextDouble() * 0.012
            practiceTrendRegime < 0 && eventRoll > 0.985 -> movement -= 0.004 + chartRandom.nextDouble() * 0.006
            practiceTrendRegime > 0 && eventRoll > 0.985 -> movement += 0.004 + chartRandom.nextDouble() * 0.006
        }

        val botPositionOpen = prefs.getBoolean("auto_bot_active", false) &&
            (prefs.getString("auto_bot_owned_btc", "0")?.toDoubleOrNull() ?: 0.0) > 0.0
        val botEntryPrice = prefs.getString("auto_bot_entry_price", "0")?.toDoubleOrNull() ?: 0.0
        if (botPositionOpen && botEntryPrice > 0.0) {
            val luckyWin = prefs.getBoolean("auto_bot_lucky_trade", false)
            val outcomeTarget = botEntryPrice * if (luckyWin) PracticeMarketConfig.BOT_WIN_PRICE_RATIO else PracticeMarketConfig.BOT_LOSS_PRICE_RATIO
            val directedStep = 0.00045 + chartRandom.nextDouble() * 0.00025
            if (luckyWin && safePrevious < outcomeTarget) movement = maxOf(movement, directedStep)
            else if (!luckyWin && safePrevious > outcomeTarget) movement = minOf(movement, -directedStep)
        }
        return (safePrevious * (1.0 + movement)).coerceIn(floor, ceiling)
    }

    private fun loadCachedChart() {
        pricePoints.clear()
        try {
            val array = JSONArray(prefs.getString("price_chart", "[]") ?: "[]")
            for (i in 0 until array.length()) {
                val value = array.optDouble(i, 0.0)
                if (value > 0.0) pricePoints.add(value)
            }
        } catch (_: Exception) {
            pricePoints.clear()
        }
    }

    private fun saveCachedChart() {
        val array = JSONArray()
        pricePoints.forEach { array.put(it) }
        prefs.edit()
            .putString("price_chart", array.toString())
            .putInt("practice_trend_regime", practiceTrendRegime)
            .putInt("practice_trend_ticks", practiceTrendTicksRemaining)
            .apply()
    }

    private fun formatBtc(value: Double): String = String.format(Locale.US, "%.8f", value.coerceAtLeast(0.0))

    private fun formatIdr(value: Double): String {
        val number = NumberFormat.getNumberInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 0
            minimumFractionDigits = 0
        }
        return "Rp ${number.format(value)}"
    }

    private fun formatChange(value: Double): String {
        val sign = if (value >= 0.0) "+" else ""
        return "${sign}${String.format(Locale.US, "%.2f", value)}%  ·  24 jam"
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD)
            else Typeface.create("sans-serif", Typeface.NORMAL)
            includeFontPadding = true
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = rounded(panel, 14)
        }
    }

    private fun button(value: String, color: Int, textColor: Int): Button {
        return Button(this).apply {
            text = value
            textSize = 12f
            setTextColor(textColor)
            isAllCaps = false
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = rounded(color, 10)
            stateListAnimator = null
            minHeight = dp(44)
            minimumHeight = dp(44)
            setPadding(dp(10), 0, dp(10), 0)
        }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun gap(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    companion object {
        private const val REQUEST_AUTO_BOT_NOTIFICATION = 5302
    }

    private data class TradeRecord(
        val type: String,
        val idr: Double,
        val btc: Double,
        val price: Double,
        val time: Long
    )

    private data class BotTradeEvent(
        val type: String,
        val btc: Double = 0.0,
        val price: Double = 0.0,
        val grossIdr: Double = 0.0,
        val feeIdr: Double = 0.0,
        val cashFlowIdr: Double = 0.0,
        val realizedPnl: Double = 0.0,
        val time: Long = 0L,
        val note: String = ""
    )

    private inner class MarketChartView : View(this@MainActivity) {
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x28FFFFFF
            strokeWidth = dp(1).toFloat()
        }
        private val upPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = green
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        private val downPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = red
            style = Paint.Style.STROKE
            strokeWidth = dp(2).toFloat()
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = white }
        private val markerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * resources.displayMetrics.density
        }
        private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = dp(9).toFloat()
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = dp(11).toFloat()
            textAlign = Paint.Align.CENTER
        }
        private var values: List<Double> = emptyList()
        private var revealProgress = 1f
        private var pulseProgress = 0f
        private var revealAnimator: ValueAnimator? = null
        private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1150L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = LinearInterpolator()
            addUpdateListener {
                pulseProgress = it.animatedValue as Float
                invalidate()
            }
        }

        fun setValues(data: List<Double>, animate: Boolean = true) {
            values = data.filter { it.isFinite() && it > 0.0 }.toList()
            revealAnimator?.cancel()
            if (animate && values.size >= 2) {
                revealProgress = 0f
                revealAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 850L
                    interpolator = LinearInterpolator()
                    addUpdateListener {
                        revealProgress = it.animatedValue as Float
                        invalidate()
                    }
                    start()
                }
            } else {
                revealProgress = 1f
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            if (!pulseAnimator.isStarted) pulseAnimator.start()
        }

        override fun onDetachedFromWindow() {
            revealAnimator?.cancel()
            pulseAnimator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val left = dp(7).toFloat()
            val right = width - dp(7).toFloat()
            val top = dp(13).toFloat()
            val bottom = height - dp(25).toFloat()
            val plotWidth = right - left
            val plotHeight = bottom - top

            // Exchange-style grid: horizontal price levels and vertical time divisions.
            for (i in 0..4) {
                val y = top + plotHeight * i / 4f
                canvas.drawLine(left, y, right, y, gridPaint)
            }
            for (i in 0..6) {
                val x = left + plotWidth * i / 6f
                canvas.drawLine(x, top, x, bottom, gridPaint)
            }

            val timeLabels = listOf("90s", "75s", "60s", "45s", "30s", "15s", "NOW")
            timeLabels.forEachIndexed { index, text ->
                val x = left + plotWidth * index / 6f
                val align = when (index) {
                    0 -> Paint.Align.LEFT
                    6 -> Paint.Align.RIGHT
                    else -> Paint.Align.CENTER
                }
                axisPaint.textAlign = align
                canvas.drawText(text, x, height - dp(5).toFloat(), axisPaint)
            }

            if (values.size < 2 || plotWidth <= 0f || plotHeight <= 0f) {
                canvas.drawText("Menunggu data pergerakan harga...", width / 2f, height / 2f, emptyPaint)
                return
            }

            val minValue = values.minOrNull() ?: return
            val maxValue = values.maxOrNull() ?: return
            val rawRange = maxValue - minValue
            val padding = if (rawRange > 0.0) rawRange * 0.10 else max(maxValue * 0.001, 1.0)
            val low = minValue - padding
            val high = maxValue + padding
            val range = max(high - low, 1.0)

            fun pointX(index: Int): Float = left + plotWidth * index / (values.size - 1).toFloat()
            fun pointY(value: Double): Float = bottom - ((value - low) / range).toFloat() * plotHeight

            // Draw a very soft tinted area under the visible price curve.
            val segmentCount = values.size - 1
            val progressAcross = revealProgress * segmentCount
            val lastCompleteIndex = progressAcross.toInt().coerceIn(0, segmentCount)
            val partial = (progressAcross - lastCompleteIndex).coerceIn(0f, 1f)
            var endX = pointX(0)
            var endY = pointY(values[0])
            val curve = Path().apply { moveTo(endX, endY) }

            for (i in 0 until segmentCount) {
                if (i > progressAcross) break
                val fraction = if (i < lastCompleteIndex) 1f else partial
                if (fraction <= 0f) break
                val x1 = pointX(i)
                val y1 = pointY(values[i])
                val x2 = pointX(i + 1)
                val y2 = pointY(values[i + 1])
                endX = x1 + (x2 - x1) * fraction
                endY = y1 + (y2 - y1) * fraction
                curve.lineTo(endX, endY)
            }

            val tint = if (values.last() >= values.first()) green else red
            val area = Path().apply {
                moveTo(pointX(0), bottom)
                lineTo(pointX(0), pointY(values[0]))
                addPath(curve)
                lineTo(endX, bottom)
                close()
            }
            val areaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                shader = LinearGradient(
                    0f, top, 0f, bottom,
                    (tint and 0x00FFFFFF) or 0x26000000,
                    (tint and 0x00FFFFFF) or 0x00000000,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawPath(area, areaPaint)

            // Each segment is green when the sampled market price rises, red when it falls.
            canvas.save()
            canvas.clipRect(left, top - dp(2), right, bottom + dp(2))
            for (i in 0 until segmentCount) {
                if (i > progressAcross) break
                val fraction = if (i < lastCompleteIndex) 1f else partial
                if (fraction <= 0f) break
                val x1 = pointX(i)
                val y1 = pointY(values[i])
                val x2 = pointX(i + 1)
                val y2 = pointY(values[i + 1])
                val visibleX = x1 + (x2 - x1) * fraction
                val visibleY = y1 + (y2 - y1) * fraction
                val paint = if (values[i + 1] >= values[i]) upPaint else downPaint
                canvas.drawLine(x1, y1, visibleX, visibleY, paint)
            }
            canvas.restore()

            // A pulsing point marks the latest practice-volatility sample.
            val latestValue = if (progressAcross >= segmentCount) values.last() else {
                val index = lastCompleteIndex.coerceIn(0, segmentCount - 1)
                values[index] + (values[index + 1] - values[index]) * partial.toDouble()
            }
            val latestX = if (progressAcross >= segmentCount) right else endX
            val latestY = pointY(latestValue)
            val latestColor = if (values.last() >= values[values.lastIndex - 1]) green else red
            markerRingPaint.color = latestColor
            markerRingPaint.alpha = (100 + pulseProgress * 100).toInt().coerceIn(100, 200)
            canvas.drawCircle(latestX, latestY, dp(5).toFloat() + pulseProgress * dp(4), markerRingPaint)
            markerPaint.color = latestColor
            canvas.drawCircle(latestX, latestY, dp(3).toFloat(), markerPaint)
        }
    }
}