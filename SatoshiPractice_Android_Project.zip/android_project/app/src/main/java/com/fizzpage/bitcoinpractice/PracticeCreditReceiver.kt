package com.fizzpage.bitcoinpractice

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Adds local-only practice credits after the educational delay. No payment is processed. */
class PracticeCreditReceiver : BroadcastReceiver() {
    companion object {
        const val REQUEST_CODE = 42017
        private const val NOTIFICATION_ID = 42018
        private const val CHANNEL_ID = "practice_credit_updates"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("satoshi_practice", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("practice_credit_pending", false)) return

        val dueAt = prefs.getLong("practice_credit_due_at", 0L)
        val now = System.currentTimeMillis()
        if (dueAt > now) {
            val retryIntent = Intent(context, PracticeCreditReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                context,
                REQUEST_CODE,
                retryIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pending)
            return
        }

        val amount = prefs.getString("practice_credit_amount", "1000000")?.toDoubleOrNull() ?: 1_000_000.0
        val current = prefs.getString("practice_balance", "0")?.toDoubleOrNull() ?: 0.0
        prefs.edit()
            .putString("practice_balance", (current + amount).toString())
            .putBoolean("practice_credit_pending", false)
            .putLong("practice_credit_due_at", 0L)
            .putInt("practice_credit_claim_count", prefs.getInt("practice_credit_claim_count", 0) + 1)
            .apply()

        showNotification(context, amount)
    }

    @Suppress("DEPRECATION")
    private fun showNotification(context: Context, amount: Double) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Pembaruan kredit latihan",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Pemberitahuan saat kredit latihan virtual ditambahkan."
            }
            manager.createNotificationChannel(channel)
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(
            context,
            REQUEST_CODE,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val formattedAmount = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID")).format(amount)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_ID)
        } else {
            Notification.Builder(context)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Kredit latihan berhasil ditambahkan")
            .setContentText("Rp $formattedAmount kredit virtual sudah masuk ke saldo latihan.")
            .setStyle(Notification.BigTextStyle().bigText("Rp $formattedAmount kredit virtual sudah masuk ke saldo Satoshi Practice. Kredit ini tidak memiliki nilai tunai dan tidak dapat dicairkan."))
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()
        manager.notify(NOTIFICATION_ID, notification)
    }
}
