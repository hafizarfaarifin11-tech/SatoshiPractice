package com.fizzpage.bitcoinpractice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Date
import java.util.Locale
import java.text.SimpleDateFormat
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import java.util.Random

/**
 * User-started foreground service for the LOCAL Satoshi Practice auto-trading game.
 * It only changes virtual practice credits and never submits orders to an exchange.
 */
class AutoMinerService : Service() {
    private val prefs by lazy { getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val random = Random()
    private var wakeLock: PowerManager.WakeLock? = null
    private var tickCount = 0
    private var lastNotificationUpdate = 0L
    private var currentPrice = 0.0

    private val tickRunnable = object : Runnable {
        override fun run() {
            try {
                if (!prefs.getBoolean(KEY_BOT_ACTIVE, false)) {
                    stopBot("Bot dihentikan karena status sesi tidak aktif.")
                    return
                }
                advanceLocalMarketAndBot()
            } catch (error: Exception) {
                appendBotEvent(
                    type = "INFO",
                    time = System.currentTimeMillis(),
                    note = "Tick bot tertunda karena kendala lokal: ${error.javaClass.simpleName}. Bot mencoba lanjut otomatis."
                )
                updateNotification("Bot latihan aktif · memulihkan proses")
            }
            if (prefs.getBoolean(KEY_BOT_ACTIVE, false)) {
                handler.postDelayed(this, TICK_INTERVAL_MS)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        runningNow = true
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopBot("Bot dimatikan dari tombol notifikasi.")
            return START_NOT_STICKY
        }

        // START_STICKY can recreate the service after Android reclaims the process.
        // Resume only when the persisted user-started session is still marked active.
        if (!prefs.getBoolean(KEY_BOT_ACTIVE, false)) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startAsForeground()
        acquireCpuWakeLock()
        val baseline = readDouble(KEY_SESSION_START_EQUITY, 0.0)
        if (baseline <= 0.0) {
            val price = readDouble("last_price", readDouble("market_reference_price", 0.0))
            val equity = readDouble("practice_balance", 0.0) + readDouble("btc_holding", 0.0) * price
            prefs.edit()
                .putString(KEY_SESSION_START_EQUITY, equity.toString())
                .putString(KEY_BOT_PEAK_RETURN, "0.0")
                .apply()
        }
        prefs.edit()
            .putBoolean(KEY_SERVICE_RUNNING, true)
            .putLong(KEY_SERVICE_HEARTBEAT, System.currentTimeMillis())
            .apply()
        handler.removeCallbacks(tickRunnable)
        handler.post(tickRunnable)
        return START_STICKY
    }

    private fun startAsForeground() {
        val notification = buildNotification("Bot latihan aktif · menyiapkan pasar lokal")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun acquireCpuWakeLock() {
        try {
            val manager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = manager.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "$packageName:SatoshiPracticeAutoMiner"
                ).apply { setReferenceCounted(false) }
            }
            if (wakeLock?.isHeld != true) wakeLock?.acquire()
        } catch (_: Exception) {
            // The foreground service can still run when the device does not grant a wake lock.
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Auto Miner latihan",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menampilkan status bot trading virtual yang berjalan di latar belakang."
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(status: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPending = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, AutoMinerService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        builder
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Satoshi Practice · Auto Miner")
            .setContentText(status)
            .setStyle(Notification.BigTextStyle().bigText(
                "$status\nBot memakai kredit virtual lokal. Tidak ada penambangan BTC sungguhan atau order ke exchange."
            ))
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppPending)
            .addAction(android.R.drawable.ic_media_pause, "Matikan bot", stopPending)
        return builder.build()
    }

    private fun updateNotification(status: String) {
        try {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(status))
        } catch (_: Exception) {
        }
    }

    private fun advanceLocalMarketAndBot() {
        val now = System.currentTimeMillis()
        val marketReference = readDouble("market_reference_price", readDouble("last_price", 0.0))
        val manualBoost = readDouble("manual_price_boost_idr", 0.0)
        val anchor = (marketReference + manualBoost).coerceAtLeast(1.0)
        val points = loadChartPoints()
        val previous = points.lastOrNull() ?: readDouble("last_price", anchor).takeIf { it > 0.0 } ?: anchor
        val next = nextPracticePrice(previous, anchor)
        points.add(next)
        while (points.size > 90) points.removeAt(0)
        currentPrice = next

        val chartJson = JSONArray().apply { points.forEach { put(it) } }.toString()
        val chartEditor = prefs.edit()
            .putString("price_chart", chartJson)
            .putString("last_price", currentPrice.toString())
            .putInt("practice_trend_regime", practiceTrendRegime)
            .putInt("practice_trend_ticks", practiceTrendTicksRemaining)
            .putLong(KEY_SERVICE_HEARTBEAT, now)
        chartEditor.apply()

        processBotTradeTick(points, next, now)
        // A session risk stop removes the foreground notification and stops this service.
        if (!prefs.getBoolean(KEY_BOT_ACTIVE, false)) return
        tickCount += 1
        if (now - lastNotificationUpdate >= NOTIFICATION_REFRESH_MS || tickCount == 1) {
            lastNotificationUpdate = now
            val balance = formatIdr(readDouble("practice_balance", 0.0))
            updateNotification("Bot berjalan · ${formatIdr(next)} per BTC · saldo latihan $balance")
        }
    }

    private var practiceTrendRegime = 0
    private var practiceTrendTicksRemaining = 0

    private fun nextPracticePrice(previous: Double, anchor: Double): Double {
        practiceTrendRegime = prefs.getInt("practice_trend_regime", 0).coerceIn(-1, 1)
        practiceTrendTicksRemaining = prefs.getInt("practice_trend_ticks", 0).coerceAtLeast(0)
        if (practiceTrendTicksRemaining <= 0) {
            val roll = random.nextDouble()
            practiceTrendRegime = when {
                roll < 0.30 -> 1
                roll < 0.55 -> -1
                else -> 0
            }
            practiceTrendTicksRemaining = 14 + random.nextInt(27)
        }
        practiceTrendTicksRemaining -= 1

        val displacement = ((anchor - previous) / anchor).coerceIn(-0.08, 0.08)
        val drift: Double
        val noise: Double
        val meanReversion: Double
        when (practiceTrendRegime) {
            1 -> { drift = 0.00042; noise = 0.00145; meanReversion = 0.025 }
            -1 -> { drift = -0.00038; noise = 0.00155; meanReversion = 0.045 }
            else -> { drift = 0.0; noise = 0.00120; meanReversion = 0.115 }
        }
        var movement = drift + random.nextGaussian() * noise + displacement * meanReversion
        val eventRoll = random.nextDouble()
        val nearHigh = previous >= anchor * 1.018
        val dumpChance = if (nearHigh) 0.0060 else 0.0025
        val pumpChance = if (practiceTrendRegime == 1 && previous < anchor * 1.025) 0.0045 else 0.0020
        when {
            eventRoll < dumpChance -> movement -= 0.018 + random.nextDouble() * 0.022
            eventRoll < dumpChance + pumpChance -> movement += 0.018 + random.nextDouble() * 0.020
            practiceTrendRegime == -1 && eventRoll < 0.025 -> movement -= 0.005 + random.nextDouble() * 0.009
            practiceTrendRegime == 1 && previous >= anchor * 1.012 && eventRoll > 0.975 ->
                movement -= 0.008 + random.nextDouble() * 0.014
            practiceTrendRegime == 1 && previous < anchor * 1.020 && eventRoll > 0.992 ->
                movement += 0.006 + random.nextDouble() * 0.010
        }
        return (previous * (1.0 + movement)).coerceIn(anchor * 0.90, anchor * 1.055)
    }

    private fun processBotTradeTick(points: List<Double>, price: Double, now: Long) {
        val feeRate = 0.001
        var balance = readDouble("practice_balance", 0.0)
        var btcHolding = readDouble("btc_holding", 0.0)
        var botOwnedBtc = readDouble("auto_bot_owned_btc", 0.0)
        var entryCost = readDouble("auto_bot_entry_cost", 0.0)
        var entryPrice = readDouble("auto_bot_entry_price", 0.0)
        var entryTime = prefs.getLong("auto_bot_entry_time", 0L)
        var lastTradeAt = prefs.getLong("auto_bot_last_trade_at", 0L)
        var peakNetReturn = readDouble(KEY_BOT_PEAK_RETURN, 0.0)
        var tradeOccurred = false

        val sessionStartEquity = readDouble(KEY_SESSION_START_EQUITY, 0.0)
        val currentEquity = balance + btcHolding * price
        val sessionDrawdown = if (sessionStartEquity > 0.0) {
            currentEquity / sessionStartEquity - 1.0
        } else 0.0
        val sessionRiskLimitReached = sessionDrawdown <= SESSION_MAX_DRAWDOWN

        if (botOwnedBtc > 0.0 && entryCost > 0.0) {
            val estimatedNet = botOwnedBtc * price * (1.0 - feeRate)
            val netReturn = estimatedNet / entryCost - 1.0
            val heldSeconds = ((now - entryTime).coerceAtLeast(0L) / 1000L)
            peakNetReturn = max(peakNetReturn, netReturn)
            val recent = points.takeLast(20)
            val fastEma = ema(recent, 7)
            val slowEma = ema(recent, 18)
            val trendReversed = recent.size >= 18 && fastEma < slowEma * 0.9995

            val exitReason = when {
                sessionRiskLimitReached -> "Rem otomatis: batas rugi sesi 3% tercapai"
                netReturn <= -0.010 -> "Batas risiko posisi -1,0% tersentuh"
                peakNetReturn >= 0.007 && netReturn <= peakNetReturn - 0.004 -> "Trailing stop mengunci hasil setelah harga berbalik"
                netReturn >= 0.016 -> "Target hasil bersih +1,6% tercapai"
                trendReversed && netReturn >= 0.0020 -> "Tren pendek melemah; hasil positif diamankan"
                heldSeconds >= 600L && netReturn >= 0.0 -> "Batas waktu 6 menit; posisi ditutup tanpa memaksa rugi"
                else -> null
            }
            if (exitReason != null) {
                val btcSold = min(botOwnedBtc, btcHolding)
                if (btcSold > 0.0) {
                    val gross = btcSold * price
                    val fee = gross * feeRate
                    val net = gross - fee
                    val pnl = net - entryCost
                    balance += net
                    btcHolding = (btcHolding - btcSold).coerceAtLeast(0.0)
                    appendTradeRecord("BOT JUAL", gross, btcSold, price, now)
                    appendBotEvent("JUAL", btcSold, price, gross, fee, net, pnl, now, exitReason)
                    tradeOccurred = true
                }
                botOwnedBtc = 0.0
                entryCost = 0.0
                entryPrice = 0.0
                entryTime = 0L
                peakNetReturn = 0.0
                lastTradeAt = now
            }
        } else if (!sessionRiskLimitReached && now - lastTradeAt >= ENTRY_COOLDOWN_MS && balance >= 1_000.0) {
            val signal = hasBullishEntrySignal(points)
            if (signal) {
                // Small position size keeps a losing practice trade from dominating the wallet.
                val totalSpend = min(balance * POSITION_FRACTION, balance)
                if (totalSpend >= 1_000.0) {
                    val gross = totalSpend / (1.0 + feeRate)
                    val fee = totalSpend - gross
                    val btcBought = gross / price
                    if (btcBought.isFinite() && btcBought > 0.0) {
                        balance = (balance - totalSpend).coerceAtLeast(0.0)
                        btcHolding += btcBought
                        botOwnedBtc = btcBought
                        entryCost = totalSpend
                        entryPrice = price
                        entryTime = now
                        peakNetReturn = 0.0
                        lastTradeAt = now
                        appendTradeRecord("BOT BELI", gross, btcBought, price, now)
                        appendBotEvent(
                            "BELI", btcBought, price, gross, fee, totalSpend, 0.0, now,
                            "Tren naik terkonfirmasi, momentum positif, dan volatilitas masih terkendali"
                        )
                        tradeOccurred = true
                    }
                }
            }
        }

        prefs.edit()
            .putString("practice_balance", balance.toString())
            .putString("btc_holding", btcHolding.toString())
            .putString("auto_bot_owned_btc", botOwnedBtc.toString())
            .putString("auto_bot_entry_cost", entryCost.toString())
            .putString("auto_bot_entry_price", entryPrice.toString())
            .putLong("auto_bot_entry_time", entryTime)
            .putLong("auto_bot_last_trade_at", lastTradeAt)
            .putString(KEY_BOT_PEAK_RETURN, peakNetReturn.toString())
            .putLong(KEY_SERVICE_HEARTBEAT, now)
            .apply()

        if (tradeOccurred) {
            val currentBalance = formatIdr(balance)
            updateNotification("Bot transaksi · ${formatIdr(price)} per BTC · saldo latihan $currentBalance")
            lastNotificationUpdate = now
        }
        if (sessionRiskLimitReached) {
            stopBot("Rem otomatis aktif: nilai portofolio turun 3% dari awal sesi. Bot dihentikan untuk membatasi simulasi kerugian.")
        }
    }

    private fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        val alpha = 2.0 / (period + 1.0)
        var result = values.first()
        for (value in values.drop(1)) result += alpha * (value - result)
        return result
    }

    private fun hasBullishEntrySignal(points: List<Double>): Boolean {
        if (points.size < 22) return false
        val sample = points.takeLast(24)
        val fast = ema(sample, 7)
        val slow = ema(sample, 18)
        val priorFast = ema(sample.dropLast(3), 7)
        val price = sample.last()
        val previous = sample[sample.lastIndex - 1]
        val threeTicksAgo = sample[sample.lastIndex - 3]
        val fastSlope = if (priorFast > 0.0) fast / priorFast - 1.0 else 0.0
        val momentum = if (threeTicksAgo > 0.0) price / threeTicksAgo - 1.0 else 0.0
        val recentMoves = sample.takeLast(12).zipWithNext { a, b ->
            if (a > 0.0) abs(b / a - 1.0) else 1.0
        }
        val averageVolatility = if (recentMoves.isNotEmpty()) recentMoves.average() else 1.0
        val trendUp = fast > slow * 1.0002 && fastSlope > 0.00008
        val rebound = price > previous && price > threeTicksAgo
        val nearTrend = price in (fast * 0.997)..(fast * 1.005)
        val momentumOkay = momentum in 0.0002..0.0040
        return trendUp && rebound && nearTrend && momentumOkay && averageVolatility < 0.0028
    }

    private fun appendTradeRecord(type: String, idr: Double, btc: Double, price: Double, time: Long) {
        val old = try { JSONArray(prefs.getString("order_history", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val updated = JSONArray().put(JSONObject().apply {
            put("type", type)
            put("idr", idr)
            put("btc", btc)
            put("price", price)
            put("time", time)
        })
        for (index in 0 until min(old.length(), 29)) {
            updated.put(old.opt(index))
        }
        prefs.edit().putString("order_history", updated.toString()).apply()
    }

    private fun appendBotEvent(
        type: String,
        btc: Double = 0.0,
        price: Double = 0.0,
        gross: Double = 0.0,
        fee: Double = 0.0,
        cash: Double = 0.0,
        pnl: Double = 0.0,
        time: Long = System.currentTimeMillis(),
        note: String = ""
    ) {
        val array = try { JSONArray(prefs.getString("auto_bot_events", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        array.put(JSONObject().apply {
            put("type", type)
            put("btc", btc)
            put("price", price)
            put("gross", gross)
            put("fee", fee)
            put("cash", cash)
            put("pnl", pnl)
            put("time", time)
            put("note", note)
        })
        while (array.length() > 500) array.remove(0)
        prefs.edit().putString("auto_bot_events", array.toString()).apply()
    }

    private fun loadChartPoints(): MutableList<Double> {
        val result = mutableListOf<Double>()
        try {
            val array = JSONArray(prefs.getString("price_chart", "[]") ?: "[]")
            for (index in 0 until array.length()) {
                val value = array.optDouble(index, 0.0)
                if (value.isFinite() && value > 0.0) result.add(value)
            }
        } catch (_: Exception) {
        }
        if (result.isEmpty()) {
            val fallback = readDouble("last_price", readDouble("market_reference_price", 0.0))
            if (fallback > 0.0) result.add(fallback)
        }
        return result
    }

    @Suppress("DEPRECATION")
    private fun stopBot(reason: String) {
        handler.removeCallbacks(tickRunnable)
        val now = System.currentTimeMillis()
        val price = readDouble("last_price", currentPrice)
        val ownedBtc = readDouble("auto_bot_owned_btc", 0.0)
        val entryCost = readDouble("auto_bot_entry_cost", 0.0)
        if (ownedBtc > 0.0) {
            val gross = ownedBtc * price
            val fee = gross * 0.001
            val estimatedNet = gross - fee
            val estimatedPnl = estimatedNet - entryCost
            appendBotEvent(
                type = "INFO", btc = ownedBtc, price = price, gross = gross, fee = fee,
                cash = estimatedNet, pnl = estimatedPnl, time = now,
                note = "Posisi ${String.format(Locale.US, "%.8f", ownedBtc)} BTC belum dijual dan tetap berada di portofolio. Estimasi P/L jika dijual sekarang: ${formatSignedIdr(estimatedPnl)}."
            )
        }
        appendBotEvent(type = "INFO", time = now, note = reason)
        prefs.edit()
            .putBoolean(KEY_BOT_ACTIVE, false)
            .putBoolean(KEY_SERVICE_RUNNING, false)
            .putString("auto_bot_owned_btc", "0.0")
            .putString("auto_bot_entry_cost", "0.0")
            .putString("auto_bot_entry_price", "0.0")
            .putString(KEY_BOT_PEAK_RETURN, "0.0")
            .putLong("auto_bot_entry_time", 0L)
            .putLong("auto_bot_last_trade_at", now)
            .putLong(KEY_SERVICE_HEARTBEAT, now)
            .apply()
        releaseCpuWakeLock()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        stopSelf()
    }

    private fun releaseCpuWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun readDouble(key: String, fallback: Double): Double =
        (prefs.getString(key, fallback.toString())?.toDoubleOrNull() ?: fallback)
            .takeIf { it.isFinite() } ?: fallback

    private fun formatIdr(value: Double): String {
        val formatter = NumberFormat.getNumberInstance(Locale("id", "ID")).apply {
            maximumFractionDigits = 0
            minimumFractionDigits = 0
        }
        return "Rp ${formatter.format(value.coerceAtLeast(0.0))}"
    }

    private fun formatSignedIdr(value: Double): String =
        (if (value >= 0.0) "+" else "-") + formatIdr(abs(value))

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(tickRunnable)
        releaseCpuWakeLock()
        runningNow = false
        // Do not clear the persisted active flag here: START_STICKY may recreate this
        // service after a system process reclaim. A normal user stop clears it first.
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.fizzpage.bitcoinpractice.action.START_AUTO_MINER"
        const val ACTION_STOP = "com.fizzpage.bitcoinpractice.action.STOP_AUTO_MINER"
        const val PREFS_NAME = "satoshi_practice"
        private const val KEY_BOT_ACTIVE = "auto_bot_active"
        private const val KEY_SERVICE_RUNNING = "auto_bot_service_running"
        private const val KEY_SERVICE_HEARTBEAT = "auto_bot_service_heartbeat"
        private const val CHANNEL_ID = "satoshi_auto_miner_channel"
        private const val NOTIFICATION_ID = 5301
        private const val TICK_INTERVAL_MS = 1_000L
        private const val NOTIFICATION_REFRESH_MS = 30_000L
        private const val ENTRY_COOLDOWN_MS = 180_000L
        private const val POSITION_FRACTION = 0.04
        private const val SESSION_MAX_DRAWDOWN = -0.03
        private const val KEY_SESSION_START_EQUITY = "auto_bot_session_start_equity"
        private const val KEY_BOT_PEAK_RETURN = "auto_bot_peak_net_return"

        @Volatile
        private var runningNow: Boolean = false

        fun isRunning(): Boolean = runningNow

        fun start(context: Context) {
            val intent = Intent(context, AutoMinerService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }
}
