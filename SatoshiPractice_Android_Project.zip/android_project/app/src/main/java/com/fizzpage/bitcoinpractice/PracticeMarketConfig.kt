package com.fizzpage.bitcoinpractice

import java.util.Random
import kotlin.math.sin

internal data class PracticePriceStep(
    val price: Double,
    val regime: Int,
    val ticksRemaining: Int
)

internal data class PracticeLuckyReward(
    val won: Boolean,
    val bonusIdr: Double
)

/** Settings and shared mechanics for the local-only Satoshi Practice market game. */
internal object PracticeMarketConfig {
    const val PRICE_FLOOR_IDR = 1_110_000_000.0
    const val PRICE_CEILING_IDR = 1_200_000_000.0
    const val PRICE_HISTORY_TICKS = 360 // six minutes at one point per second
    const val TREND_PHASE_MIN_TICKS = 180 // three minutes
    const val TREND_PHASE_MAX_TICKS = 300 // five minutes
    const val BULL_PHASE_CHANCE = 0.50 // direction of the first phase only; later phases alternate
    const val BOT_WIN_CHANCE = 0.60
    const val LUCKY_BONUS_MIN_IDR = 50_000.0
    const val LUCKY_BONUS_MAX_IDR = 250_000.0
    const val BOT_POSITION_FRACTION = 0.95
    const val BOT_ENTRY_EDGE_FRACTION = 0.025
    const val BOT_TAKE_PROFIT_NET = 0.022
    const val BOT_STOP_LOSS_NET = -0.015
    const val BOT_ENTRY_COOLDOWN_MS = 120_000L
    const val BOT_SESSION_MAX_DRAWDOWN = -0.03
    const val PHASE_MIGRATION_KEY = "practice_smooth_phase_market_v1"
    const val BOT_LUCKY_BONUS_KEY = "auto_bot_lucky_bonus_idr"

    /**
     * Produces a gentle directional tick. Trend phases last 3–5 minutes and alternate,
     * with small pullbacks rather than isolated vertical spikes. The public ticker is
     * only a weak anchor; the visible chart remains a local practice simulation.
     */
    fun nextPriceStep(
        previous: Double,
        anchor: Double,
        currentRegime: Int,
        currentTicksRemaining: Int,
        nowMillis: Long,
        random: Random
    ): PracticePriceStep {
        val floor = PRICE_FLOOR_IDR
        val ceiling = PRICE_CEILING_IDR
        if (!previous.isFinite() || previous <= 0.0 || !anchor.isFinite() || anchor <= 0.0) {
            return PracticePriceStep(anchor.coerceIn(floor, ceiling), currentRegime.coerceIn(-1, 1), 0)
        }

        val safePrevious = previous.coerceIn(floor, ceiling)
        val safeAnchor = anchor.coerceIn(floor, ceiling)
        var regime = currentRegime.coerceIn(-1, 1)
        var ticksRemaining = currentTicksRemaining.coerceIn(0, TREND_PHASE_MAX_TICKS)

        if (regime == 0) {
            regime = if (random.nextDouble() < BULL_PHASE_CHANCE) 1 else -1
            ticksRemaining = nextPhaseLength(random)
        } else if (ticksRemaining <= 0) {
            regime = -regime
            ticksRemaining = nextPhaseLength(random)
        }

        // Reverse before hitting either hard boundary so the line doesn't get stuck flat.
        val edgeMargin = (ceiling - floor) * 0.01
        if (safePrevious <= floor + edgeMargin && regime < 0) {
            regime = 1
            ticksRemaining = nextPhaseLength(random)
        } else if (safePrevious >= ceiling - edgeMargin && regime > 0) {
            regime = -1
            ticksRemaining = nextPhaseLength(random)
        }

        val anchorOffset = ((safeAnchor - safePrevious) / safeAnchor).coerceIn(-0.08, 0.08)
        val gentleWave = sin(nowMillis / 18_000.0) * 0.000012
        var movement = regime * 0.00016 + random.nextGaussian() * 0.000026 + gentleWave + anchorOffset * 0.00006

        // Brief counter-trend pullbacks create a natural-looking rhythm without sharp spikes.
        if (random.nextDouble() < 0.08) {
            movement -= regime * (0.000045 + random.nextDouble() * 0.000045)
        }
        movement = movement.coerceIn(-0.00024, 0.00024)

        var next = safePrevious * (1.0 + movement)
        if (next >= ceiling) {
            next = ceiling
            regime = -1
            ticksRemaining = nextPhaseLength(random)
        } else if (next <= floor) {
            next = floor
            regime = 1
            ticksRemaining = nextPhaseLength(random)
        } else {
            ticksRemaining = (ticksRemaining - 1).coerceAtLeast(0)
        }

        return PracticePriceStep(next, regime, ticksRemaining)
    }

    /** Local game reward: 60% chance of a separately disclosed Rp50k–Rp250k bonus. */
    fun rollLuckyReward(random: Random): PracticeLuckyReward {
        val won = random.nextDouble() < BOT_WIN_CHANCE
        val bonus = if (won) {
            LUCKY_BONUS_MIN_IDR + random.nextInt(201) * 1_000.0
        } else 0.0
        return PracticeLuckyReward(won, bonus)
    }

    private fun nextPhaseLength(random: Random): Int =
        TREND_PHASE_MIN_TICKS + random.nextInt(TREND_PHASE_MAX_TICKS - TREND_PHASE_MIN_TICKS + 1)
}
