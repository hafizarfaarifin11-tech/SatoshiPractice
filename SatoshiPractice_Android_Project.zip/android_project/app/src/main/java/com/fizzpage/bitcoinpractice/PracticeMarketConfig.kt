package com.fizzpage.bitcoinpractice

/** Settings for the local-only Satoshi Practice market and Auto Miner game. */
internal object PracticeMarketConfig {
    const val PRICE_FLOOR_IDR = 1_110_000_000.0
    const val PRICE_CEILING_IDR = 1_200_000_000.0
    const val BULL_PHASE_CHANCE = 0.60
    const val BOT_WIN_CHANCE = 0.60
    const val BOT_WIN_PRICE_RATIO = 1.019
    const val BOT_LOSS_PRICE_RATIO = 0.9895
    const val BOT_POSITION_FRACTION = 0.95
    const val BOT_TAKE_PROFIT_NET = 0.016
    const val BOT_STOP_LOSS_NET = -0.012
    const val BOT_ENTRY_COOLDOWN_MS = 120_000L
    const val BOT_SESSION_MAX_DRAWDOWN = -0.03
}
