package com.fizzpage.bitcoinpractice

import java.util.Random

internal data class PracticePriceStep(
    val price: Double,
    val regime: Int,
    val ticksRemaining: Int
)

internal data class PracticeLuckyReward(
    val won: Boolean,
    val bonusIdr: Double
)

/** Shared local-price and virtual-credit rules for Satoshi Practice. */
internal object PracticeMarketConfig {
    const val PRICE_FLOOR_IDR = 1_110_000_000.0
    const val PRICE_CEILING_IDR = 1_200_000_000.0
    const val PRICE_HISTORY_TICKS = 180 // three minutes, one point per second
    // Retained for reading old saved preference values; the random path no longer uses phases.
    const val TREND_PHASE_MAX_TICKS = 300
    const val BOT_WIN_CHANCE = 0.50
    const val LUCKY_BONUS_MIN_IDR = 50_000.0
    const val LUCKY_BONUS_MAX_IDR = 250_000.0
    const val BOT_POSITION_FRACTION = 0.95
    const val BOT_ENTRY_EDGE_FRACTION = 0.025
    const val BOT_TAKE_PROFIT_NET = 0.022
    const val BOT_STOP_LOSS_NET = -0.015
    const val BOT_ENTRY_COOLDOWN_MS = 120_000L
    const val BOT_SESSION_MAX_DRAWDOWN = -0.03
    const val PHASE_MIGRATION_KEY = "practice_random_walk_v2"
    const val BOT_LUCKY_BONUS_KEY = "auto_bot_lucky_bonus_idr"

    /**
     * A symmetric random walk with small random ticks and occasional larger jumps.
     * There are no forced bullish/bearish phases or forced winning/losing directions.
     * The weak anchor pull only prevents the local price from drifting permanently.
     */
    fun nextPriceStep(
        previous: Double,
        anchor: Double,
        currentRegime: Int,
        currentTicksRemaining: Int,
        nowMillis: Long,
        random: Random
    ): PracticePriceStep {
        val floor = PRICE_FLOOR_IDR
        val ceiling = PRICE_CEILING_IDR
        if (!previous.isFinite() || previous <= 0.0 || !anchor.isFinite() || anchor <= 0.0) {
            return PracticePriceStep(anchor.coerceIn(floor, ceiling), 0, 0)
        }

        val price = previous.coerceIn(floor, ceiling)
        val reference = anchor.coerceIn(floor, ceiling)
        val randomMove = random.nextGaussian() * 0.00018
        val jump = if (random.nextDouble() < 0.075) {
            (if (random.nextBoolean()) 1.0 else -1.0) * (0.00035 + random.nextDouble() * 0.00085)
        } else 0.0
        val anchorPull = ((reference - price) / reference).coerceIn(-0.08, 0.08) * 0.000045
        val movement = (randomMove + jump + anchorPull).coerceIn(-0.0015, 0.0015)
        val raw = price * (1.0 + movement)

        // Reflect a small overshoot at either edge instead of leaving a flat line at the cap.
        val next = when {
            raw > ceiling -> ceiling - (raw - ceiling) * 0.65
            raw < floor -> floor + (floor - raw) * 0.65
            else -> raw
        }.coerceIn(floor, ceiling)

        return PracticePriceStep(next, 0, 0)
    }

    /** 50% chance of a separate virtual bonus, independent of price direction. */
    fun rollLuckyReward(random: Random): PracticeLuckyReward {
        val won = random.nextDouble() < BOT_WIN_CHANCE
        val bonus = if (won) {
            LUCKY_BONUS_MIN_IDR + random.nextInt(201) * 1_000.0
        } else 0.0
        return PracticeLuckyReward(won, bonus)
    }
}
