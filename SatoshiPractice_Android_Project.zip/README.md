# Satoshi Practice v0.2.0

Aplikasi Android portrait bertema pasar Bitcoin untuk latihan dengan kredit virtual. Harga BTC/IDR dan grafik historis 24 jam diambil dari CoinGecko. Order beli/jual hanya mengubah saldo dan portofolio lokal latihan.

## UI dan grafik
- Panel BTC/IDR berada di bagian atas dengan harga dan perubahan 24 jam.
- Grafik 24 jam memakai garis grid horizontal dan vertikal. Segmen harga diberi warna hijau saat naik dan merah saat turun. Titik terakhir berdenyut dan garis digambar dengan animasi saat data diperbarui.
- Quote spot terbaru ditambahkan ke ujung seri grafik pada saat refresh. Pembaruan otomatis berjalan setiap 90 detik; ini bukan feed transaksi per detik.
- Panel order nominal, tombol BELI BTC dan JUAL BTC berada tepat di bawah panel grafik.
- Saldo, portofolio, dan riwayat order berada setelah panel order.

## Build
Workflow GitHub Actions ada di `.github/workflows/android.yml`. Simpan arsip ini di repository dengan nama `SatoshiPractice_Android_Project.zip`, dan simpan workflow pada `.github/workflows/android.yml`. Workflow akan mencari arsip tersebut secara rekursif, mengekstrak proyek, lalu menjalankan `assembleDebug`.

## Build configuration
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
