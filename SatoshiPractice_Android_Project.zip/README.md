# Satoshi Practice v0.4.7

Aplikasi Android portrait untuk mempelajari tampilan pasar BTC/IDR dan mencoba alur order menggunakan kredit latihan virtual. Aplikasi ini bukan exchange/broker, tidak mengirim order sungguhan, dan tidak menerima uang.

## Fitur v0.4.7
- Ikon launcher memakai artwork Satoshi Practice dari pengguna, termasuk adaptive icon Android.
- Pengaturan awal 14 langkah edukasi; nama tampilan wajib diisi dan disimpan lokal.
- Saldo awal akun latihan baru adalah Rp0. Saldo akun yang sudah ada tetap disimpan saat pembaruan.
- Tersedia 36 pilihan kredit virtual dari Rp200.000 sampai Rp905.000.000 dengan timer lokal yang meningkat sesuai nominal. Tidak ada pembayaran/deposit uang.
- Harga acuan BTC/IDR diperiksa dari ticker publik Indodax setiap detik saat aplikasi aktif. Nilai harga latihan aktif bergerak setiap detik pada grafik; harga header, estimasi, portofolio, dan order selalu tersinkron dengan titik terakhir grafik.
- Grafik memakai rezim bullish, bearish, dan sideways dengan durasi yang berubah-ubah. Rezim bearish sedikit lebih sering, ditambah peluang candle dump tajam, pump, dan bull trap agar harga tidak terus naik. Grafik adalah jalur harga latihan yang acak, bukan riwayat pasar atau prediksi harga nyata.
- Batas harga latihan tetap 25%–400% dari acuan agar jalur punya ruang gerak luas.
- Tombol BELI BTC dan JUAL BTC tetap berada tepat di bawah panel grafik.
- Tombol UP di samping harga menambah Rp1 pada harga dasar latihan setiap 50 tap; progres dan kenaikannya disimpan lokal.
- Panel RTP menampilkan skenario arah untuk 1 jam, 6 jam, pukul 06.00 berikutnya, dan 24 jam. Ini heuristik sederhana dengan rentang ketidakpastian; bukan probabilitas teruji, bukan saran investasi, dan tidak menjamin profit.
- Panel order menampilkan estimasi BTC, nilai IDR, biaya 0,1%, dan saldo/holding setelah transaksi sebelum order. Estimasi diperbarui saat nominal, satuan, atau titik harga grafik berubah.
- Tombol MAX pada kolom nominal mengisi jumlah maksimum menurut tindakan aktif dan satuan yang dipilih: beli dengan semua saldo IDR, BTC maksimum yang terjangkau, jual seluruh BTC, atau nilai IDR bersih maksimum. Jumlah BTC dibulatkan ke bawah pada presisi 8 desimal agar tidak melewati saldo/aset tersedia.
- Beli sebagai BTC: input adalah jumlah BTC; biaya ditambahkan ke nilai IDR.
- Beli sebagai Saldo (IDR): input adalah anggaran total termasuk biaya, sehingga memasukkan seluruh saldo tidak gagal hanya karena biaya ekstra.
- Jual sebagai BTC: input adalah jumlah BTC.
- Jual sebagai Saldo (IDR): input adalah target saldo bersih setelah biaya; aplikasi menghitung BTC yang perlu dijual.
- Semua transaksi hanya mengubah saldo dan portofolio latihan lokal. Tidak ada deposit atau penarikan uang sungguhan.

## Build
Workflow GitHub Actions tetap berada di `.github/workflows/android.yml`. Simpan arsip ini di repository dengan nama persis `SatoshiPractice_Android_Project.zip`; workflow yang sudah digunakan sebelumnya tidak perlu diganti untuk pembaruan ini.

## Konfigurasi build
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- versionCode 12 / versionName 0.4.7
