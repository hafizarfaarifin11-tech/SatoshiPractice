# Satoshi Practice v0.5.3

Aplikasi Android portrait untuk mempelajari tampilan pasar BTC/IDR dan mencoba alur order menggunakan kredit latihan virtual. Aplikasi ini bukan exchange/broker, tidak mengirim order sungguhan, dan tidak menerima uang.

## Pembaruan v0.5.3 — Auto Miner BTC
- Menambahkan panel Auto Miner BTC di bagian paling bawah dashboard.
- Tombol yang sama mengaktifkan dan mematikan bot.
- Bot memantau harga grafik latihan setiap detik, mencoba membeli saat menemukan peluang koreksi atau peluang acak, lalu mencoba menjual pada target hasil bersih, batas risiko, batas waktu, atau perubahan sinyal.
- Setiap pembelian menggunakan maksimal 18% saldo IDR yang tersedia. Biaya latihan 0,1% diterapkan pada setiap order.
- Bot dapat menutup posisi dengan untung maupun rugi. Tidak ada hasil yang dijamin.
- Seluruh transaksi bot dicatat di panel laporan: jenis transaksi, waktu, harga BTC, jumlah BTC, biaya, hasil bersih, serta P/L terealisasi.
- Transaksi bot juga muncul di riwayat akun dan dihitung dalam ringkasan aktivitas.
- BTC yang masih dipegang saat bot dimatikan tidak dijual otomatis; aset tersebut tetap berada di portofolio pengguna dan dapat dijual manual setelah bot berhenti.
- BTC yang sedang dikelola bot tidak dapat dijual melalui order manual selama bot aktif agar saldo tidak bertabrakan.
- Bot hanya berjalan saat aplikasi berada di layar. Ketika aplikasi ditinggalkan atau ditutup, bot dihentikan dan posisi yang belum dijual tetap berada di portofolio. Setelah aplikasi dibuka kembali, bot tidak menyala otomatis.
- "Auto Miner" adalah nama fitur dalam aplikasi; fitur ini sebenarnya bot trading untuk latihan, bukan proses mining atau penambangan Bitcoin sungguhan.

## Pembaruan sebelumnya
- Registrasi awal terdiri dari lima langkah: nama (wajib, maksimal 24 karakter), tanggal lahir via kalender, domisili tingkat provinsi/kabupaten/kecamatan, pengalaman latihan, dan strategi pilihan.
- Avatar profil di dashboard membuka halaman Akun yang memuat profil, analisis strategi, portofolio, dan riwayat transaksi.
- Nama, tanggal lahir, domisili, pengalaman, dan strategi disimpan lokal di perangkat.
- Grafik latihan bergerak setiap detik dan menjadi harga aktif untuk estimasi serta order latihan. Data grafik adalah volatilitas latihan, bukan riwayat harga pasar.
- Harga acuan BTC/IDR diambil dari ticker publik Indodax.
- Order beli/jual mendukung satuan BTC atau IDR, biaya 0,1%, estimasi order, dan tombol MAX.
- Saldo dan kepemilikan BTC berupa kredit/aset latihan virtual.
- Pilihan kredit virtual, timer, dan notifikasi lokal tetap tersedia.
- RTP menampilkan rentang skenario heuristik yang tidak terkalibrasi, bukan probabilitas teruji atau jaminan profit.

## Build
Workflow GitHub Actions tetap berada di `.github/workflows/android.yml`. Simpan arsip ini di repository dengan nama persis `SatoshiPractice_Android_Project.zip`; workflow yang sudah digunakan sebelumnya tidak perlu diganti untuk pembaruan ini.

## Konfigurasi
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- versionCode 16 / versionName 0.5.3

## Privasi dan keselamatan
Tanggal lahir dan domisili merupakan data pribadi. Masukkan hanya informasi yang memang ingin disimpan di perangkat. Tidak perlu memasukkan alamat jalan, nomor rumah, KTP, selfie, nomor rekening, OTP, seed phrase, atau kata sandi. Semua order dan Auto Miner berjalan lokal sebagai latihan virtual; aplikasi tidak mengakses akun exchange dan tidak mengirim transaksi sungguhan.
