# Satoshi Practice

Android Studio / GitHub Actions project for Satoshi Practice.

## GitHub Actions

Upload this archive as `SatoshiPractice_Android_Project.zip` to the repository root, and place the standalone workflow file at `.github/workflows/android.yml`.
The workflow locates the archive recursively, extracts the Android project, and builds the debug APK.

The app uses virtual practice credits only. It does not accept deposits or perform real cryptocurrency transactions.
