# Satoshi Practice v0.4.2

Aplikasi Android portrait untuk mempelajari tampilan pasar BTC/IDR dan mencoba alur order menggunakan kredit latihan virtual. Aplikasi ini bukan exchange/broker, tidak mengirim order sungguhan, dan tidak menerima uang.

## Fitur v0.4.2
- Ikon launcher memakai artwork Satoshi Practice yang diberikan pengguna, termasuk adaptive icon Android.
- Pengaturan awal berisi 14 langkah edukasi. Nama tampilan wajib diisi dan disimpan lokal; aplikasi tidak meminta email, nomor telepon, KTP, selfie, rekening bank, password, atau seed phrase.
- Saldo akun latihan baru dimulai dari Rp0. Saldo akun yang sudah ada tetap tersimpan saat update.
- Tersedia 36 pilihan nominal kredit latihan dari Rp200.000 sampai Rp905.000.000.
- Estimasi timer meningkat seiring nominal yang dipilih, dari 2 menit pada nominal minimum hingga 180 menit pada nominal maksimum. Waktu merupakan timer lokal untuk kredit virtual, bukan proses pembayaran.
- Sebelum kredit virtual dijadwalkan, pengguna melewati 26 langkah pemahaman. Ini bukan verifikasi usia 18+, KYC, atau pemeriksaan identitas.
- Kredit latihan tidak mempunyai nilai tunai dan tidak dapat dibeli, ditarik, ditransfer, atau ditukar. Tidak ada pembayaran, deposit, QRIS, transfer bank, atau kartu yang diproses.
- Aplikasi menampilkan hitung mundur serta mengirim notifikasi lokal ketika kredit latihan ditambahkan, jika izin notifikasi diberikan. Android dapat menunda alarm saat perangkat berada dalam mode hemat daya.
- Grafik LIVE menggunakan sampel ticker BTC/IDR publik dari Indodax dan diperiksa setiap 1 detik selama aplikasi terbuka. Grafik bergulir dengan jendela 90 detik; jika tidak ada transaksi/perubahan harga baru, titik harga dapat tetap sama sehingga garis terlihat datar. Perubahan 24 jam dihitung dari harga referensi 24 jam pada ringkasan pasar. API publik mendokumentasikan batas 180 permintaan/menit; polling 1 detik menggunakan sekitar 60 permintaan/menit. Jika request gagal, aplikasi menunggu 5 detik sebelum mencoba lagi. Ini adalah data satu exchange, bukan agregat seluruh pasar.
- Panel order memiliki tombol BELI BTC dan JUAL BTC di bawah grafik. Aksi hanya mengubah saldo/portofolio latihan lokal.
- Saldo, portofolio, dan riwayat order tampil di bawah panel order.

## Build
Workflow GitHub Actions ada di `.github/workflows/android.yml`. Simpan arsip ini di repository dengan nama persis `SatoshiPractice_Android_Project.zip`, dan simpan workflow di `.github/workflows/android.yml`. Workflow mencari arsip secara rekursif, mengekstrak proyek, lalu menjalankan `assembleDebug`.

## Build configuration
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- versionCode 7 / versionName 0.4.2


## Pembaruan v0.4.2
- Tambahkan pilihan "Jual Sebagai": BTC atau Saldo (IDR).
- Jika memilih BTC, angka input berarti jumlah BTC yang dijual.
- Jika memilih Saldo (IDR), angka input berarti nilai Rupiah bruto yang ingin dijual; aplikasi menghitung BTC yang diperlukan.
- Nominal BELI tetap dimasukkan dalam IDR.
- Informasi jumlah BTC dan estimasi nilai yang tersedia ditampilkan di bawah pilihan.
