# Satoshi Practice v0.3.0

Aplikasi Android portrait untuk mempelajari tampilan pasar BTC/IDR dan mencoba alur order menggunakan kredit latihan virtual. Aplikasi ini tidak terhubung ke exchange, tidak mengirim order sungguhan, dan tidak menerima uang.

## Fitur v0.3.0
- Ikon launcher memakai artwork Satoshi Practice yang diberikan pengguna, termasuk aset legacy dan adaptive icon Android.
- Pengaturan akun pertama kali berisi 14 langkah edukasi. Nama tampilan opsional disimpan lokal; aplikasi tidak meminta email, nomor telepon, KTP, selfie, rekening bank, password, atau seed phrase.
- Saldo awal selalu Rp0. Data saldo lama dari build sebelumnya direset pada migrasi pertama ke v0.3.0.
- Saldo dapat bertambah melalui tantangan edukasi 16 langkah. Hadiahnya Rp1.000.000 kredit latihan virtual, bukan deposit atau uang sungguhan.
- Kredit latihan dijadwalkan masuk sekitar 5 menit setelah seluruh langkah selesai. Aplikasi menampilkan hitung mundur dan mengirim notifikasi bila izin notifikasi Android diberikan. Jika aplikasi tetap terbuka, saldo juga disinkronkan saat hitung mundur mencapai nol.
- Grafik menggunakan data BTC/IDR historis dan quote publik CoinGecko. Hitung mundur UI bergerak setiap detik, sedangkan quote pasar dipolling sekitar 60 detik; data provider bisa tetap sama karena cache/rate limit. Tidak ada harga acak yang disisipkan sebagai tick nyata.
- Panel order memiliki tombol BELI BTC dan JUAL BTC di bawah grafik. Aksi hanya mengubah saldo/portofolio latihan lokal.
- Saldo, portofolio, dan riwayat order tampil di bawah panel order.

## Catatan data pasar
CoinGecko menyatakan endpoint umumnya di-cache sekitar 1–5 menit. API publik memiliki batas request per menit, sehingga polling per detik tidak menjamin harga lebih baru dan dapat memicu rate limit. Lihat dokumentasi dukungan CoinGecko untuk rincian terkini.

## Build
Workflow GitHub Actions ada di `.github/workflows/android.yml`. Simpan arsip ini di repository dengan nama persis `SatoshiPractice_Android_Project.zip`, dan simpan workflow di `.github/workflows/android.yml`. Workflow mencari arsip secara rekursif, mengekstrak proyek, lalu menjalankan `assembleDebug`.

## Build configuration
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- versionCode 3 / versionName 0.3.0
