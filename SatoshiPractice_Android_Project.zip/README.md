# Satoshi Practice v0.4.3

Aplikasi Android portrait untuk mempelajari tampilan pasar BTC/IDR dan mencoba alur order menggunakan kredit latihan virtual. Aplikasi ini bukan exchange/broker, tidak mengirim order sungguhan, dan tidak menerima uang.

## Fitur v0.4.3
- Ikon launcher memakai artwork Satoshi Practice yang diberikan pengguna, termasuk adaptive icon Android.
- Pengaturan awal berisi 14 langkah edukasi. Nama tampilan wajib diisi dan disimpan lokal; aplikasi tidak meminta email, nomor telepon, KTP, selfie, rekening bank, password, atau seed phrase.
- Saldo akun latihan baru dimulai dari Rp0. Saldo akun yang sudah ada tetap tersimpan saat update.
- Tersedia 36 pilihan nominal kredit latihan dari Rp200.000 sampai Rp905.000.000.
- Estimasi timer meningkat seiring nominal yang dipilih, dari 2 menit pada nominal minimum hingga 180 menit pada nominal maksimum. Waktu merupakan timer lokal untuk kredit virtual, bukan proses pembayaran.
- Sebelum kredit virtual dijadwalkan, pengguna melewati 26 langkah pemahaman. Ini bukan verifikasi usia 18+, KYC, atau pemeriksaan identitas.
- Kredit latihan tidak mempunyai nilai tunai dan tidak dapat dibeli, ditarik, ditransfer, atau ditukar. Tidak ada pembayaran, deposit, QRIS, transfer bank, atau kartu yang diproses.
- Aplikasi mengambil harga acuan BTC/IDR dari endpoint ringkasan publik Indodax. Harga acuan diperiksa setiap detik saat aplikasi terbuka; data bisa terlambat atau gagal dimuat.
- Grafik utama adalah **visualisasi volatilitas latihan acak**, bukan rekaman harga pasar. Grafik menghasilkan satu titik baru setiap detik di sekitar harga acuan terbaru, dengan gerakan kecil dan lonjakan sesekali agar pengguna dapat melihat garis hijau/merah yang berubah. Harga yang digunakan untuk perhitungan order tetap harga acuan Indodax yang ditampilkan di atas grafik.
- Panel order sekarang menyediakan pilihan satuan terpisah untuk **Beli Sebagai** dan **Jual Sebagai**, masing-masing BTC atau Saldo (IDR). Pilihan berlaku pada tombol yang sesuai:
  - Beli sebagai BTC: input berarti jumlah BTC yang ingin dibeli; saldo IDR dihitung dari harga acuan.
  - Beli sebagai Saldo (IDR): input berarti nominal rupiah; aplikasi menghitung BTC yang diperoleh.
  - Jual sebagai BTC: input berarti jumlah BTC yang ingin dijual.
  - Jual sebagai Saldo (IDR): input berarti nilai Rupiah bruto yang ingin diperoleh; aplikasi menghitung BTC yang perlu dijual.
- Biaya latihan 0,1% diperhitungkan pada order beli/jual. Saldo dan kepemilikan divalidasi sebelum order dicatat.
- Aksi BELI/JUAL hanya mengubah saldo dan portofolio latihan lokal. Saldo, portofolio, dan riwayat order tampil di bawah panel order.

## Build
Workflow GitHub Actions ada di `.github/workflows/android.yml`. Simpan arsip ini di repository dengan nama persis `SatoshiPractice_Android_Project.zip`, dan simpan workflow di `.github/workflows/android.yml`. Workflow mencari arsip secara rekursif, mengekstrak proyek, lalu menjalankan `assembleDebug`.

## Build configuration
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- versionCode 8 / versionName 0.4.3

## Pembaruan v0.4.3
- Grafik berubah setiap detik dengan seri volatilitas latihan acak yang diberi label jelas dan tidak disamarkan sebagai data historis pasar.
- Pilihan satuan Beli dan Jual kini terpisah dan keduanya berfungsi untuk BTC maupun IDR.
- Form input menampilkan satuan yang sedang aktif berdasarkan tombol BELI/JUAL yang dipilih.
