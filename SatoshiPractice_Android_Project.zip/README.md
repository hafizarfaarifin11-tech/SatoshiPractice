# Satoshi Practice v0.5.1

Aplikasi Android portrait untuk mempelajari tampilan pasar BTC/IDR dan mencoba alur order menggunakan kredit latihan virtual. Aplikasi ini bukan exchange/broker, tidak mengirim order sungguhan, dan tidak menerima uang.

## Pembaruan v0.5.0
- Registrasi awal dipadatkan menjadi 5 langkah:
  1. Nama tampilan/nama diri wajib minimal 24 karakter.
  2. Tanggal lahir dipilih melalui kalender Android (hari, bulan, tahun), bukan angka usia bebas.
  3. Domisili diisi sebagai provinsi, kabupaten/kota, dan kecamatan.
  4. Pilihan pengalaman latihan.
  5. Pilihan strategi latihan.
- Avatar inisial di kanan atas dashboard membuka halaman Akun.
- Halaman Akun memuat informasi profil, usia yang dihitung dari tanggal lahir, domisili, pilihan pengalaman dan strategi, ringkasan aktivitas strategi, portofolio, dan riwayat transaksi.
- Riwayat transaksi dipindahkan dari dashboard ke halaman Akun.
- Data nama, tanggal lahir, domisili, pengalaman, dan strategi disimpan lokal di perangkat. Data profil tersebut tidak dikirim ke server; koneksi internet aplikasi dipakai untuk mengambil ticker pasar publik.
- Update onboarding tidak menghapus saldo latihan, BTC latihan, atau riwayat transaksi yang sudah tersimpan.


## Pembaruan v0.5.1 — volatilitas lebih seimbang
- Grafik latihan tetap bergerak setiap detik dengan fase bullish, bearish, dan sideways.
- Saat sideways, harga lebih sering bergerak berombak di sekitar acuan ticker; bila acuan sekitar Rp1,155 miliar, area stabil yang umum berada di sekitar Rp1,15–Rp1,16 miliar.
- Fase bullish dan pump sesekali dapat membawa grafik ke sekitar Rp1,18 miliar atau lebih, bergantung pada harga acuan saat itu.
- Dump mendadak masih mungkin terjadi (sekitar 1,8–4,0% per kejadian), tetapi peluangnya diturunkan dibanding model sebelumnya.
- Batas ekstrem diperlebar secara moderat menjadi 90%–105,5% dari harga acuan, bukan 25%–400%.
- Grafik cache lama direset satu kali saat upgrade; saldo virtual, BTC, profil, dan riwayat transaksi tidak dihapus.

## Fitur latihan yang tetap tersedia
- Harga acuan BTC/IDR dari ticker publik Indodax.
- Grafik volatilitas latihan yang bergerak tiap detik dan menjadi harga aktif untuk estimasi serta order latihan. Grafik merupakan data latihan, bukan riwayat harga pasar.
- Order beli/jual dengan pilihan satuan BTC atau IDR, estimasi biaya 0,1%, dan tombol MAX.
- Saldo dan kepemilikan BTC virtual, portofolio, serta riwayat order lokal.
- Pilihan kredit virtual, timer, dan notifikasi lokal.
- RTP berisi rentang skenario heuristik yang tidak terkalibrasi, bukan probabilitas teruji atau jaminan profit.

## Build
Workflow GitHub Actions tetap berada di `.github/workflows/android.yml`. Simpan arsip ini di repository dengan nama persis `SatoshiPractice_Android_Project.zip`; workflow yang sudah digunakan sebelumnya tidak perlu diganti untuk pembaruan ini.

## Konfigurasi
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- versionCode 14 / versionName 0.5.1

## Privasi
Tanggal lahir dan domisili merupakan data pribadi. Masukkan hanya informasi yang memang ingin disimpan di perangkat. Tidak perlu memasukkan alamat jalan, nomor rumah, KTP, selfie, nomor rekening, OTP, atau kata sandi.
