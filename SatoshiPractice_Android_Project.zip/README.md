# Satoshi Practice v0.4.0

Aplikasi Android portrait untuk mempelajari tampilan pasar BTC/IDR dan mencoba alur order menggunakan kredit latihan virtual. Aplikasi ini bukan exchange/broker, tidak mengirim order sungguhan, dan tidak menerima uang.

## Fitur v0.4.0
- Ikon launcher memakai artwork Satoshi Practice yang diberikan pengguna, termasuk adaptive icon Android.
- Pengaturan awal berisi 14 langkah edukasi. Nama tampilan opsional disimpan lokal; aplikasi tidak meminta email, nomor telepon, KTP, selfie, rekening bank, password, atau seed phrase.
- Saldo akun latihan baru dimulai dari Rp0. Saldo akun yang sudah ada tetap tersimpan saat update.
- Tersedia 36 pilihan nominal kredit latihan dari Rp200.000 sampai Rp905.000.000.
- Estimasi timer meningkat seiring nominal yang dipilih, dari 2 menit pada nominal minimum hingga 180 menit pada nominal maksimum. Waktu merupakan timer lokal untuk kredit virtual, bukan proses pembayaran.
- Sebelum kredit virtual dijadwalkan, pengguna melewati 26 langkah pemahaman. Ini bukan verifikasi usia 18+, KYC, atau pemeriksaan identitas.
- Kredit latihan tidak mempunyai nilai tunai dan tidak dapat dibeli, ditarik, ditransfer, atau ditukar. Tidak ada pembayaran, deposit, QRIS, transfer bank, atau kartu yang diproses.
- Aplikasi menampilkan hitung mundur serta mengirim notifikasi lokal ketika kredit latihan ditambahkan, jika izin notifikasi diberikan. Android dapat menunda alarm saat perangkat berada dalam mode hemat daya.
- Grafik menggunakan data BTC/IDR historis dan quote publik CoinGecko. Hitung mundur UI bergerak setiap detik, sedangkan quote pasar dipolling sekitar 60 detik; data provider bisa tetap sama karena cache/rate limit. Tidak ada harga acak yang disisipkan sebagai tick nyata.
- Panel order memiliki tombol BELI BTC dan JUAL BTC di bawah grafik. Aksi hanya mengubah saldo/portofolio latihan lokal.
- Saldo, portofolio, dan riwayat order tampil di bawah panel order.

## Build
Workflow GitHub Actions ada di `.github/workflows/android.yml`. Simpan arsip ini di repository dengan nama persis `SatoshiPractice_Android_Project.zip`, dan simpan workflow di `.github/workflows/android.yml`. Workflow mencari arsip secara rekursif, mengekstrak proyek, lalu menjalankan `assembleDebug`.

## Build configuration
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- versionCode 5 / versionName 0.4.0
