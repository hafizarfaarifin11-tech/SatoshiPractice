# Satoshi Practice v0.5.7

A local Bitcoin-price practice app. Balances and orders are virtual; the app does not mine real BTC, custody crypto, process payments, or submit orders to exchanges.

## Auto Miner background mode

- Auto Miner runs in an Android foreground service after the user manually starts it.
- It continues the local virtual chart and simulated buy/sell logic while the screen is off or the app Activity is no longer visible.
- An ongoing notification shows that it is active and includes a stop action. Notification permission is requested on Android 13+.
- A partial CPU wake lock keeps one-second simulation ticks running while the screen is off. This can use noticeable battery power.
- The simulation uses the latest cached BTC/IDR market reference as its anchor. In background mode it continues locally and does not need a data connection, but the external market reference is not refreshed until the app is brought back to the foreground.
- Android battery management, manufacturer restrictions, force-stop, or device shutdown can still stop the service. It is not restarted after a phone reboot.
- An open bot position is retained as virtual BTC if the user stops the bot.

## Build

The Android app module is in `android_project/`. GitHub Actions workflow remains `android.yml`; no workflow changes are required for this update.

Build with JDK 17, Android SDK platform 35/build tools 35.0.0, and Gradle 8.7.


Wallet migration in v0.5.7 resets virtual IDR and BTC holdings to zero once after updating. It stops Auto Miner and cancels pending practice-credit alarms; profile and historical order logs are preserved.
