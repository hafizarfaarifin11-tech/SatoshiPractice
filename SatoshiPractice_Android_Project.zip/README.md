# SatoshiPractice v0.5.8

Local-only virtual practice simulator.

- Practice chart is bounded to Rp1,110,000,000–Rp1,200,000,000.
- The Auto Miner performs one virtual 60% win / 40% loss random draw per entry. The practice chart follows the selected game scenario until its +1.6% net take-profit or -1.2% net stop-loss is reached.
- Auto Miner can use up to 95% of the virtual balance per position; session brake is -3%.
- With Rp20,000,000 virtual balance, spending Rp19,000,000 and exiting at a rise from Rp1.11B to Rp1.13B yields about Rp303,696 net after 0.1% buy and sell fees. The 60/40 result roll may select a losing scenario instead.
- The entire "Informasi Saldo" dashboard card has been removed.

The 60/40 odds are an explicitly artificial game mechanic, not a real-market forecast or tested trading probability. All balances and transactions are virtual; no orders are sent to an exchange.
